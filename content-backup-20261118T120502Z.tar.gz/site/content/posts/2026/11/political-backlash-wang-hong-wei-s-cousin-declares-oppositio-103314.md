---
title: "Political Backlash: Wang Hong-wei’s Cousin Declares Opposition to Mayor Chiang Wan-an"
date: 2026-11-17T12:33:00Z
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiSEFVX3lxTE5pWW01TVVLLWMzVmdFTWtsemdyS2t1ZU92REhDakhrTmtyeDNhV2NCandNdW1yUEJFQ1NQUkp5ZHkydjUzM0F1YtIBTEFVX3lxTE1vSlNkTXZlNWw3SzR5d1laeFFrZVhsTHlxYWRPcEpTMEVBX1ZLWEhWSXVHeklOUHo2QVN2dGV3WHVFMVk4Sl9pS2pBYkc?oc=5"
source_name: "三立新聞網SETN.com"
draft: false
---

A surprising political development has emerged within the pro-Kuomintang (KMT) camp, as Wang Hong-pin, the cousin of KMT legislator Wang Hong-wei, publicly declared that she would not vote for Taipei Mayor Chiang Wan-an. Known as a prominent figure in the financial sector, Wang Hong-pin’s decision has sent shockwaves through local political circles, particularly due to her family ties to a staunch KMT supporter.

<!--more-->

The primary catalyst for this public dissent appears to be the city government's decision to demolish a pedestrian bridge, a move that critics have described as 'brutal' and insensitive to the needs of the community. Wang Hong-pin expressed her frustration with the administration's top-down approach, arguing that the city's urban planning decisions have alienated residents who care deeply about their local environment.

This act of defiance has been seized upon by opposition figures, including city councilor Ho Meng-hua, who used the incident to criticize the Chiang administration for ignoring the voices of citizens. While Mayor Chiang Wan-an has attempted to downplay the incident, the public stance taken by a member of a prominent KMT family has highlighted growing internal discontent regarding the mayor's governance style. The incident has sparked a broader conversation about the balance between urban modernization and the preservation of community spaces in Taipei.
