---
title: "聯合國駐西撒哈拉維和任務結束，摩洛哥重申遵守停火協議"
date: Thu, 05 Nov 2026 04:31:52 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMifEFVX3lxTFBzSDlRakFQX0w2NkxlZGxGbzVjeUI3NnlndDVRSUtvMl9iMjhDaGVxdDl4ZVRtMjVHdTJYSXlMWk11WnZEYnBJSTJoaHFJb1pWZ0g2ZWhFdUNCTFFKM2ZWLXZ3czZJZWdVOEJpckJSNDg3WVduVWRFQ25VSDc?oc=5"
source_name: "F4W/WON"
draft: false
---

摩洛哥政府近日正式宣告，儘管國際外交努力面臨重大阻礙，該國仍將繼續遵守有關西撒哈拉地區的停火協議。此前，聯合國在該地區長達35年的維和任務剛剛宣告結束，這一變動引發了外界對該地區未來局勢的廣泛擔憂。

<!--more-->

此次聯合國維和任務的終結，源於一場罕見的外交僵局。在安理會就相關決議草案進行表決時，美國和俄羅斯投下了反對票，導致未能達成共識。

中國對未能達成一致表示遺憾，並特別批評了由美國推動的決議草案。談判的破裂導致聯合國人員開始逐步撤離，實際上終結了自上世紀80年代末以來對該地區長達三十多年的國際監督篇章。

儘管聯合國維和任務撤出，摩洛哥方面堅稱其致力於維護地區穩定，並將繼續履行停火條款。目前，國際社會正努力應對維和任務結束後的連鎖反應，局勢依然錯綜複雜。

觀察人士正密切監測該地區是否存在任何局勢升級的跡象，而當地政府則強調，在缺乏正式聯合國機構存在的情況下，他們將致力於維持現狀。西撒哈拉的未來依然是國際社會激烈辯論的焦點，各利益相關方紛紛呼籲建立新的外交框架，以確保該地區的長期和平。
