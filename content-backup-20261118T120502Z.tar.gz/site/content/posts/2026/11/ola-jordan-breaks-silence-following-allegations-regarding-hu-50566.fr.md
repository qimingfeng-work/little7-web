---
title: "Ola Jordan brise le silence après les rumeurs d'infidélité visant son mari James Jordan"
date: Sun, 08 Nov 2026 17:15:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMioAFBVV95cUxQX3FybTg2VzZva3FTclJOU2xZLV9vWDJLZno1ZUFSY0d6alJYTmN3MTVQMFhxcFN3S25Dckg1X3BWdHdDT1d1R3h2Z3lWTjM0bjFrVF9HODluQ0hpak5yRnNjUHhoUF9kUUZRSHNNVWRTRG9scFNScXZIdENJd2RFNlpPNi0wbkFoeHBpX21kcjFnVENPeENhV1d4Vi1mM2FS?oc=5"
source_name: "The Sun"
draft: false
---

L'ancienne danseuse professionnelle de l'émission à succès *Strictly Come Dancing*, Ola Jordan, s'est exprimée publiquement pour la première fois face à la tempête médiatique qui entoure récemment son mari, James Jordan.

<!--more-->

Le couple, qui constitue depuis de nombreuses années l'un des piliers incontournables de la scène du divertissement britannique, se retrouve aujourd'hui au centre d'une intense spéculation suite à des allégations persistantes d'infidélité impliquant James et la danseuse Polina Mayer.

Dans le cadre d'un entretien exclusif accordé récemment à la presse, Ola a révélé qu'elle était « totalement dévastée » par le déroulement des événements.

La danseuse, mariée à James depuis de longues années, a décrit cette situation douloureuse comme la confirmation pure et simple de ses « pires craintes ».

Les allégations en question, suggérant que James se serait dangereusement rapproché de Polina Mayer au cours d'une période de tension conjugale, ont provoqué une onde de choc considérable tant au sein du grand public que parmi la solide communauté de fans du couple.

Cette prise de parole franche de la part d'Ola marque la toute première fois qu'elle s'exprime de manière aussi approfondie sur ces rumeurs insistantes.

Bien que le couple ait déjà eu à affronter le regard scrutateur des médias par le passé, la nature spécifique de ces nouvelles accusations a manifestement eu de lourdes répercussions sur son équilibre émotionnel.

La situation se trouve par ailleurs complexifiée par la notoriété publique de leur mariage, largement documenté par les tabloïds depuis plus d'une décennie.

Alors que cette affaire continue de faire les grands titres de la presse, les initiés de l'industrie du divertissement soulignent l'impact potentiel que cela pourrait avoir sur la vie professionnelle et personnelle des deux protagonistes.

Tandis que James Jordan n'a pas encore fourni de réfutation détaillée face à ces accusations précises, le débat public demeure principalement concentré sur les retombées émotionnelles vécues par Ola.

L'avenir du couple demeure ainsi l'objet de spéculations intenses alors qu'ils traversent ce chapitre particulièrement difficile de leur relation.
