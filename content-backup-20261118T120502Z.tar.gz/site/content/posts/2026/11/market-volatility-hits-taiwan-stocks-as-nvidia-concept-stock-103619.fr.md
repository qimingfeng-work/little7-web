---
title: "La Bourse de Taïwan connaît une séance en montagnes russes portée par les actions liées à Nvidia"
date: 2026-11-18T02:04:47Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMijgRBVV95cUxQemptUTU2em9zUXQ0WGNqNF9Sd0EyRi1KSTlTWnJ6cXQzRkpwRW80UG51Q1JFaFR2bkN0aWkwRk9XSW8yQ1NkZHpiV2lVN3FnTHowN3QwaWh4ekVabC00QUp1cGlSNkNielFia1dGVHc4Q1hPUERWVko1ZEMzLVZDbERkN1ViMjZvMms1U3RwdVhVMEprWVQ0RGdYOVM0bGY3UmpidjVpZlJXa0hYR0ZqZzVneXhBWS1sZVNoQ1pjWk81aEdUNk9PdHdKbGdtaGxzR0ZGRmVZaDdOZ21DWlNWdHBTSkZBZGxzTFFEWWtIY2dPbXBhMzR3MC1Nbk9ST2pXNVk4VXl6ekNXUW9vOEF0YVBxTUtRSU1rVkFlZzVTa2R4cVItaVpnM0pmU2lxMGxGdWdXVFYtYjRrY2lYZlVaOFJOMjY3YndySGlHU2ZfeUEteHZkNGJVa3dHMGJHUmgtaWd3OXo5LTJhR1lDMUl1MnhwTXV5bzZqZmU3OXJxaFFPNWl5T1pZZ3hYMUNVRE5RV1RKMUFHQkVvVHlxc25HZnp3U2hIb0RtMjBjaEw0UGlOcVJ2WUpFT0Vfd3pJT0lZamhSMTZWSmZkSVVSNXZqZjNBNVpkZ1BFMFdURnhweXpWZXJLOVFic0o3djFpYm4zZ0lhclREYjNlNUMxellJU0JhYWwtNW5HZjlvUDd3?oc=5"
source_name: "Yahoo股市"
draft: false
---

La Bourse de Taïwan a récemment traversé une séance aux allures de montagnes russes, caractérisée par une intense volatilité largement dictée par la performance des « actions du concept Nvidia ».

<!--more-->

Le marché a initialement bondi de plus de 800 points, stimulé par un optimisme prononcé entourant l'industrie des semi-conducteurs et le boom mondial de l'intelligence artificielle (IA).

Cependant, cet élan s'est avéré difficile à maintenir sur la durée, entraînant un renversement spectaculaire en cours de séance qui a vu une grande partie des gains initiaux s'évaporer à la clôture.

Les actions liées à Nvidia, acteur incontournable de la chaîne d'approvisionnement mondiale en IA, ont enregistré des mouvements significatifs.

Des entreprises telles que Kinsus Interconnect Technology ont initialement atteint la limite maximale de hausse quotidienne autorisée, tandis que des géants de l'industrie comme ASE Technology et King Yuan Electronics ont affiché des gains dépassant 5 % lors des premiers échanges.

Ces sociétés, souvent qualifiées d'« actions du concept Nvidia » en raison de leur rôle prépondérant dans l'écosystème du matériel informatique dédié à l'IA, sont devenues le principal baromètre du sentiment des investisseurs dans la région Asie-Pacifique.

Néanmoins, cet enthoususiasme débordant a été tempéré par des prises de bénéfices opportunistes et des inquiétudes plus générales concernant le marché, alors que des valeurs phares telles que Quanta Computer et Delta Electronics ont vu leurs gains matinaux se transformer en pertes nettes.

Les analystes financiers ont souligné que le passage rapide du marché d'une hausse massive à un repli net reflète la sensibilité actuelle et accrue des investisseurs aux tendances technologiques mondiales ainsi qu'aux mises à jour des chaînes d'approvisionnement.

Le secteur des substrats ABF, qui avait subitement été soumis à une forte pression baissière, a montré des signes encourageants de reprise dès le début de la journée, fournissant un soutien bienvenu à l'indice global.

Malgré le recul observé en fin de séance, le marché reste focalisé sur les perspectives à long terme du secteur de l'intelligence artificielle.

Il est vivement conseillé aux investisseurs de faire preuve de prudence, car l'interaction complexe entre la demande mondiale de semi-conducteurs et la dynamique du marché local continue de provoquer d'importantes fluctuations de prix à travers l'indice taïwanais, fortement axé sur les technologies de pointe.
