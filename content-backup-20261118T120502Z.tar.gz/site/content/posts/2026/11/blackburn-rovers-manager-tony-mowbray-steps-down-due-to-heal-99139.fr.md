---
title: "Tony Mowbray quitte son poste d'entraîneur de Blackburn Rovers pour raisons de santé"
date: 2026-11-17T10:34:29Z
lang: "fr"
mode: "llm_translate"
source_url: "https://www.bbc.co.uk/sport/football/articles/c6dx190nkvl4o?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
image_url: "https://ichef.bbci.co.uk/ace/standard/240/cpsprodpb/eb7a/live/5c0f70d0-6139-11ee-ac8c-9d18dbc280ea.png"
draft: false
---

Blackburn Rovers a officiellement annoncé que l'entraîneur principal Tony Mowbray quittait ses fonctions au sein du club de Championship.

<!--more-->

Cette décision intervient après une période de réflexion concernant ses problèmes de santé persistants, qui ont nécessité un retrait de l'environnement sous haute pression de la gestion du football professionnel.

Mowbray, qui a été une figure marquante à Ewood Park, laisse derrière lui un héritage de dévouement et de développement tactique.

Durant son mandat, il a joué un rôle déterminant dans la stabilisation du club et dans la promotion d'une culture de résilience au sein de l'équipe.

Le club a exprimé sa gratitude pour son éthique de travail infatigable et le professionnalisme dont il a fait preuve tout au long de son mandat.

La nouvelle a été accueillie par un élan de soutien de la part des fans et de la communauté du football au sens large, qui ont salué Mowbray pour son intégrité et son engagement envers le sport.

Bien que ce départ soit sans aucun doute une perte importante pour Blackburn Rovers, l'accent reste mis sur son bien-être et son rétablissement.

Le club a indiqué qu'il entamerait le processus de recherche d'un successeur, mais pour l'instant, la priorité est d'accompagner l'entraîneur sortant durant cette transition.

Alors que la saison de Championship se poursuit, Blackburn Rovers devra naviguer avec précaution dans cette période de changement.

L'impact du départ de Mowbray se fera sentir tant dans le vestiaire que parmi les supporters, mais le club reste attaché à ses objectifs à long terme.

Pour l'heure, le monde du football souhaite à Tony Mowbray un rétablissement rapide et complet, alors qu'il place sa santé au-dessus de tout.
