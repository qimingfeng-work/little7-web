---
title: "Paraguayan President Santiago Peña Resigns Amidst Banking Crisis"
date: Thu, 05 Nov 2026 17:40:40 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiW0FVX3lxTE9aN045UTM5R3Y3cW9QSk9hMHJzM1pxRjVNbUNKY0doeUNjTGt4Q1hWWGNhRGV3NU84NTN1bkJEcE9oVVl1MVZBLTRYVDdpbW1zY0xybVY5bUMzOVE?oc=5"
source_name: "BBC"
draft: false
---

Paraguayan President Santiago Peña has officially resigned from office, a move triggered by a catastrophic banking collapse that has left millions of citizens unable to access their life savings. The resignation follows days of intense public outcry and economic instability, as the nation's financial system struggled to cope with the sudden failure of a major digital banking institution.

<!--more-->

The crisis began when a prominent digital bank, once touted as a symbol of Paraguay's modernization, suddenly froze the accounts of millions of users. This left a significant portion of the population without access to their money, sparking widespread protests and demands for government accountability. President Peña, who had been a vocal supporter of the digital finance sector, found his administration unable to contain the fallout, leading to his eventual departure.

Political analysts describe the event as a significant blow to the right-wing administration, which had previously enjoyed a reputation for economic stability. The collapse of the bank has been described as a 'swaggering' failure, where rapid growth and lack of oversight eventually led to a total systemic breakdown. The freezing of savings has had a devastating impact on the middle and lower classes, eroding public trust in the government's ability to manage the economy.

As Paraguay faces this unprecedented crisis, the resignation of the President marks the beginning of a period of deep uncertainty. The international community, including financial institutions and regional neighbors, is watching closely to see how the country will navigate the aftermath of the bank collapse. The focus now shifts to the interim government's ability to restore order, address the grievances of the affected citizens, and stabilize the national financial sector before the situation deteriorates further.
