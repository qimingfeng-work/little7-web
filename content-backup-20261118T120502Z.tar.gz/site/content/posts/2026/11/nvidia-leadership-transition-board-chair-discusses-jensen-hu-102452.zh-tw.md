---
title: "Nvidia 召開財報會議：高層人事動盪後的穩定策略"
date: 2026-11-17T22:32:50Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://www.theverge.com/tech/1036160/nvidia-earnings-harvey-c-jones-jensen-huang"
source_name: "The Verge"
draft: false
---

Nvidia 近期召開了季度財報會議，這對這家科技巨頭而言是一個重要的里程碑，標誌著公司正處於領導層交接的關鍵時期。本次會議由財務長兼臨時執行長 Colette Kress 主持，並由公司史上首位董事長 Harvey C.

<!--more-->

Jones 共同出席。這是董事會首次針對長期領導人黃仁勳（Jensen Huang）離職一事，向公眾進行說明。

黃仁勳於上週辭去職務，起因是一系列關於其私生活的負面報導。據悉，多起婚外情指控浮出水面，其中更涉及與前 Megaspeed 高管 Alice 的高調關係，報導稱該名女子疑似為中國情報資產。

此醜聞在半導體產業引發軒然大波，促使 Nvidia 董事會迅速採取果斷行動，以穩定公司局勢並安撫股東。在會議中，Harvey C.

Jones 針對領導層真空問題以及公司的未來發展方向進行了回應。儘管公司面臨著替換一位曾帶領 Nvidia 在 AI 與圖形處理市場取得統治地位的遠見型領導人的挑戰，但董事會對目前的臨時領導團隊表達了信心。

公司的核心目標仍是維持營運連續性，並在動盪的市場中保護公司的競爭優勢。隨著 Nvidia 邁入新篇章，投資人與員工正密切關注該公司如何處理公司治理，以及在失去前執行長的情況下，是否能維持其成長軌跡。
