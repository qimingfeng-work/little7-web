---
title: "La PlayStation 5 franchit le cap historique des 100 millions d'exemplaires vendus dans le monde"
date: 2026-11-11T12:49:10Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMie0FVX3lxTE1DYXljdXJISFVEcFhkV2dJbllmTm1GV25ueFBKbHhyZ1BGZHlKT1BlOWUtd3N4YmNWTlRiMlB2dmdrTmJNa3FRcEI4cmlTWngzVXZMeGc4RHFCdGFWb3N0bVlENUhBUHl1M0lRZjFkbm5RUkZ6UHFXU01xOA?oc=5"
source_name: "Eurogamer.net"
draft: false
---

Sony a officiellement confirmé une étape matérielle majeure, annonçant que la console PlayStation 5 a franchi le cap des 100 millions d'unités vendues à travers le monde.

<!--more-->

Cet accomplissement place la console dans une catégorie d'élite du matériel de jeux vidéo, reflétant sa popularité constante et soutenue malgré les défis persistants de la chaîne d'approvisionnement mondiale et l'évolution rapide du marché vidéoludique.

Bien que la PS5 ait atteint ce chiffre impressionnant, elle accuse encore un certain retard par rapport aux ventes globales à vie de ses illustres prédécesseurs, à savoir la PS1, la PS2 et la PS4, qui demeurent à ce jour certaines des consoles les plus vendues de tous les temps.

Les analystes de l'industrie notent que cette étape revêt une importance toute particulière compte tenu de l'enthousiasme actuel entourant la sortie imminente du très attendu 'Grand Theft Auto VI'.

De nombreux joueurs ont entrepris de mettre à niveau leur équipement matériel en prévision des derniers titres à succès, et la PS5 demeure la plateforme de choix incontournable pour le jeu haute fidélité.

La demande soutenue et constante pour la console suggère que la stratégie de Sony, axée sur le développement de titres exclusifs de premier plan et sur des performances matérielles de pointe, continue de séduire un public extrêmement large et diversifié.

Pour l'avenir, les discussions au sein de la communauté des joueurs ont déjà commencé à s'orienter vers les prochaines générations.

Alors que la PS5 est désormais solidement établie sur le marché, les débats concernant les fonctionnalités potentielles et la nécessité future d'une hypothétique 'PS6' commencent à gagner du terrain.

Pour l'instant, toutefois, l'attention reste fermement concentrée sur le succès actuel de la génération en cours et sur la bibliothèque massive de jeux qui continuent de stimuler les ventes de matériel.

Le seuil des 100 millions d'unités sert d'indicateur clair de la force durable de la marque PlayStation au sein d'une industrie de plus en plus compétitive.

net
