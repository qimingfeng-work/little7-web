---
title: "Israeli Military Utilized Amazon Facial Recognition to Monitor Palestinians"
date: 2026-11-16T11:00:56Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://www.theguardian.com/world/2026/nov/16/israel-amazon-facial-recognition-palestinians"
source_name: "The Guardian World"
image_url: "https://i.guim.co.uk/img/media/bc01b369b562e3e2bf256cd5482bab9f368d5175/1_0_2999_2400/master/2999.jpg?width=140&quality=85&auto=format&fit=max&s=d4fd5266aa44369a3472db45234f5224"
draft: false
---

Leaked documents have revealed that the Israeli military uploaded approximately 3.5 million photographs to Amazon’s cloud computing platform to facilitate the use of advanced facial recognition technology. This initiative, which aimed to track and analyze images of Palestinians, was reportedly accelerated during the initial months of the intense aerial bombardment and ground offensive in Gaza.

<!--more-->

The integration of Amazon’s cloud services into the Israeli military’s surveillance infrastructure highlights the growing reliance of state actors on private-sector technology to meet the demands of modern warfare and intelligence gathering. According to reports, the massive database was curated to help identify individuals within the conflict zone, raising significant questions about the intersection of corporate technology and military operations. The scale of the data transfer underscores the depth of the technological support provided to the Israeli military as it navigated the logistical and operational challenges of the Gaza offensive.

This revelation has ignited a debate regarding the ethical responsibilities of major tech corporations when their tools are deployed in active conflict zones. While Amazon has maintained that its cloud services are intended for a wide range of civilian and governmental applications, the use of such powerful biometric tools for military surveillance against a specific population has drawn sharp criticism from human rights organizations. The documents suggest that the project was a key component of the military's broader strategy to enhance its situational awareness and targeting capabilities during the height of the hostilities. As the international community continues to scrutinize the impact of the conflict, the role of global tech giants in providing the backbone for such surveillance operations remains a point of intense contention.
