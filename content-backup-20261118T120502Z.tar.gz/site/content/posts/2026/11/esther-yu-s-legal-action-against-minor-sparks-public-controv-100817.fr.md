---
title: "Controverse autour de l'actrice Esther Yu : entre cyberharcèlement et recours juridiques"
date: 2026-11-17T06:20:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiwwNBVV95cUxOYURFMGpHTnQzRGRzRzVmNmVWa1RicktXbVI5cEZBS1BLTGxsQmpreTFVX0wya0tyaEJrRURDUkdtc2s3Mm1KUXI0eXVSWFAwS1BzTkpPdE45U2RZQ1d4Q09sZGFJUEp2QkVSUWdMckFvT2ZPb0lvOFgyX0pldElLSGltTVdxaERVcVdabFFkOHJuNXVzc1hkTzF2b1pxVUtUOE9KbjNvM0hMMnNCd3gyc0RNVzJkNUpSSml3SG5vaFFBeGJLYklKZU05WFloRjFOblprVGJlZXluanZxTklQajRSSUdwekZfck91SEhUVEZVNXRsMkZrbmZvdnlkQ2hqSHl3d25QN2VDbUJ1N0ZfNTVkNzg3OWU5bTluVWVCUk5Fb1BRUzl4djhrWVU5bFo1WW9oSXZ3T3d3V2ZOaE5fcGJyQmNJYzhsdjJvSVNOWXQySUpRRGFsMTN1SVo1THhJS2hJZ0xkSWxpTzR1eHNzNUxWcXpBODcyTE4ydmRSTlVxM2lDVnN3VV9DY256TWxkSnJKcnctNVUtR1FZQUUtaUJnVGI4NFVPYnpDaElob3NQZHl0dVZTX19oRkM4Y25jMUtz?oc=5"
source_name: "Yahoo新聞"
draft: false
---

L'actrice et chanteuse chinoise Esther Yu se retrouve au cœur d'un débat public houleux suite à des poursuites judiciaires engagées contre une internaute de 14 ans.

<!--more-->

La controverse a débuté lorsqu'une jeune utilisatrice a publié des commentaires critiques sur des photos récentes de Yu, où l'actrice portait un tablier jugé par certains comme trop suggestif.

Ces images, montrant la star avec le dos exposé, ont suscité une vague de réactions négatives remettant en cause la pertinence du contenu.

Suite à ces critiques, des rapports ont suggéré que Yu avait entamé des poursuites contre l'adolescente.

La situation s'est envenimée lorsque la mineure a affirmé que les membres de sa famille, y compris son père et son grand-père handicapé, avaient également été visés par les procédures.

Ce détail a provoqué une vague de sympathie pour l'adolescente et de vives critiques à l'encontre de la célébrité, beaucoup s'interrogeant sur l'éthique de cibler une mineure et sa famille pour des commentaires en ligne.

En réponse, le studio d'Esther Yu a publié une déclaration officielle urgente pour clarifier la situation.

Ils ont affirmé que leurs actions visaient uniquement les individus engagés dans la diffamation et la propagation de rumeurs malveillantes, et non la famille de la mineure.

Le studio a insisté sur le fait que le processus juridique visait à protéger la réputation de l'artiste contre un harcèlement persistant.

De plus, ils ont précisé que les procédures suivaient des canaux professionnels standards.

Malgré ces efforts de transparence, l'incident a déclenché une discussion plus large sur Internet en Chine concernant les limites de la responsabilité des célébrités, la protection des mineurs en ligne et l'usage approprié des mesures juridiques par les personnalités publiques.

Les experts juridiques soulignent que, bien que les célébrités aient le droit de défendre leur réputation, l'implication de mineurs nécessite une approche plus nuancée de la résolution des conflits.
