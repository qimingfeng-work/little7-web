---
title: "Coup dur pour 'Strictly Come Dancing' : le danseur Kai Widdrington contraint à l'incertitude"
date: 2026-11-14T21:07:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiiAFBVV95cUxQN29SUGlSMHdQV0EtZTJNeWxQenhLUlBxSHB3Q0pXaF9Md1N6WXk3WE1IUkhWbzNKWVlUUEpEdTZjOG1kMGhmel9Gb1NIdkRKVTZrajFzelN5MlhBckxjTkllRS1WSHBOYjVJbDdpQkRXeE5PSENPaWlNOUxiMEdUX2ZEbm1yb0tQ?oc=5"
source_name: "The Sun"
draft: false
---

L'émission de danse à succès diffusée à la télévision britannique, « Strictly Come Dancing », fait face à une épreuve difficile après qu'il a été révélé que le danseur professionnel Kai Widdrington pourrait être contraint de se retirer définitivement de la compétition en cours.

<!--more-->

Widdrington, qui forme un duo très populaire avec la chanteuse australienne Delta Goodrem, qui figurait parmi les favorites du public, a été terrassé par une maladie soudaine survenue en plein milieu des répétitions.

Cet imprévu a contraint le couple à annuler sa prestation très attendue d'un tango argentin, plongeant les fidèles du programme dans la déception et imposant un véritable défi logistique à la production.

Face à cette urgence sanitaire, la direction de l'émission a dû improviser un changement de partenaire de dernière minute afin de permettre à Delta Goodrem de poursuivre son aventure dans le concours.

Cette décision inattendue a provoqué des remous au sein de l'équipe, la complicité évidente entre Widdrington et la chanteuse constituant l'un des points culminants de cette saison.

Le danseur Johannes Radebe, autre figure incontournable du programme, est intervenu directement sur le plateau pour informer le public et exprimer la gravité de la situation.

Alors que l'équipe de production met tout en œuvre pour s'adapter à cette transition forcée, l'incertitude concernant l'état de santé de Widdrington continue de peser sur les organisateurs.

Le couple s'entraînait intensément sur le morceau « Missing » du groupe Everything But The Girl, et ce changement brutal de stratégie constitue un frein considérable à leur progression.

À l'approche des phases décisives du concours, tous les regards restent tournés vers un éventuel retour de Kai Widdrington sur la piste de danse, ou si cette affection marquera la fin prématurée de son parcours dans l'édition de cette année.

Les téléspectateurs attendent avec impatience de nouvelles communiqués officiels quant à l'avenir de ce partenariat et son impact direct sur les performances du week-end à venir.
