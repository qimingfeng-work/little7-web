---
title: "Taipei Mayoral Candidates Present Platforms Amidst Unique Campaign Moments"
date: 2026-11-14T06:26:00Z
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiSEFVX3lxTE9GV2pfa25aTDZIWnl2czdWVVBnVEw2Nm1MTUJKSElHYllraGZUYk9OYWpyZmg4WW1YRGtWblJpTHM4R3I4ek5DWtIBTEFVX3lxTFB2T0hfMEZRejF4MHZrOUE0MnFMeVUtTkJvMGFlRVctT0FMN01RUG1iLUZnWmxoTEdZc0lHZWNmMkhKczhuaXFFWW9ObXc?oc=5"
source_name: "三立新聞網SETN.com"
draft: false
---

The Taipei mayoral race has entered a high-stakes phase, with candidates participating in public policy presentations that have drawn significant attention for both their political content and the unusual circumstances surrounding them. Candidate Shen Po-yang, representing a distinct approach to the campaign, made headlines by opting for a low-key preparation style, stating that he spent his morning helping his daughter with her homework rather than engaging in intense media training or relying on lucky charms.

<!--more-->

During the public presentations, the atmosphere was marked by a mix of serious policy debate and political theater. While Shen focused his platform on the core concept of 'HEART,' emphasizing his commitment to addressing issues such as child abuse and school lunch quality, other candidates faced a more chaotic environment. Reports from various news outlets noted that the event saw unconventional tactics, including verbal jabs between opponents and even impromptu musical performances, reflecting the high tensions of the Taipei election.

Chiang Wan-an, another key contender, faced his own set of challenges, including a rushed arrival at the venue that required him to change his suit mid-journey. Despite the distractions, Chiang used his platform to highlight his four-year administrative record, positioning himself as a candidate focused on stability and execution. He explicitly distanced himself from the 'politics of hatred,' urging voters to focus on the future of the city rather than divisive rhetoric.

The public presentations have provided voters with a clearer view of the candidates' priorities and personal styles. As the election nears, the focus is expected to shift toward how these candidates plan to implement their proposed policies. For Shen, the next stage will be to demonstrate his executive capability, while for others, the goal remains to maintain momentum in a race that has become increasingly unpredictable. Sources: 三立新聞網SETN.com, Yahoo新聞, 公視新聞, Rti 中央廣播電臺, NOWnews今日新聞
