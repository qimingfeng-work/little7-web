---
title: "Tensions politiques lors d'un événement de campagne : incident entre Qin Hui-chu et un partisan"
date: Mon, 09 Nov 2026 11:20:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiSEFVX3lxTE9QZlRFSi1MUUNYdDFubE9NNmYyNUttQTIyNnl6dG1BVmlwQS1QV3J1SFFNZHlrS05KbVZMX2w1aXVTTzFkRmZkRNIBTEFVX3lxTE5IbDFZWUk1OGVjV2FvcGFVa0FuV2hOejF3X3EyQzVIU3JmOWd3YkFlakJ3ek1LYlU2YTJWMHRBSTdfQ2Z4SDJfV2REcDk?oc=5"
source_name: "三立新聞"
draft: false
---

Un récent événement de campagne mettant en vedette le maire de Taipei, Chiang Wan-an, et la conseillère du KMT, Qin Hui-chu, a pris une tournure inattendue lorsqu'un partisan a publiquement confronté cette dernière.

<!--more-->

Lors de la distribution d'autocollants de campagne, un individu a interpellé Qin en lui demandant : « N'êtes-vous pas du camp vert ?

Comment pouvez-vous être ici ?».

L'incident a rapidement attiré l'attention, alimentant les rumeurs de frictions internes au sein du camp bleu et les allégations selon lesquelles Qin serait ostracisée par ses propres partisans.

En réponse aux images virales et aux spéculations qui ont suivi, la politicienne du KMT, Hsu Chiao-hsin, est intervenue pour clarifier la situation.

Hsu a rejeté les affirmations selon lesquelles Qin aurait été harcelée ou exclue, affirmant que l'interaction avait été sortie de son contexte et ne reflétait pas une fracture plus large au sein du parti.

Elle a souligné que l'événement visait à démontrer l'unité et que de tels incidents isolés ne devaient pas être interprétés comme un signe d'exclusion politique systématique.

Parallèlement, l'événement a également suscité des critiques de la part d'autres personnalités politiques, notamment la conseillère du DPP, Chien Shu-pei, qui s'est interrogée sur le respect des règles de neutralité administrative par le maire lors de sa présence à la station de métro pour distribuer des autocollants.

L'incident met en lumière les sensibilités accrues et les postures politiques adoptées à l'approche de la saison électorale, les deux grands partis surveillant de près les activités de campagne de leurs adversaires pour détecter d'éventuels faux pas.
