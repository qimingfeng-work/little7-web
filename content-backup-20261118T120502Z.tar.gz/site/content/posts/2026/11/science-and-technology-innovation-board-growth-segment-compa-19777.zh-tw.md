---
title: "上海科創板“成長”板塊財務表現強勁，虧損縮減超九成"
date: Sun, 01 Nov 2026 08:43:18 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiiwFBVV95cUxOVG50dEw3UnhBTU5JYUZwNXJRQU9jSU9qLTlWbURBcnJUcHhlWTdFSzMzR0V0Wkp3bHpMN1JlRC13S0VRSml3YjY3Q0s1OEtzOHBURDFVdlRCdVljeDBBcVJWZWtCWjk0TWkyQjlXc001dFZsMlJTQ2V2M0duWkNvTTRPNmZXcTJQSmpZ0gGLAUFVX3lxTE1idEFzTS11Sm1MVGprUVYtd0FaVWFBazczNTU1bEE3dUpyU05RdERlb0p0TkwzejN2QVpKVEZXM1FMUTliVnFpbU5fSEN6d3JtV2FpRkVGQWlvZ3g1cWhsRnFoQ0IzTnpoOWlYLW5hY2VaU1ZOU2RFRzFLT3NLTGQtcHRjRGVORXJHd1k?oc=5"
source_name: "DW.com"
draft: false
---

最新財務資料顯示，上海證券交易所科創板“成長”類公司在今年前三個季度成功扭轉財務頹勢，虧損額同比收窄超過90%。得益於產品商業化成熟、運營效率提升及成本控制最佳化，這些以研發驅動為主的企業正逐步實現底線穩定。

<!--more-->

專家認為，這一復甦跡象不僅體現了企業向成熟期轉型的能力，也展示了科創板在培育高科技增長型企業方面的成效。
