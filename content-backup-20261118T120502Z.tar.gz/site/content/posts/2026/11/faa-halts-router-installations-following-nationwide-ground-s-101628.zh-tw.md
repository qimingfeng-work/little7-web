---
title: "FAA 暫停網路路由器安裝，美國航空管制系統現代化面臨資金爭議"
date: 2026-11-17T16:57:15Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMibEFVX3lxTE5lOUR5Z2FVYl9wcUNQU1VzNkN4LVk0d3lCMzQ2X1hPaEdFdVl1VkZnVk83cndNcjZzNExYdHJ1cVE1M3JtUVVJUUVaQjNueC1UZk9WbHBpQUhMZG1EeG9iVUEwQTFVVXQ0c0YyYtIBckFVX3lxTFAxcllCeTNjOS1HNXRaU2VOaW90eXdiZjF4S0ZjY3ZCRURfOG00WjhaU192Skk4QjlVM0pMaTl2RkdydjRSZWJQOE9meVhMTzhBNWdBd0JOZHFIYWYxczFmMHV3LWh1cWlBYjN3S1JPcVhYZw?oc=5"
source_name: "CNBC"
draft: false
---

美國聯邦航空總署（FAA）在經歷一場導致數千架航班中斷的全國性地面停飛事件後，已正式暫停在其設施安裝新的網路路由器。此決定正值該機構面臨國會議員、產業專家及公眾對其老舊基礎設施可靠性的強烈質疑之際。

<!--more-->

近期影響超過 2 萬架航班的地面停飛事件，在華盛頓重新引發了關於美國空中交通管制系統資金與現代化的激烈辯論。儘管 FAA 已要求額外 500 億美元來進行技術全面翻新，但該提案在參議院遭遇重大阻力。

包括共和黨成員在內的批評者質疑該機構的管理能力，指出近期的技術故障證明，單純投入資金並不能取代有效的監督與營運改革。政治緊張局勢使情況更加複雜，先前對 FAA 處理地面停飛事件不當的批評再度浮上檯面。

該機構目前面臨壓力，必須證明其能在維持現有營運的同時升級系統。暫停路由器安裝旨在進行技術更新的全面審查，以確保在過渡期間不再發生任何中斷。

隨著航空業努力從巨大的航班積壓中恢復，FAA 正處於十字路口。該機構必須在迫切的現代化需求與穩定性需求之間取得平衡。

目前，重點在於穩定現有網路，但如何資助與管理國家空域的長期問題，仍是可能在未來數月國會聽證會中佔據主導地位的爭議焦點。
