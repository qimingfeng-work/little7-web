---
title: "迪士尼宣佈新一輪裁員計畫，目標 2029 年節省 30 億美元支出"
date: 2026-11-17T11:33:18Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMihAFBVV95cUxNVTV3Q3c5eXh4UHN2d2w5cjhzcTlrM3lXUXpDdFJEejNzX3d1QzJGVkVGaUVPVFZrTmpZSFNuUnZEWERUMEZoZ0tnZVZycWdRZWg0NEY5QmJPNTBIZlRWd3BCNlNpcG16RUN2aUJvdWhzaDVacFhFMEFTdU12MEwtRXdMb1Q?oc=5"
source_name: "Financial Times"
draft: false
---

華特迪士尼公司（The Walt Disney Company）宣佈將進行新一輪裁員，作為精簡營運與達成顯著成本節約計畫的一部分。

<!--more-->

這家娛樂巨頭設定了在 2029 年前削減 30 億美元支出的目標，此舉反映了公司在競爭激烈的媒體環境中，持續追求長期財務永續性的策略轉型。儘管進行了人力縮減，迪士尼近期的財務表現仍相對強勁。

公司第四季財報優於市場預期，主要歸功於串流媒體服務的持續成長以及主題樂園業務的穩健表現。近期漫威電影的成功上映也為串流部門提供了必要的助力，有效抵銷了內容製作相關的成本壓力。

管理層將這些成本削減措施定調為資助未來成長與創新的必要步驟。透過精簡營運開銷，迪士尼旨在更有效地投資於其核心業務，包括直接面對消費者的串流平臺以及全球樂園與體驗部門。

此策略旨在確保公司保持靈活，並能適應全球觀眾快速變化的收視習慣。此訊息在投資人與產業分析師之間引發了兩極反應。

雖然部分人士讚揚其財政紀律，但也有人擔心裁員對公司創意文化的負面影響。儘管如此，迪士尼仍致力於其長期願景，利用其龐大的智慧財產權組合來維持在全球娛樂市場的統治地位。

如何在成本效率與創意產出之間取得平衡，將是迪士尼未來幾年能否持續成功的關鍵因素。
