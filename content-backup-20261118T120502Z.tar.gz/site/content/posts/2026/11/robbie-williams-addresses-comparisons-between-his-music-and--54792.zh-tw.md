---
title: "流行歌手羅比・威廉斯公開回應奧莉維亞・羅德里戈新歌相似爭議，展現大度風範"
date: Mon, 09 Nov 2026 13:30:23 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMi3gFBVV95cUxNTWRjd2gteXZTTUgwSy1zZWtfVl9mcFZubXp1S0tNYmIyMEs0NlpodFp5cl9TTXh1T3BDNjdFMUJVSXZfbGRkNlIxQllKR3RIUmJ0QndLSjc3QkVrQ3VGa3k0SHZfWFJMcjluRTVkNlV1VkJISmxtRHMyV3N1Zzkxb3MweUFxbWZLdi00Vy1hV3A4UVRjZXFzdm1FcXlDbjhnOHVQVGZzQVpxaFR1Nm9BVVhjOG9lMXBsNkd1UGxRcHZSNmxmNzlhQ2VIU3JqSzd4bF9CV1M0SE56TFRIRUE?oc=5"
source_name: "Just Jared"
draft: false
---

英國流行樂壇巨星羅比・威廉斯（Robbie Williams）近日公開回應了網路上關於奧莉維亞・羅德里戈（Olivia Rodrigo）新歌在旋律結構上與其經典名曲相似的討論。威廉斯並未藉機煽動爭議，而是透過直接的訊息平息風波，並向這位年輕歌手錶達了支援。

<!--more-->

先前，社群媒體平臺與各大音樂部落格充斥著關於這種相似性的各種猜測，並對威廉斯最初的評論產生了解讀上的分歧。為了消除任何可能的誤解，威廉斯堅定地澄清了自己的立場，明確表示自己完全沒有意圖引發爭議或採取法律行動。

他同時對於網路評論能如此迅速地將微小的音樂巧合放大成激烈辯論，感到有些莞爾。隨著音樂產業資深人士紛紛就創意創作過程發表看法，這場對話轉向了正面發展。

經典節慶歌曲《Christmas Wrapping》的詞曲創作者對羅德里戈的新聖誕歌曲給予了熱情肯定，讚賞她在數十年後仍能完美捕捉特定的懷舊氛圍。觀察家指出，音樂靈感與旋律引用在整個產業中相當常見，而公眾的反應往往突顯了跨世代對永恆流行美學的欣賞。

威廉斯在宣告結尾將目光直接投向羅德里戈，送上鼓勵的話語並駁斥了被人為炒作的戲劇性風波。他輕鬆幽默的態度不僅平息了歌迷的焦慮，也將焦點重新引導迴音樂本身，證明瞭資深藝術家與新星能夠在公眾的嚴格檢視下展現相互尊重。
