---
title: "教宗方濟各訪問秘魯，呼籲保護亞馬遜雨林與人權"
date: 2026-11-16T12:00:33Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiswFBVV95cUxNWHZnRzEtdXVOdC0xNkY0VHVYMjdETUJVRGJMSXBXbV94d2hIdmJ6eDY2ZVhpTGJpQlRCdldyV3JjM2dfRmtQVHpZcmRJWWpQcElUaklnQWlIUWdBLXdSamN0dHVHZzN1OVotZTVQYXFXek5Ic3NxRDlDdzdCVDZoblo4TktGNk1IeVBZM25xcTlDbGZ2djNaYmVOMkxySEdjWS1iVFBJaGhacTZjemJYV2Q3NA?oc=5"
source_name: "Vatican News"
draft: false
---

教宗方濟各在秘魯進行牧靈訪問的第四天，參與了一系列感人至深的活動，展現其精神領袖地位及對社會與環境議題的承諾。在奇克拉約市（Chiclayo），教宗主持了聖母加冕儀式，吸引了數千名信徒參與，成為此次訪問的精神核心。

<!--more-->

現場氣氛感人，對當地天主教社群而言是難忘的時刻。除了宗教儀式，教宗亦利用此平臺呼籲關注迫切的世俗問題，特別是亞馬遜雨林的困境。

他在公開演講中強烈呼籲立即停止濫伐森林，並稱此舉是對地球生態健康的毀滅性打擊。談及破壞環境的人力成本時，他直言不諱地譴責那些為了保護祖傳土地免受剝削，卻在過程中失去生命的部落領袖與環境捍衛者，稱這些行為是「謀殺」。

這項正義呼籲在他在利馬及雨林地區的會議中引起共鳴。教宗強調，保護環境與保護人權密不可分。

他敦促國際社會與地方當局優先保障那些站在環境保護第一線的人員之安全。透過將捍衛亞馬遜視為道德責任，他試圖將此議題提升至全球舞臺，提醒信徒傳播「福音」的內涵包括守護受造物以及為邊緣群體追求正義。

在訪問期間，教宗由包括秘魯空軍成員在內的多位官員陪同，協助其跨越複雜地形。此次訪問提醒世人，梵蒂岡正持續努力與當地民眾互動，探討超越宗教界限的議題，將傳統虔誠與當代社會行動主義相結合。

訪問結束時，教宗的訊息清晰明確：教會與那些遭受環境退化與系統性不公的人們站在一起。
