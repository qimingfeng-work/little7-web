---
title: "Le Royaume-Uni face au dilemme historique des excuses pour l'esclavage"
date: Thu, 05 Nov 2026 13:29:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMilAFBVV95cUxNNzZIdERwVGYzNFFDRG5PaGNrOFk1c2JhUnZ6MXZnU0VMeWJGbTA2WTk4TE5MM2NqZ3VacXAxSjBGbmJDWTR0bzZRNHRoRGZOanRRc3IxYVdPazRlcDUxUVdFUDdCVG85a0Z0LTZGZHdLcExUTkgyY3BnS0dTSk1xMFZXeVp5alprMXJuam1kMXc5bVg3?oc=5"
source_name: "The Guardian"
draft: false
---

Le Royaume-Uni traverse actuellement une période de réflexion diplomatique et sociale complexe, alors que le gouvernement envisage de présenter des excuses officielles pour son rôle historique dans la traite transatlantique des esclaves.

<!--more-->

Les observateurs scrutent avec attention l'expérience récente des Pays-Bas, où une démarche similaire a suscité des réactions contrastées, afin d'identifier les écueils potentiels et les leçons à tirer pour Londres.

L'expérience néerlandaise a démontré qu'une telle repentance n'est jamais un acte simple ; elle est perçue de manière divergente selon les segments de la société.

Au Royaume-Uni, le débat est tout aussi polarisé.

D'un côté, les partisans des excuses soutiennent qu'il s'agit d'un impératif moral indispensable pour reconnaître les souffrances de millions de personnes et entamer un processus de guérison collective.

De l'autre, des voix s'élèvent pour exprimer leurs craintes quant aux implications politiques et financières, redoutant que ces excuses ne servent de base à des demandes de réparations ou ne creusent davantage les divisions au sein de la population britannique.

Des rapports récents indiquent que le gouvernement britannique s'engage dans des discussions « limitées dans le temps » sur cette question, cherchant à trouver un équilibre délicat entre la reconnaissance des torts historiques et la gestion des attentes du public.

Des personnalités politiques, telles qu'Ed Miliband, ont tenté de rassurer les contribuables en affirmant que des excuses ne signifieraient pas nécessairement un coût financier direct, mais le scepticisme demeure prégnant.

Parallèlement, la famille royale, et particulièrement le roi Charles III, fait face à des défis diplomatiques majeurs lors de ses déplacements dans les Caraïbes, où les appels à la responsabilité et à la reconnaissance du passé colonial se font de plus en plus pressants.

La leçon majeure du cas néerlandais est que la formulation des excuses est tout aussi cruciale que l'acte lui-même.

Sans une stratégie claire et un engagement sincère auprès des communautés affectées, le geste risque d'être perçu comme purement performatif ou insuffisant.

Alors que la Grande-Bretagne avance, elle doit déterminer si elle est capable de construire un récit qui aborde le passé sans aliéner son propre public national, une tâche qui demeure l'un des exercices d'équilibriste diplomatique les plus ardus pour l'administration actuelle.
