---
title: "Mauricio Pochettino impose une discipline de fer à Manchester United"
date: 2026-11-17T17:39:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMijwFBVV95cUxPRktmbk8zUm5PZkJmYUp6RjhXMlZ1NDlXa2tHTmR1VXVIZkpESnpJcE52T2JiTGZRbUtKbHZ3ajU2NXdSMFRFeXVmNVJDanQ3Q1lGdnpmSkhUTUo5NlRIY2xfa2hmZEVyN2llc3NzWjNleWI1VHRKanFEcENxaF9wMUpwd09GRkxLRVl5dFRiTdIBlAFBVV95cUxQdl9tb2ZaZ2tHTTdFZjdIcE41WUpzTE1iM0ZfeVUxWE54eE1JVHgxaWdCN1pZR3lnVXhHS0duSlpQY21vU1VMYUpuSzNKQWlSX1UzbjR2TEF1NnVuaHEyYlhyUkFaVmxCRlpDMHNEVGpxOGxUR3VaYkhFZlJwZFVsMHdLUTlpeUtGTVR6ZTVuWG9GLXc4?oc=5"
source_name: "Mirror"
draft: false
---

Mauricio Pochettino n'a pas perdu de temps pour affirmer son autorité à Manchester United, introduisant une série de changements de règles rigoureux visant à élever la condition physique et le professionnalisme de l'équipe.

<!--more-->

Alors que le club se prépare pour un choc à enjeux élevés contre Liverpool, le nouvel entraîneur a signalé un changement clair de culture, soulignant qu'il faut « être une bonne personne » pour réussir sous sa direction.

L'un des changements les plus notables concerne la suppression des jours de repos programmés après les matchs.

Pochettino, connu pour sa philosophie d'entraînement intense, mettrait en œuvre un programme de remise en forme majeur pour s'assurer que ses joueurs répondent aux exigences physiques de son style de pressing haut.

Cette décision a été interprétée comme une réponse directe aux inquiétudes selon lesquelles l'effectif actuel manquerait de l'endurance nécessaire pour exécuter efficacement sa vision tactique.

En gardant les joueurs engagés et en s'entraînant de manière cohérente, Pochettino vise à construire une unité plus résiliente et disciplinée.

En coulisses, la transition a été rapide.

Pochettino a déjà envoyé son équipe d'entraîneurs à Manchester pour commencer le travail de fond, s'assurant que l'équipe est préparée aux changements tactiques qu'il a l'intention d'introduire.

Bien que certains experts aient remis en question la capacité de l'effectif actuel de Manchester United à s'adapter au style de football spécifique de Pochettino, l'entraîneur reste concentré sur la tâche immédiate.

Le match à venir contre Liverpool servira de test décisif pour ces nouvelles normes.

Les joueurs s'adapteraient à cette approche stricte, qui privilégie avant tout l'effort collectif et le conditionnement physique.

L'interdiction des jours de repos après les matchs n'est que le début de ce qui devrait être une refonte complète des opérations quotidiennes du club.

La réputation de Pochettino pour le développement des jeunes talents et la promotion d'un environnement de travail acharné est mise à l'épreuve dans l'environnement sous haute pression d'Old Trafford.

Alors que l'équipe se prépare pour la rencontre contre Liverpool, tous les regards seront tournés vers la question de savoir si cette nouvelle approche disciplinée se traduira par une amélioration des performances sur le terrain.
