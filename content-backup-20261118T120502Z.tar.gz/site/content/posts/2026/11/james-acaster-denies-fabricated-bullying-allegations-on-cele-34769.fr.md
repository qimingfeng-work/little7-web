---
title: "James Acaster dément les rumeurs de harcèlement sur le tournage de 'Celebrity Traitors'"
date: Wed, 04 Nov 2026 12:18:37 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMirwFBVV95cUxPUHVHYmdXMG51WUttTVotVko1ZDhHRnVpTWo4aTdXNzFEZ0hnOVN5SWVrS055WDdpd2JyRS04Y0dyNjJ2UEN6VURyMUNvTmxKbTlMZ3hYUGdfQUpncXpjbzRlR1dDcUNOM3BUVjZ0M3FDQ1Qtd21uQUdBR193VVlEVnUwU2FkUXRrOElQMG9hMTlFT01PT1REelJWVW0tcEJoRW43dTFGbFljRzBLN0Nv?oc=5"
source_name: "Digital Spy"
draft: false
---

L'humoriste James Acaster a publiquement pris la parole pour mettre fin aux rumeurs persistantes concernant sa participation à l'émission de téléréalité 'Celebrity Traitors'.

<!--more-->

Il a fermement rejeté les allégations suggérant qu'il aurait été victime de harcèlement de la part d'autres candidats.

La controverse avait pris de l'ampleur suite aux déclarations du chanteur James Blunt, qui avait laissé entendre que la version diffusée à l'écran ne reflétait pas toute l'intensité des interactions entre les participants.

James Blunt, également candidat, avait affirmé que les téléspectateurs n'avaient pas pu mesurer l'étendue des interrogatoires subis par Acaster durant le programme.

Ces remarques ont alimenté de nombreuses spéculations médiatiques, certains médias avançant même que l'humoriste aurait été pris pour cible par d'autres stars, ce qui aurait précipité son départ de l'émission.

Toutefois, Acaster a qualifié ces récits de « totalement fabriqués », insistant sur le fait que la perception publique de son expérience est en totale contradiction avec la réalité des faits.

Face à cette polémique, la BBC, chaîne responsable de la production, a réagi par le biais d'un communiqué officiel.

Le diffuseur a souligné que le bien-être de tous les participants demeure sa « priorité absolue ».

La chaîne maintient qu'elle dispose de protocoles rigoureux visant à garantir un environnement sûr et bienveillant pour tous les intervenants de ses projets de téléréalité.

Malgré les assurances de la chaîne et les démentis d'Acaster, l'affaire continue de susciter un débat sur le montage des émissions de téléréalité et les risques de manipulation narrative.

En supprimant certaines séquences, les producteurs pourraient avoir involontairement créé un vide propice aux interprétations erronées et au sensationnalisme.

Alors que la poussière retombe sur ces allégations, James Acaster reste concentré sur la clarification de la situation : les tensions dramatiques observées à l'écran ne reflétaient pas un environnement hostile, mais illustraient simplement la nature compétitive du jeu télévisé.
