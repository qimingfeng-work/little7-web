---
title: "Tories Pay Artist for Burnham Images After Legal Threat"
date: 2026-11-13T18:41:13Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://www.bbc.co.uk/news/articles/cr5y139wplppo?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
image_url: "https://ichef.bbci.co.uk/ace/standard/240/cpsprodpb/41d4/live/e6b0b330-c0cb-11f1-a5b0-6f550c662e91.jpg"
draft: false
---

The UK Conservative Party has reached a financial settlement with prominent illustrator Stanley Chow after utilizing his artwork without proper authorization. The dispute arose when the political party incorporated Chow's distinctive illustrations depicting Prime Minister Andy Burnham in promotional materials and campaign communications, prompting the artist to threaten formal legal action for copyright infringement.

<!--more-->

Stanley Chow, renowned for his bold portraiture style and pop-culture depictions, discovered his work being used by Conservative accounts online and in print without his consent or compensation. Recognizing the potential legal exposure and the reputational damage of an intellectual property dispute with a well-known independent creator, party representatives moved quickly to resolve the matter. Sources close to the negotiation confirmed that an undisclosed financial payment has now been made to the artist.

This incident highlights ongoing concerns within political organizations regarding digital content usage and copyright compliance. As social media campaigns increasingly rely on rapid-fire visual content, the boundary between fair use, political commentary, and outright copyright violation frequently becomes blurred. Creators and trade bodies have repeatedly urged political parties and public figures to respect intellectual property rights, emphasizing that artists rely on licensing fees and commissioned work for their livelihoods.

Legal experts note that political entities are not exempt from standard copyright laws, regardless of whether the imagery is used for commentary, satire, or public awareness campaigns. By settling the matter swiftly, the Conservative Party has avoided a potentially embarrassing public trial and set a precedent regarding the valuation of freelance creative work in political advertising.
