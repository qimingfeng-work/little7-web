---
title: "Ajustements des effectifs en MLB : Quel avenir pour les espoirs taïwanais ?"
date: 2026-11-18T03:43:06Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMirAJBVV95cUxQamRHd0d0MnF0RWtMTG55SE50YjlYeGItdmluSjduaktJbDZCWS1CVzZYb1BtX0RqRHpRQlozQ2ZPanlqbjROUVliM1UzODdQcF9HU0EwSFdGc243Q0tuQnNoZkRxQUVnT2VUN2tIeTltTEVxR2ZOVktlanU1dHlqeXdjYXJKOTFsbGlRc2NrdkVsdWxhLU4tZEE3SkdIU1Y4MHlJTmNZMENUQ29ubVBISEw5dTFBMEtuRDdKczhnYldPaHpGa1Riamo5YnBxY19hMnF5VXpadDZEbl8zdkotbGgyR3E3eTRPQ0tGdVlIaTFTU3l2UWR5QnRuVkljU2NTWm9icmlGRl9hdm9PMlR2V1hPUHZGd3pRTlBnVUpKYm1IdFpyc3pkX0c4UXU?oc=5"
source_name: "Yahoo運動"
draft: false
---

Les Tigers de Détroit ont procédé à des ajustements significatifs de leur effectif en plaçant quatre joueurs sur la liste des transferts (DFA).

<!--more-->

Ce mouvement intervient alors que les équipes de la Ligue majeure de baseball (MLB) finalisent leurs effectifs de 40 joueurs, une étape cruciale pour protéger les talents en vue de la prochaine Draft de la règle 5.

Parmi les développements notables, plusieurs espoirs taïwanais se retrouvent à un tournant de leur carrière professionnelle.

Pour les fans de baseball taïwanais, l'attention se porte sur le statut d'étoiles montantes comme Tsung-Che Cheng et Hao-Yu Lee.

Ces deux joueurs ont réussi à conserver leur place dans l'effectif de 40 joueurs de leurs organisations respectives, ce qui leur offre une sécurité accrue pour poursuivre leur développement au sein du système MLB.

Maintenir une telle place est une étape majeure, indiquant que l'organisation les considère comme faisant partie de ses plans à court ou moyen terme.

À l'inverse, d'autres talents taïwanais, dont Yu-Min Lin, Pan Wen-Hui et Lin Chen-Wei, n'ont pas été inclus dans l'effectif de 40 joueurs de leurs équipes.

Cette exclusion les rend éligibles à la Draft de la règle 5, un événement annuel permettant à d'autres clubs de sélectionner des joueurs non protégés.

Bien que cette incertitude puisse être difficile pour ces jeunes athlètes, elle représente également une opportunité potentielle de rejoindre une organisation offrant un chemin plus direct vers les ligues majeures.

La Draft de la règle 5 a historiquement servi de tremplin pour de nombreux joueurs souhaitant prouver leur valeur au plus haut niveau.

Alors que l'intersaison progresse, la communauté du baseball continue de débattre des implications de ces mouvements stratégiques, qui reflètent l'équilibre constant entre le développement à long terme et la flexibilité immédiate des effectifs.
