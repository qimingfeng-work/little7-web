---
title: "Shane Gillis Addresses Backlash Following Controversial SNL Monologue"
date: 2026-11-14T15:43:00Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMilwFBVV95cUxOTVY5SnR5LXZkRWhWSU5xalppcXRvenZYWVBTWmRTMkNOVkstcURFTWM4aXdrWm9FNFB4aHZsdElhYk8tc3dTYUxscng0bWZlY0phY3RUaHpieFIwVG45ekVlTkJSeGdRUjczbDZFN2ZGMVRrbDMweUU0a1RpSl9QSE9aRWV5VkthbmVjdnFVUEU4Ui0wSk4w?oc=5"
source_name: "Variety"
draft: false
---

Comedian Shane Gillis has finally broken his silence regarding the intense backlash he faced following his recent monologue on 'Saturday Night Live'. The controversy stemmed primarily from a segment in which Gillis made jokes about the attire of women at gyms, a bit that drew immediate criticism from various corners of the internet and media landscape.

<!--more-->

In his response, Gillis expressed genuine surprise at the scale of the negative reaction. He clarified his position, stating that he does not actually have a problem with how women choose to dress while working out. The comedian suggested that the intent behind his monologue was misinterpreted, and he emphasized that he had aimed to avoid controversy during his return to the iconic sketch show.

Despite his promise to keep things light, the monologue quickly became a focal point of debate regarding the boundaries of comedy and the evolving standards of public discourse. Gillis's comments reflect the ongoing tension between traditional stand-up sensibilities and the expectations of a modern, highly sensitive audience. As he navigates the aftermath, the incident highlights the precarious position comedians often find themselves in when performing on high-profile platforms where every word is subject to immediate and widespread scrutiny.
