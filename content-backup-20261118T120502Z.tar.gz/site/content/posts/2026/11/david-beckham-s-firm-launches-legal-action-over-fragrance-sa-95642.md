---
title: "David Beckham's Firm Launches Legal Action Over Fragrance Sales in Discount Retailer"
date: 2026-11-16T13:26:00Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMisAFBVV95cUxONWdqRUV0dktXTWl4eExSa3FsakVZaFZKR3pxbFVRSi1WcHZObFU1MnVaRDFzUlJEakVod2Y1SDFWMEJKNE5zWHpfZDEtbHFLXzhUVkpBRnh3MWtqbmlyUzI4c3JkQkpvQ1dxV3VaRVlDR2lMbnNBSnhNMnlWRlRYZDRBQWtzQzF2dmlaXzNBUlU2SWp2cUdhajFuRnZJX25ZWE9xSDN2QlY3d0t2bThtWg?oc=5"
source_name: "The Guardian"
draft: false
---

David Beckham's business empire has initiated legal proceedings following the discovery of his branded fragrances being sold at the discount retail chain, Poundland. The legal dispute centers on the unauthorized distribution of the products, which the Beckham firm argues undermines the brand's premium image and violates existing distribution agreements. The case has highlighted the challenges celebrities face in maintaining brand integrity within the global retail market.

<!--more-->

Reports indicate that the legal action could involve claims for significant damages, with some sources citing figures as high as $41 million. The core of the dispute lies in how the fragrances ended up on the shelves of a discount store, a move that the Beckham firm claims was not sanctioned by their licensing partners. By selling the items at a fraction of their intended retail price, the store has allegedly caused financial harm and diluted the exclusivity of the Beckham fragrance line.

Legal experts suggest that this case serves as a warning to retailers and distributors about the importance of supply chain management. For a brand as globally recognized as David Beckham's, the perception of value is paramount. The presence of luxury-marketed goods in a discount environment can lead to consumer confusion and damage long-term brand equity. The Beckham firm is seeking to hold the relevant parties accountable for what they describe as a breach of contract and unauthorized trade.

As the legal battle unfolds, the retail industry is watching closely to see how the courts will interpret the rights of brand owners in controlling the secondary market. Poundland and other retailers involved in the distribution chain have yet to provide a detailed public defense, but the scale of the lawsuit suggests that the Beckham firm is prepared for a prolonged legal fight. This incident underscores the ongoing tension between high-end celebrity branding and the aggressive pricing strategies of discount retailers.
