---
title: "Le sénateur Richard Blumenthal réclame la démission de Lutnick sur fond de scandale Nvidia"
date: 2026-11-14T20:33:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMilgFBVV95cUxOLXF2TW1semtjZmNCMEVCZUN0czVVc3ZpTmlCRXg1Q1ZMMmdwS1ZsdG1Db1ZqTHpwYXBfQXd2YVRUSm14VnNVTzVnTUpiR3o1UkllUlBYaEtHX01fYW9wbERYWGJvZWJfV1RSTi0xaGh1V19PWU04bHBMRnp3R2VfN3lLc0NmdHJocVhlUEg0bTlzTWFuVHfSAZsBQVVfeXFMT1A1UWZqRC0yNV80UEtmQV9DSmROa2NKLVhmcTZnMjhBX3ltdmJrMXYzTTQ3VkozenJpazNyTVRHNFh2cVpINnZhcEpJSC1wVHBhbVRrTWlodDlrTTN5YnZ4VXphbDNQV182NnNXbGtObTBhc180UkRZNTlKNDhpUkxCakx5Y3BzcGR2ZUpqSGw1ZHAxS3dBeTdVcUU?oc=5"
source_name: "The Hill"
draft: false
---

Le sénateur Richard Blumenthal a publiquement exigé que Lutnick quitte ses fonctions à la suite de l'émergence d'un scandale impliquant le fabricant de puces Nvidia.

<!--more-->

La controverse s'articule autour d'allégations de liens inappropriés et de risques potentiels pour la sécurité nationale, des critiques affirmant que les accointances de Lutnick ont compromis l'intégrité de son mandat.

La situation s'est encore envenimée avec la parution de rapports suggérant qu'une entreprise liée aux fils de Lutnick entretiendrait des connexions étroites avec le géant des semi-conducteurs, soulevant ainsi des questions cruciales quant à d'éventuels conflits d'intérêts.

Ce que l'on qualifie désormais de « scandale Nvidia » a atteint les sphères les plus élevées de l'État, braquant les projecteurs sur le cabinet de Donald Trump.

Cette affaire a suscité des appels pressants en faveur d'un processus de vérification des antécédents plus rigoureux et d'une transparence accrue concernant les transactions financières des hauts fonctionnaires gouvernementaux.

Selon des informations relayées par Axios, un malaise perceptible gagne même les rangs du mouvement MAGA, certaines figures politiques prenant leurs distances à l'égard de Lutnick au fur et à mesure que se dévoilent les détails de cette affaire d'espionnage présumée impliquant la Chine.

En outre, le département du Commerce fait l'objet de vives critiques pour son omission d'inscrire sur liste noire l'entreprise Megaspeed, prétendument impliquée dans ce scandale élargi.

Bessent et d'autres hauts responsables ont exprimé leur exaspération face à ce qu'ils considèrent comme une absence d'action résolue, accentuant la pression sur l'administration pour qu'elle prenne à bras-le-corps ces impératifs de sécurité.

À mesure que s'approfondit l'enquête sur ces connexions sulfureuses, le coût politique de cette affaire pour Lutnick semble aller croissant.

Cet incident met en relief toute la complexité de la régulation des industries de haute technologie et le risque d'ingérence de l'espionnage international dans l'élaboration des politiques intérieures, laissant l'administration aux prises avec les retombées de ces graves accusations.
