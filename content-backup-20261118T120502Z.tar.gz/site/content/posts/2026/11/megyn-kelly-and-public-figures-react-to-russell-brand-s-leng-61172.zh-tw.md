---
title: "羅素·布蘭德性侵案判決引發輿論風暴，名人問責制再成焦點"
date: Tue, 10 Nov 2026 18:48:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiwgFBVV95cUxOVTlwVGRQVG5TSlF6cGt6VldPclViYXRuQS0tNVNoaEdobUJCMXZsbFY4LXhxM19uS0FibUkwdjZQOE5zTklpTUdWc1g5ZGFWcnZ6RUZQM3hyaXJCcWU0ajRJVmZlYzczemhCUlpvaGdwbFZCQ25BQ3E2aE5Xbk54ZXVHNUJNSkdOX0tEZnRyZ0llUXY2bGRXNmh6U0hORWR3cjFvbG9GQU9aMGU5aG45SHk2c180N2dGcW1oV1ZkMXBYQQ?oc=5"
source_name: "USA Today"
draft: false
---

英國喜劇演員兼媒體人羅素·布蘭德（Russell Brand）因強姦與性侵罪名被判處十年以上徒刑，此判決在媒體界引發了激烈的辯論。判決出爐後，包括記者梅根·凱利（Megyn Kelly）在內的多位知名人士公開質疑刑罰的嚴厲程度。

<!--more-->

凱利形容這長達十年的刑期「瘋狂」，進而引發了關於司法量刑準則以及公眾對高知名度刑事案件認知等更廣泛的對話。針對布蘭德的法律程式伴隨著對其過去行為的強烈審視。

包括《紐約時報》與 NPR 在內的主要媒體報導指出，針對他的指控範圍遠超近期定罪的範疇。布蘭德的前伴侶潔米瑪·高史密斯（Jemima Goldsmith）公開指控他曾有虐待行為，為公眾輿論增添了個人證詞的層次。

這些揭露使圍繞其名人身份的敘事變得複雜，焦點從他的娛樂事業轉向了他在私生活中的行為。對判決的反應並不僅限於法律分析師。

伊隆·馬斯克（Elon Musk）等人士也加入了評論行列，部分批評法律程式的人士認為該刑期比例失衡。然而，這些觀點也遭到了另一派人士的反駁，他們認為該懲罰反映了性侵指控的嚴重性。

隨著布蘭德開始服刑，此案持續成為討論問責制、「#MeToo」運動以及名人身份與刑事司法交集的重要焦點。媒體報導依然密集，從他自由的最後時光到入獄後的立即影響，各家媒體都在追蹤每一個發展細節。
