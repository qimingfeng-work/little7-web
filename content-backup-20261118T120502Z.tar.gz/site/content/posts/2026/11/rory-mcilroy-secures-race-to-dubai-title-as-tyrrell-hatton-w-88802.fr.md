---
title: "Golf : Rory McIlroy sacré à Dubaï, Tyrrell Hatton triomphe au DP World Tour"
date: 2026-11-15T13:41:15Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMi9gFBVV95cUxOMlpBc2x1SzlWMFhTQTFndDBMT01qTnBhMWtBLTg3TkprT2NRdVhyeHVEZW4yX0xPMnVaakdKbkQ3ZDRwaHlfMEpZZVphZEo4bUpOcmtMOFl1QVFEU1VzcHZIc05lbFowS2xXcHBReHVJTjE2U2lvSVFTVVZBZkt6aXQ5MW9kYUNiY2N5ZGhHTzBhR1NqbTFWeTJYOG82X1ptYnJPeEtrYWFSUEhqRkRraDB0YlN4YkFGLUNraUxEVF9PUkVMZ0tvc2VyYXpzVTF3eWt2MTUxNmN6ay1EZHpGbjdidWhiLXd1X3l0NU9UYUY5VlNjNXc?oc=5"
source_name: "Sky Sports"
draft: false
---

La saison de golf 2026 s'est conclue en apothéose lors du DP World Tour Championship, où Rory McIlroy a décroché son titre historique dans la « Race to Dubai ».

<!--more-->

Malgré un champ de joueurs extrêmement compétitif et une pression intense lors de la dernière journée, McIlroy a sécurisé la prestigieuse couronne saisonnière, égalant ainsi le record de victoires à l'Ordre du Mérite détenu par la légende Colin Montgomerie.

Très ému, McIlroy a dédié cet exploit à son père, actuellement hospitalisé, ajoutant une dimension profondément personnelle à ce nouveau jalon professionnel.

Si McIlroy a raflé le prix global de la saison, la victoire dans le tournoi lui-même est revenue à Tyrrell Hatton.

Auteur d'une performance magistrale tout au long de la semaine, Hatton a su repousser les assauts de ses rivaux de haut niveau pour s'imposer avec autorité lors de cette finale.

Son succès souligne une campagne exceptionnelle et confirme son statut parmi l'élite du golf mondial.

La dernière journée du tournoi revêtait des enjeux majeurs : doubles adhésions au PGA Tour, cagnottes lucratives et exemptions cruciales pour l'Open étaient en jeu.

Alors que les joueurs luttaient jusqu'au dernier trou, le drame a captivé les fans du monde entier, offrant un point d'orgue mémorable à une année de golf international inoubliable.

Ce dénouement marque non seulement la fin d'une saison, mais aussi le début d'une nouvelle ère pour ces champions.
