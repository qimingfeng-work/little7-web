---
title: "Renforcement des liens sino-cambodgiens : une amitié « d'acier » célébrée lors du 73e anniversaire de l'indépendance"
date: Mon, 09 Nov 2026 08:35:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiaEFVX3lxTE1nVUtRMnNYUzV6TV9NOERKMlhVTWxFbjF6STlSMWs5UUFIWHFuM29rd3FvWDRURWFiakk5V2Q0NHpndDEyTGtkcDlxaS15eGJWYmg0MExReU1IX2Fzb3RDRTJIWDZYaTd4?oc=5"
source_name: "早晨报"
draft: false
---

Le président chinois Xi Jinping a récemment réaffirmé la solidité des relations entre la Chine et le Cambodge, qualifiant les deux nations d'amis « d'acier ».

<!--more-->

Cette déclaration intervient dans un contexte de célébrations fastueuses au Cambodge, qui a marqué son 73e anniversaire d'indépendance par trois jours de festivités intenses.

La capitale, Phnom Penh, a été illuminée par des feux d'artifice spectaculaires et des cérémonies traditionnelles de la torche de la victoire, symbolisant la souveraineté retrouvée du pays.

Pour souligner cet événement historique, le président Xi a adressé un message de félicitations formel au roi du Cambodge, Norodom Sihamoni.

Cet échange diplomatique souligne la profondeur de la confiance mutuelle, de la coopération stratégique et de l'histoire partagée qui unissent Pékin et Phnom Penh.

Des diplomates de haut rang et des représentants internationaux ont également salué cette relation, notant que les récents développements diplomatiques et les cadres de paix régionaux ouvrent de nouveaux chapitres dans les relations internationales.

Le Cambodge, par ces célébrations, a non seulement mis en avant son riche patrimoine culturel et sa fierté nationale, mais a également réaffirmé son engagement diplomatique croissant sur la scène mondiale.

Les observateurs soulignent que ce partenariat solide demeure une pierre angulaire de la stabilité régionale en Asie du Sud-Est, caractérisé par une collaboration économique robuste et un soutien mutuel sur les intérêts nationaux fondamentaux.

Cette alliance stratégique continue de jouer un rôle prépondérant dans l'équilibre géopolitique de la région, favorisant des investissements conjoints et une coordination étroite sur les dossiers sécuritaires et économiques.
