---
title: "Taiwan's National Stabilization Fund Adjusts ETF Holdings Amid Market Volatility"
date: Wed, 11 Nov 2026 23:00:00 GMT
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMipwNBVV95cUxNZEhXV0RSSGgwWDFuWndwc2JrWXBneXJoMFg0Q3dMdGNJWGJLS1VUbnNqcXVPVDUxWURjR2Q4VHRkRW12eVljTEhQTU1xU1ZzSE03Y0VHWjVvVE04bEdpajl2cnF2MnJyU2p3aGRXUnQtakZIdTdmYWcwQnJyZnp6OERDTHdWckNDVmpKSkkwSFhYR3EyRDMzMm1HbmdDbHNiY3cxT29zV2JteHloQWZHSGlUZWhZUThzQ1kxN0p0UmhoaDNrYzIxRlptRy1Tek9pWUU2THRRTlhiX19vMEt3S0JYOXUxY1V3RURRWXJjUHBHZUFpbXNLWEc3ZzN1TVZnZkdLTEdoSFNfanJvT2F5WXlDR0VLS2NqSkRmX1U0S0hDeU5CWmJIUzJrbVdaQURqcXA2QTJyZDlubXZVd3FsaE5EY0xVLVpSX3JHUkhlMzRhS2sxcC11RlRleXZ5b2pnOWZBWlFJZ2tYNnlTUWFtY3l5Wk9jbF9lQjZuZFMzSk5IbG9EX1ZXa0NfSkNOamhkeDJXNUFFYWZtdl9UQUpGSzlfNUd1YlE?oc=5"
source_name: "Yahoo股市"
draft: false
---

Recent market data indicates that Taiwan's National Stabilization Fund, often referred to as the 'national team,' has begun adjusting its investment portfolio by offloading significant positions in leveraged ETFs. Reports suggest that the fund took advantage of recent market highs to sell approximately 19,000 shares of two specific '2x' leveraged ETFs. Additionally, the fund has reportedly withdrawn 290 million New Taiwan Dollars from its holdings in the 0050 ETF, signaling a strategic shift in its market intervention approach.

<!--more-->

This move has sparked widespread discussion among investors, particularly as the broader market experiences fluctuations. While the state-backed fund manages its exposure, foreign institutional investors have shown a different trend. Data shows that foreign investors have been net buyers of certain stocks for ten consecutive days, with some holdings exceeding 100,000 shares. This divergence in strategy between the national team and foreign capital highlights the complexities of the current Taiwanese stock market environment.

Individual stocks have also faced unexpected volatility. For instance, Powerchip Semiconductor Manufacturing Corporation (PSMC) saw a sharp 11.9 percent rise before experiencing a sudden sell-off, leaving its 690,000 shareholders in a state of confusion. Analysts are closely monitoring these movements to determine if the market is entering a period of correction or if these adjustments are merely tactical rebalancing by major players.

Furthermore, the activity of foreign and domestic investment trusts remains a focal point. While some sectors are seeing heavy selling pressure, others are being targeted as potential 'dark horses' for future growth. The market remains sensitive to these institutional shifts, as investors look for clues on how the national fund will continue to influence liquidity and price stability in the coming quarters. As the situation evolves, market participants are advised to remain cautious and monitor the ongoing rebalancing efforts by both state and foreign entities.
