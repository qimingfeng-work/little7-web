---
title: "Political Controversy Arises Over Jaw Shaw-kong's Campaign Appearance for Chiu Chen-yuan"
date: Tue, 10 Nov 2026 06:10:10 GMT
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMisgNBVV95cUxNT1hZWUlkd0tJSWw0UjNKV1BtTGE2RWdHSmtyV0dxdDVhNjNFcUJYSGtESmk2MUNkYkUxbVU0SG1Femo1Nm82YnM1Z2J1ZDR4ME5pWHgzLUVfMGMwbTMwMWMxeG5DVUwwRl9Zc1MxRmdfczBoWjdpVjgyLVJxMXRwaXN5UGF0VWtrYWRtOFNjZGkyZ3pEYkpCV0huQUlQOFFSaUpQY0JBeHZwLUdwNklkR3JwczJRY1FFZzFNUGZ5YWdqcjl2TEp1OHJVMVVlUElxbE95cE93bnhkczdpS05KZjhJSVVoVlBMS2xhSFJDazZ5NjR2eUhmUTFQY2dSQlc1ZDBNQXp0cnpPd09LX1JjTlhaWDJ2VU1ocXBib0xpbGtVNFE1bUozemxkQzZyYTh3UmE1WHhVY3ZVZHRFNGpmd1ZobWdnS1YxZjdlOFM4Z2hPcGg0elZkVXdyZnJtQndyOFhuLTdIa0dzVjFfZDZicXlQeHZDbTl6N1EwLUN2YTJLYlFrN0RfUHBBdXFHakZmQUE0SG8xclU0Wms3ZF9ZWDF3OHdXTW1SOEdLLTdMMG9sZw?oc=5"
source_name: "Yahoo新聞"
draft: false
---

A recent political event in Taiwan has sparked considerable controversy within local political circles after Jaw Shaw-kong made a high-profile appearance to support candidate Chiu Chen-yuan. The move immediately drew questions regarding party loyalty and the ongoing discussions surrounding opposition cooperation strategies, highlighting the delicate political alliances forming ahead of upcoming elections.

<!--more-->

Addressing the ensuing debate, Chang Ya-ping, head of the Kuomintang's (KMT) disciplinary committee, maintained a pragmatic stance. Chang emphasized that promoting cooperation between the pan-Blue coalition and the Taiwan People's Party (TPP) has become a broad consensus among party members, thereby dismissing notions that disciplinary action or internal sanctions would be pursued against Jaw for crossing party lines during the campaign.

Meanwhile, other political figures weighed in on the dynamic, with various discussions focusing on mayoral races, cross-party strategic coordination, and the leadership styles of key figures within the opposition camp. Commentators noted that while such joint appearances demonstrate a unified front against the ruling party, they also expose underlying tensions and differing strategic visions among coalition partners regarding how best to approach the electorate.
