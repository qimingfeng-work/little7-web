---
title: "Incident insolite au Pérou : le pape Léon touché à l'œil par un chapelet lors de sa tournée sud-américaine"
date: 2026-11-16T20:49:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiswFBVV95cUxOaktGWV9xYmVVbkttU2l0ZG5SQ0xaeWxNM2ZQb253LUtYWW8xVWEtYUFpWHg5cFNwM2Mwa1FEQnVYT004RzVtTzdMOHl1OHFnTnl5UUI2SHU2UXpNdWtrVVJlcUlndkJObUkyQ091dkJxZzU5anJyVEc3eDZYR3hENHlyWFQta3ZtV0pMUzdNaG5TbmZlZnptalJIdzRUR2otSjBVVnVvSzFBenVheXJvSjFEdw?oc=5"
source_name: "New York Post"
draft: false
---

Lors de sa dernière apparition publique au Pérou, le pape Léon a vécu un incident inopiné et douloureux lorsqu'il a été frappé à l'œil par un chapelet lancé par la foule.

<!--more-->

L'événement s'est produit alors que le souverain pontife participait à un défilé d'adieu, un moment destiné à célébrer la conclusion de sa tournée historique de 12 jours en Amérique du Sud.

Alors que le pape saluait les foules de sympathisants, un projectile – un chapelet offert en guise de cadeau – l'a accidentellement atteint, provoquant une vive inquiétude parmi son service de sécurité et les spectateurs rassemblés.

Cet incident s'est déroulé sur fond de voyage missionnaire hautement significatif.

Tout au long de son séjour en Amérique latine, le pape Léon s'est concentré sur la diffusion d'un message de compassion, de justice sociale et de renouveau spirituel.

Sa tournée a été marquée à la fois par de grandes célébrations publiques et par un engagement politique sérieux.

Notamment, lors d'une étape à Pucallpa, le pape a pris position contre la violence, dénonçant publiquement le meurtre récent de 37 dirigeants amazoniens.

Sa visite a été largement interprétée comme une réaffirmation de l'engagement de l'Église envers les communautés marginalisées de la région.

Malgré le malheureux accident survenu lors du défilé, la tournée du pape a été globalement caractérisée par sa nature historique et par le lien profond qu'il a tissé avec les populations locales.

Les médias ont largement documenté le voyage, mettant en contraste les efforts diplomatiques du pape et les moments humains, parfois chaotiques, qui accompagnent souvent ces événements publics de grande envergure.

L'incident du chapelet, bien qu'alarmant, n'a pas éclipsé l'impact plus large de sa visite, que de nombreux analystes considèrent comme une revitalisation de l'esprit missionnaire de son pontificat.

Les équipes de sécurité devraient réexaminer les protocoles entourant les apparitions publiques du pape à la suite de cet incident.

Bien que le lancement d'objets religieux soit souvent une expression de dévotion dans les cultures catholiques, le risque physique encouru par le souverain pontife rappelle les défis inhérents à la gestion de foules massives.

Alors que le pape Léon achève sa tournée sud-américaine, l'attention demeure fixée sur la portée de ses paroles et sur les ponts diplomatiques qu'il a tenté de bâtir à travers tout le continent, marquant durablement les esprits des fidèles et des observateurs internationaux.

Source: New York Post
