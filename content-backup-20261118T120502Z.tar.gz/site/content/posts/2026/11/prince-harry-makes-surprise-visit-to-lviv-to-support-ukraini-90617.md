---
title: "Prince Harry Makes Surprise Visit to Lviv to Support Ukrainian Veterans"
date: 2026-11-15T22:00:24Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://www.theguardian.com/uk-news/2026/nov/15/prince-harry-ukraine-war-surprise-trip-invictus-games"
source_name: "The Guardian World"
image_url: "https://i.guim.co.uk/img/media/082248113d66f00317e3a188a707a740b59e16b9/191_193_2669_2135/master/2669.jpg?width=140&quality=85&auto=format&fit=max&s=ec896eb5e828c19c1a39e8a6177db095"
draft: false
---

In a surprise diplomatic and humanitarian gesture, Prince Harry, the Duke of Sussex, traveled to the Ukrainian city of Lviv this past weekend. The visit, which was kept under wraps until his arrival, saw the Prince meeting with wounded veterans and medical personnel to offer his support for those affected by the ongoing conflict with Russia.

<!--more-->

During his visit, Prince Harry participated in a conference focused on the treatment and rehabilitation of war-injured individuals. Addressing the attendees, the Duke offered a message of hope, stating his belief that Ukraine is 'going to win the war.' His presence in the western Ukrainian city was intended to highlight the resilience of the Ukrainian people and to draw international attention to the long-term medical needs of those who have served on the front lines.

Prince Harry also floated the idea that Ukraine could one day serve as a host nation for the Invictus Games, the international sporting event he founded for wounded, injured, and sick service personnel. He described the trip as a risk, given the current security situation, but emphasized that he felt a deep sense of 'warmth' upon his arrival. His interactions with the veterans were described as deeply personal, with the Prince listening to their stories of survival and recovery.

The visit has been viewed as a significant show of solidarity from a high-profile member of the British royal family. While the Duke has stepped back from his senior working royal duties, his commitment to veteran causes remains a cornerstone of his public work. By visiting Lviv, he has brought a renewed focus to the human cost of the conflict, particularly regarding the specialized care required for soldiers who have suffered life-altering injuries. The Ukrainian government and local officials welcomed his visit as a morale booster for both the military and the civilian population.
