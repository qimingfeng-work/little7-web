---
title: "「關渡海潮」無人機表演引發熱議，意外捲入臺北市長選戰攻防"
date: 2026-11-17T01:38:00Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiSEFVX3lxTFAzQWM5UzlYUFBsUkVoLTdRa25KcFdzLXdIZGFhZ1U2RzhleEs1aXVaS1ZxSUVKeFAtTGxZblZ1YUtJbG1iUnlaTtIBTEFVX3lxTE11SUpYeGhUX0FieUJaczB6WHgxZGdoUzJTcnJVY1ZOdGZ4RXE2NmloVlcyX0p4T1F3RWFaQkI3bzV0VWRnbTJES0FMLVU?oc=5"
source_name: "三立新聞網SETN.com"
draft: false
---

近期一場名為「關渡海潮」的無人機表演吸引了廣大公眾目光，並迅速成為臺北市長選戰中的熱門話題。這場大規模的空中展演由數百架無人機協同演出，吸引了大量群眾圍觀並獲得媒體廣泛報導，但也引發了關於其組織與資金來源的政治爭議。

<!--more-->

來自醫療與政治界人士的幕後評論，為該活動增添了更多懸疑色彩，公眾討論焦點集中在沈伯洋（Puma Shen）等關鍵政治人物的參與上。

儘管主辦單位將即將到來的「臺北海潮嘉年華」宣傳為慶祝城市文化與社群參與的活動，但競爭對手的陣營迅速利用此表演，針對競選策略、政治品牌以及現代選舉中巨額財務資源的使用進行辯論。

現任官員與競爭候選人對此回應，強調應重視具體的市政成就與基層經營，而非高科技的政治造勢。隨著多位政治重量級人物紛紛出面支援各自候選人，以迎接即將到來的選舉決戰，圍繞無人機表演的爭議，反映了定義當前選戰的激烈競爭與創新競選策略。

com
