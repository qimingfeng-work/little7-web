---
title: "Yemeni Government and Houthis Exchange Accusations Following Deadly Taiz Market Strike"
date: Sat, 07 Nov 2026 06:53:26 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiswFBVV95cUxQWUFFT1gtN2l4YndNOENnbWhZbE84UWpJM0dsWU1CNzJQbjRFTWZIZFh0b01wb0QxUTVleklRZWVJaEgxcExlVWhDWFFVMEVIaFZhVHF4S3RQOFZTRnNQWXRHRGY4VTZLZkc1Z3hFQVkxTHN6S0hheURfZFJaTjRKdjRlclpwQnU4cDhSNXJCR1RuOVl0N3k5Vlc1Qkt3dGhNY1FMNFhYaXlHRmFsZ0hva0hjRdIBuAFBVV95cUxNUWFDV1ZCNEtVOHVHWXVQbVctNEhueXlfazF3cHk5UnBIWWhLU01wN1UtZTNwcllVdWw5NGpFY2tzcEJDMXIyRXktYVJkcjc1NlV0MndQYnB1a3dHd3Ixc0VqeHNCLXQzc1dUaGpycklSdjNDZ2RfNEs3U1l2Z29NMGVUVFk5cFNRdWhtdjZSa0Zva29tZE5Od3FuOHFVdWVfWnRnZTlIUVFzUlVZcEk5ZnJCUGhtdjNB?oc=5"
source_name: "Al Jazeera"
draft: false
---

A wave of violence has struck a market in Taiz, Yemen, resulting in significant casualties and sparking a fierce war of words between the internationally recognized government and Houthi rebels. Both sides have traded blame for the deadly strikes, which have once again highlighted the devastating human cost of the ongoing conflict in the region.

<!--more-->

Initial reports from Houthi-affiliated health officials suggest that at least 33 people were killed in the incident, with many more suffering from severe injuries. The Houthis have accused a Saudi-led coalition air strike of targeting the civilian area, labeling the event a massacre. Conversely, Yemeni government forces have denied these allegations, instead pointing to Houthi shelling as the cause of the destruction. They have also reported recent military advances in other areas, claiming that the Houthi narrative is a diversionary tactic aimed at masking their own failures on the battlefield.

The international community has expressed alarm over the incident, with humanitarian organizations calling for an immediate investigation into the strike. The tragedy in Taiz is just the latest in a series of escalations that have plagued Yemen for years, leaving millions in need of aid and facing the threat of famine. As the blame game continues, the civilian population remains caught in the crossfire, with little hope for a lasting ceasefire in the near future. The conflicting reports from both sides make it difficult to ascertain the exact circumstances of the strike, but the loss of life is undeniable and serves as a grim reminder of the urgency for a peaceful resolution to the Yemeni crisis.
