---
title: "Victoire d'Everton et polémique persistante autour de l'arbitrage vidéo en Premier League"
date: Fri, 06 Nov 2026 23:42:06 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiiwJBVV95cUxPVGItRzhvR19EMlI3QmRXRkg3Z2tEMklyRkEtcGN5Mmt3MnFNUWtIY1pKSVNSU3BkUHlIVkRXajFQcC13V1RrSVVGUjFaM3ByMTNtN3hJNjM3TmRTR1FMZS1HRERnTmZaS0VmQ1NzaHFENldPSHFVR3kzdjZhN3Z2dnoyWVRaUWxnOW9qT0x3M01oS0lMdDVpUVNMdXFVemxTbnNYem91ODVCQnllSEFwdDcyTHRYekxxaC1RTGJOUlZXbVF6SGxCTk9mUHlhR1VobXRQdjM4Qnd0LTB2c0pxTXZ5U3lKaTJHVVlDbzFFSXAwRkp5bkdBX0s5RDE1bWJtSTRxb0lPUi0xbDQ?oc=5"
source_name: "Sky Sports"
draft: false
---

Everton a récemment arraché une victoire convaincante de 3 buts à 1 face à Coventry City lors d'une rencontre de Premier League, mais le match a été totalement éclipsé par une intense controverse entourant le système d'assistance vidéo à l'arbitrage (VAR).

<!--more-->

L'entraîneur d'Everton, Frank Lampard, a exprimé sa vive frustration après le coup de sifflet final, affirmant que le corps arbitral n'avait pas rempli ses fonctions avec l'efficacité requise.

Selon Lampard, au moins trois incidents cruciaux ont joué en défaveur des « Sky Blues », impactant directement le rythme et l'issue de la partie.

Les griefs formulés par Lampard ont trouvé un écho auprès de divers observateurs, bien que les avis concernant l'impact réel de ces décisions demeurent partagés.

Si le technicien d'Everton estime que son équipe a pâti d'un arbitrage défaillant, d'autres voix, dont l'ancien entraîneur d'Everton David Moyes, ont offert un point de lecture différent, rejetant l'idée que les officiels soient les seuls responsables du résultat final.

Ce débat met une fois de plus en lumière les difficultés persistantes auxquelles fait face la Premier League dans l'application de la VAR, les critiques estimant que l'outil technologique engendre souvent plus de confusion que de clarté.

Dans la foulée de la rencontre, la Premier League a publié un communiqué explicatif concernant le but litigieux inscrit par Thierno Barry, s'efforçant de justifier la procédure décisionnelle adoptée.

Malgré cette mise au point, les discussions post-match se sont principalement focalisées sur les incohérences perçues des arbitres assistants vidéo.

L'analyse détaillée du match suggère que si l'arbitrage a indéniablement pesé dans les débats, il serait réducteur d'imputer l'unique responsabilité du score aux officiels.

Néanmoins, cet épisode a ravivé le débat de fond sur la place de la technologie dans le football moderne et sur sa capacité réelle à garantir l'équité sur le rectangle vert.
