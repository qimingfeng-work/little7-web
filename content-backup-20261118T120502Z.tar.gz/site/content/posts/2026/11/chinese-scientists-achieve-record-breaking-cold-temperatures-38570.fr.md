---
title: "Percée scientifique : la Chine crée la matière la plus froide jamais enregistrée dans l'espace"
date: Thu, 05 Nov 2026 23:34:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMifEFVX3lxTFBQMXA2QjhyR2lyUzNjbUtRMDlNV0d4NVMtdnRMMWNnWDlOZ0pzUE1vNTdsVTJSbFVYbmkyQk5rX3NRRjhkWGdOS1VYTHFsRm5Vem9NV25YcjlHS2h6dkZPRF9qTFpTN1FUeTV5MVNKNHRQUGlTTjR6dGFka3Q?oc=5"
source_name: "杭州新闻"
draft: false
---

Dans une réalisation révolutionnaire pour la physique expérimentale, des scientifiques chinois ont réussi à créer la matière artificielle la plus froide jamais enregistrée, en tirant parti de l'environnement unique de la station spatiale chinoise Tiangong.

<!--more-->

Cette expérience, qui repousse les limites de la thermodynamique, marque un bond en avant significatif dans l'étude des gaz quantiques et de la physique atomique ultra-froide.

En exploitant les conditions de microgravité du laboratoire en orbite, les chercheurs ont pu refroidir des atomes à des températures jusqu'ici inaccessibles sur Terre.

Dans un environnement sans gravité, les atomes peuvent être manipulés et observés pendant des durées prolongées sans l'interférence de la sédimentation gravitationnelle.

Cela a permis la formation d'un condensat de Bose-Einstein à des températures record.

Cet état de la matière, où les atomes se comportent comme une entité quantique unique, offre une fenêtre rare sur les lois fondamentales de l'univers.

L'expérience a été menée à l'aide d'équipements spécialisés conçus pour isoler les atomes du bruit thermique externe.

Le succès de cette entreprise démontre non seulement la maîtrise technique avancée du programme spatial chinois, mais souligne également l'importance des installations de recherche basées dans l'espace pour mener des recherches scientifiques fondamentales impossibles à reproduire dans des laboratoires terrestres.

Les données collectées pourraient conduire à des avancées majeures dans la mesure de précision, l'informatique quantique et le développement de capteurs ultra-sensibles.

La communauté scientifique mondiale a salué cette réussite comme une étape majeure.

Alors que les chercheurs continuent d'analyser les données, l'attention se porte désormais sur la manière dont ces états ultra-froids peuvent être utilisés pour tester les théories de la gravité et de la matière noire.

Cette réalisation consolide la position de la Chine en tant qu'acteur clé sur la scène scientifique mondiale, prouvant que la station spatiale n'est pas seulement une plateforme d'observation, mais un laboratoire sophistiqué pour la recherche physique de pointe.
