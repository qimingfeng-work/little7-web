---
title: "Supreme Court Maintains Injunction Against DEI Grant Defunding"
date: 2026-11-16T19:54:21Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://arstechnica.com/science/2026/11/supreme-court-keeps-injunction-against-dei-grant-defunding-in-place/"
source_name: "Ars Technica"
image_url: "https://cdn.arstechnica.net/wp-content/uploads/2026/11/GettyImages-2302915568-1024x648.jpg"
draft: false
---

The United States Supreme Court has decided to keep an injunction in place that prevents the cancellation of diversity, equity, and inclusion (DEI) grants. This legal development follows a lower appeals court ruling that previously determined the termination of these grants violated First Amendment protections. The case centers on the tension between government funding policies and the constitutional rights of organizations that promote DEI initiatives.

<!--more-->

Legal experts note that the Supreme Court's decision to uphold the injunction serves as a significant hurdle for those seeking to defund such programs. The appeals court had previously reasoned that the government cannot arbitrarily strip funding from organizations based on their ideological focus if that focus is protected under free speech principles. By refusing to intervene at this stage, the Supreme Court effectively allows the lower court's reasoning to stand for the time being, ensuring that the grants remain active while the litigation continues.

This ongoing legal battle highlights the broader national debate regarding the role of DEI programs in public and private institutions. Proponents of these grants argue that they are essential for fostering inclusive environments and addressing historical inequities. Conversely, critics argue that such programs can lead to discriminatory practices or promote specific political agendas with taxpayer money. As the case moves forward, the judiciary will likely need to provide more definitive guidance on how the First Amendment applies to government-funded diversity initiatives. For now, the injunction provides a temporary reprieve for the affected organizations, maintaining the status quo as the legal process unfolds.
