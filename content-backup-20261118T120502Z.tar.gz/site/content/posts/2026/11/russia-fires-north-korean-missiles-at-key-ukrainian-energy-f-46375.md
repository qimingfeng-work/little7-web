---
title: "Russia Fires North Korean Missiles at Key Ukrainian Energy Facility, Says Zelenskyy"
date: Sat, 07 Nov 2026 14:45:17 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiugFBVV95cUxOTjZnZ0pEb3luTzdrRnBmT01PUHNWMGNwbmNTRVpfdUhhRmNZY0JZTDNrOGh6N3JJaWNBdDFlSklNcW14UHh6Z2FTbjlEU0pFaFUtYUlMZVUyRjYxZ1RyLTFJRFBQTm5MSkoxSzE3M1lnSGM0T0FiTVBoekF6YjZmakVDNTNTaGVteDY1bG5jSDVKWkZvMlZWdkJDZGpXRnJUMjBEWjNpVC1OeEk0dTM4amxDdGQzVmIwY3c?oc=5"
source_name: "Euronews.com"
draft: false
---

Ukrainian President Volodymyr Zelenskyy has reported that Russian forces utilized North Korean-supplied missiles in a targeted assault against a critical energy facility in Ukraine. The overnight aerial bombardment caused substantial destruction to the country's power infrastructure, resulting in widespread blackouts and emergency water shortages in the capital city of Kyiv and surrounding regions. International monitors have expressed deep concern over the ongoing intensification of strikes targeting civilian utility networks.

<!--more-->

The recent barrage has further strained Ukraine's already vulnerable electrical grid as winter approaches, compounding the humanitarian challenges faced by local residents. Emergency repair crews have been deployed across affected areas, though officials warn that restoring full capacity will require considerable time and resources. Foreign allies have repeatedly condemned these infrastructure attacks, viewing them as an explicit strategy to erode civilian morale through freezing conditions.

Amid these developments, defense analysts have highlighted the growing military cooperation between Moscow and Pyongyang, noting the deployment of foreign-manufactured ballistic missiles on the European battlefield. As Ukraine continues to appeal for advanced air defense systems, the international community remains focused on mitigating the severe humanitarian impacts stemming from the systematic degradation of the nation's energy grid.
