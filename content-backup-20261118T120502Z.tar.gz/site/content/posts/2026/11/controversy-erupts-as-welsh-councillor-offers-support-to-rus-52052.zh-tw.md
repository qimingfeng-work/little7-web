---
title: "威爾士議員公開呼籲喜劇演員羅素·布蘭德“堅持住”引發強烈眾怒"
date: Sat, 07 Nov 2026 15:17:26 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMipwFBVV95cUxObm9yTmt1ME85NkJUWmJVQWtxaDZvcG9CQWRtT0xnSGZWTTFGNTVlc1lXRl96Z1ZIdUMwVzdzdDVKQmsxcGhOU2pPb0FtdEIzY2NSY25TYjM3Y3lPN3lYY1VrN1hGV0h6UV9OdWRDZHNCMHJZZ0tCVXJLeFk4ZXJuMEtDSzc5X2xNeGp2ZDlzdFBlU2gzSDBqcU9GRlFBQUcyWklMWUdFSQ?oc=5"
source_name: "South Wales Argus"
draft: false
---

在喜劇演員羅素·布蘭德（Russell Brand）最近因強姦罪被定罪之後，一名威爾士地方議員公開敦促其“堅持住”，這一言論引發了廣泛的憤怒和譴責。

<!--more-->

在法院做出認定布蘭德犯有嚴重性犯罪的法律判決之後，該議員的言論立即遭到同行政治家、維權組織以及廣大公眾的尖銳批評。這一事件重新點燃了關於公眾人物及權威人士應如何回應性暴力案件的更廣泛社會討論。

這名議員的言論被普遍譴責為對受害者的不敏感，並涉嫌貶低司法公正程式的嚴肅性。為了回應這一猛烈抨擊，許多人呼籲重新評估該議員的政治判斷力以及他是否還適合擔任公職。

羅素·布蘭德案已經成為媒體和娛樂行業內部開展深入反思的一個引爆點，許多人呼籲採取“零容忍”的態度來應對虐待行為並追究加害者的責任。

媒體界的知名人士，包括凱瑟琳·瑞安（Katherine Ryan），公開談到了在有罪判決出臺後人們感受到的“悲傷與如釋重負”，並強調了支援倖存者和確保正義得以伸張的重要性。

與此同時，政府部長們警告稱，行業必須更加嚴肅地對待針對虐待行為的指控，並暗示布蘭德案應當成為推動系統性變革的催化劑。圍繞這名威爾士議員的爭議再次提醒人們，關於責任追究和受害者支援的討論遠未結束，民選官員的公開言論在公眾輿論的法庭上具有舉足輕重的分量。

背景補充：羅素·布蘭德作為英國知名的喜劇演員、主持人和演員，近年來的法律糾紛和性侵指控在英國社會引發了巨大的輿論震動。此案不僅關乎個人犯罪的法律審判，更觸及了演藝界權力結構、性騷擾防治以及公眾人物道德底線的深層社會議題。
