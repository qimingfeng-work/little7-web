---
title: "BBC 調查記者追蹤到議會醜聞核心人物，現身布加勒斯特高階公寓"
date: 2026-11-17T06:20:16Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://www.bbc.co.uk/news/articles/c6205wpv2g81o?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
image_url: "https://ichef.bbci.co.uk/ace/standard/240/cpsprodpb/081f/live/8c9ba410-e1d5-11f1-b8c8-67fa35f5afdb.png"
draft: false
---

BBC 的調查記者近日成功追蹤到與一樁備受矚目的議會醜聞相關的核心商人，並在布加勒斯特市中心的一處高階且戒備森嚴的公寓大樓內發現了他的蹤跡。這一突破性進展為這場在過去幾個月中引起公眾高度關注與媒體廣泛報導的財務爭議，帶來了新的發展。

<!--more-->

該名被確認為利亞姆·卡瓦納（Liam Kavanagh）的男子，先前在外界對其參與爭議性議會交易的質疑聲中，一直設法躲避公眾視線。記者在該高檔住宅區埋伏多日，最終確認了他的行蹤，這隨即引發了政界人士與調查人員對於責任歸屬與透明度的新一波呼籲。

隨著布加勒斯特目擊事件的細節曝光，當局正在權衡針對議會醜聞進行更廣泛調查的下一步行動。BBC 團隊的發現不僅揭露了卡瓦納目前的藏身處，也加大了法律與市政機構的壓力，要求其必須針對爭議性的財務交易給出明確交代。
