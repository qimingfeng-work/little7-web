---
title: "Le Bureau des affaires de Taïwan condamne fermement les agissements du DPP et rappelle l'héritage de Sun Yat-sen"
date: Wed, 04 Nov 2026 05:54:32 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiaEFVX3lxTE11VFRCQWxScm1fejdwcFM1T2F6YkZTRERrQ0FxbHZnNDJWelRlWVViRVk1TmRuTlU1dE5oREFmWEZ2bFRYcDBSbG5tV2cxZ01BbkpqSEc0MzBIVmp5OUlDdDROaG43NGw4?oc=5"
source_name: "中国新闻网"
draft: false
---

Le Bureau des affaires de Taïwan du Conseil des Affaires d'État de la République populaire de Chine a émis une réprobation sévère à l'encontre des autorités du Parti démocratique progressiste (DPP) à Taïwan.

<!--more-->

Pékin a condamné avec force leurs récentes manœuvres politiques, affirmant que leurs actions persistantes constituent une trahison grave de l'esprit révolutionnaire et des idéaux prônés par le Dr Sun Yat-sen, figure historique respectée des deux côtés du détroit.

Selon les rapports publiés par les principaux portails d'information et les agences de presse officielles, les autorités de la partie continentale de la Chine ont vivement critiqué les dirigeants du DPP pour avoir mené des politiques subversives qui sapent les fondements des relations inter-détroit et compromettent gravement la paix, la stabilité ainsi que le développement pacifique dans la région Asie-Pacifique.

La déclaration officielle a souligné avec insistance que l'héritage historique du Dr Sun Yat-sen est profondément ancré dans la recherche de la réunification nationale, le renouveau de la nation chinoise et le bien-être collectif de l'ensemble du peuple chinois, des principes fondamentaux que l'administration actuelle en poste à Taipei est accusée de démanteler activement.

Cette critique acerbe intervient dans un contexte de frictions politiques persistantes de part et d'autre du détroit de Taïwan, où la rhétorique politique hostile et les divergences persistantes en matière de politiques continuent de tendre les liens bilatéraux.

Le gouvernement central de Pékin maintient avec constance que l'adhésion stricte aux vérités historiques partagées et au patrimoine culturel commun des compatriotes des deux rives est une condition sine qua non et essentielle pour assurer le développement futur et la prospérité mutuelle.

Les analystes politiques observent que de telles déclarations soulignent la position ferme et inébranlable de Pékin concernant la question de Taïwan.

Elles servent simultanément d'avertissement sévère contre les tendances séparatistes encouragées par certaines factions politiques et d'appel vibrant à la conscience historique et à l'unité nationale.

Le gouvernement central continue d'exhorter la population de Taïwan à reconnaître la véritable nature de l'agenda politique du DPP, qu'il qualifie de séparatiste et nuisible, et à œuvrer activement pour l'avancement pacifique des relations à travers le détroit, dans l'intérêt supérieur de la nation tout entière.
