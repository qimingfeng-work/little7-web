---
title: "« Godzilla Minus Zero » bat des records au box-office mondial"
date: Sun, 08 Nov 2026 16:21:19 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMirwFBVV95cUxOcjRfLWVsVWt1VzExRzBrMHRScUxQR2NRalhlTXhJQnNBdW1RSzN1dHNBc3FwRGs1RUpub0lzLTlFaFNUclkxUU9jbnZCYTZZZVdpc3NMNzc3NHpxTmVwSngyaGxXcnFzdXg3cWhnbkU2Y1NaUTdCbkJoY195ajhWN3FqYllueUVTZXMzRGNTNnl1OG40NmhHbVBXMExmM3ZleVYzUzZ3ZVJ2bXVhazRJ?oc=5"
source_name: "IndieWire"
draft: false
---

Le box-office mondial a un nouveau recordman : « Godzilla Minus Zero » a fait une entrée fracassante dans les salles avec un début époustouflant de 31,6 millions de dollars.

<!--more-->

Ce week-end d'ouverture phénoménal marque le meilleur démarrage jamais enregistré pour un film en langue étrangère en prises de vues réelles, pulvérisant les références précédentes de l'industrie et captivant les publics en Amérique du Nord et au-delà.

Les observateurs de l'industrie du divertissement, dont IndieWire et Deadline, ont rapporté que le film a largement dépassé les projections initiales, écrasant ses concurrents nationaux et laissant d'autres sorties majeures dans son sillage.

Les critiques ont loué le film pour son récit captivant, ses effets visuels époustouflants et un retour rafraîchissant aux racines terrifiantes du monstre emblématique, obtenant ainsi un succès critique à la hauteur de son triomphe commercial.

Les critiques de cinéma de publications telles que le Washington Post et Forbes ont noté que l'attrait universel du film a permis d'introduire le légendaire kaiju à une nouvelle génération de cinéphiles tout en satisfaisant les fans de longue date de la franchise.

Ce succès financier remarquable souligne un appétit croissant parmi le grand public pour des récits internationaux diversifiés sur grand écran.

Le film prouve que les barrières linguistiques ne sont plus un frein lorsque la qualité cinématographique et l'impact émotionnel sont au rendez-vous.

Avec une dynamique de bouche-à-oreille stellaire et une forte rétention dans les salles, « Godzilla Minus Zero » est idéalement positionné pour une exploitation lucrative sur le long terme.

Les experts de l'industrie surveillent désormais de près combien de temps le film de monstre pourra maintenir sa domination au box-office dans les semaines à venir.

Ce succès pourrait ouvrir la porte à davantage de productions internationales ambitieuses sur le marché nord-américain.
