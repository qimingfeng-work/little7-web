---
title: "Le représentant Thomas Massie lance une procédure de destitution contre le secrétaire à la Défense Pete Hegseth"
date: Mon, 09 Nov 2026 20:51:20 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMipwFBVV95cUxOQndiNU9ORkE4ZnY0dDFUTjQtakNmOV9PQ0JGVWxGVVBLOW11UkllaGFlekwwOXpJUjE4dFpWdmxTMkVMQkN0UGZuaVNMbTZIcUdENHRVUlFLN1BqUTZIN1RKVmIyZC03UW9JeDdraHVuQUhCUTl1TWR1UjVra3c4WkQwRVc5UjloTVZFMlloQU1maWVUb2RtdlU5NERzLXU0Vmd1Q1JZbw?oc=5"
source_name: "Sky News"
draft: false
---

Le représentant Thomas Massie a pris des mesures formelles pour forcer un vote sur la destitution du secrétaire américain à la Défense, Pete Hegseth.

<!--more-->

Cette décision marque une escalade significative dans les frictions politiques internes au sein du Parti républicain, alors que plusieurs législateurs ont commencé à critiquer ouvertement le leadership et la conduite de Hegseth.

La pression pour la destitution a gagné du terrain ces derniers jours, divers rapports indiquant que le secrétaire à la Défense fait face à une pression croissante des deux côtés de l'allée.

Les articles de destitution introduits par Massie se concentrent sur des allégations qui ont fait surface concernant le mandat de Hegseth.

Bien que les détails spécifiques des accusations restent un sujet de débat intense, la décision elle-même signale une rupture claire dans l'unité du parti.

Pour beaucoup, ce développement est considéré comme une sorte de « jour J » pour Hegseth, car son avenir politique est désormais en jeu.

L'introduction de ces articles force la Chambre à aborder la question, ce qui pourrait conduire à un vote en séance plénière controversé qui pourrait avoir des implications considérables pour l'administration actuelle.

Les analystes politiques suggèrent que cet effort reflète des divisions plus profondes au sein du caucus républicain concernant les priorités de défense et la surveillance des fonctionnaires de la branche exécutive.

Alors que certains membres du parti se sont ralliés pour soutenir Hegseth, d'autres estiment que les allégations sont suffisamment graves pour justifier une enquête formelle.

Au fur et à mesure que la situation se déroule, l'accent sera mis sur la capacité de Massie à obtenir suffisamment de soutien pour faire avancer le processus de destitution ou si la direction interviendra pour supprimer le vote.

L'issue de ce défi définira probablement le paysage politique pour le reste du mandat.
