---
title: "UFC 334 Aftermath: Josh Hokit Reveals Vision Issues Following Controversial Bout"
date: 2026-11-16T04:51:20Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMirgFBVV95cUxPU1VMNXhzQ3k1d1l1NE90ckl3d0NQVUlkOGFXREEwYTU5ZmVUYWh3Vkxka2pBT210UXZHaGsxS0poZmpfb3gtT0xhYjJPbnE4bG90TzdtR0dCRkxOb2ZITFVnTmtzUExULWtoY3N6NWNWTzdnb2tlQklfNWdrQV9paXhadVAxb0VkNDk2NDUtb3Vmb2FqTHg5VzhiNk9tN1FDY04xaFdONVhuQ2Z1TnfSAbMBQVVfeXFMTW10ejd0ZGo1TE9xU1B6LURyVzhLQ1AwbFNwY2tXTkJGaTh0WEw0V2tzSXJQN0ttdExqZXMzNk15bjhYemtFYVNWSjA3ejBZZm51RXVxX19lSDZOR3FvWmQ3c0ZNY2Q2M0pEdWk1dHU2OEVoYnVJeEhTanFlaXdENHdoY2dkWTV6elpmOGl2SzlUQ3BjRUZsdlh2ekVmelp4QW9oeVlWQkJTT0xlYTBNY2RQZk0?oc=5"
source_name: "Sherdog"
draft: false
---

The aftermath of UFC 334 has been dominated by a bizarre and concerning revelation from the camp of fighter Josh Hokit. Following his high-profile bout against Ciryl Gane, teammates of Hokit disclosed that the fighter had been suffering from significant vision impairment during the match, specifically claiming that he was 'seeing triple' for the duration of the fight.

<!--more-->

This impairment was reportedly the result of an early eye-poke sustained during the opening exchanges of the contest. The incident has sparked a wave of discussion regarding officiating and the impact of such fouls on the outcome of professional bouts. Hokit himself has since spoken out, calling for a rematch against Gane, arguing that the injury prevented him from competing at his full potential and fundamentally altered the competitive balance of the fight.

While the official results of UFC 334 have been recorded, the controversy surrounding the eye-poke has cast a shadow over the event's main card. Medical reports from the hospital following the fight have corroborated the severity of the injury, adding weight to the calls for a reconsideration of the result. As the UFC brass reviews the incident, the case of Josh Hokit highlights the ongoing challenges of managing fight-ending fouls and the difficult decisions that follow when a contest is marred by accidental, yet fight-altering, injuries.
