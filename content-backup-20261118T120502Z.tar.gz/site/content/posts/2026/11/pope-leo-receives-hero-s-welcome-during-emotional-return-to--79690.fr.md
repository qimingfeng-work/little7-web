---
title: "Le voyage émouvant du Pape Léon à Chiclayo : une ferveur populaire incommensurable au Pérou"
date: 2026-11-13T18:34:45Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiW0FVX3lxTE1ydHBPajVWOFRBNFZIbTh2UzRDdy1UUTZWSkNwUHVKYmVoOVVjUHJKV2d6M0V1X1pOUmZTalZ2djItczRMQU10cDhaZXk2MTVjaVI0Ukl6N1hFNU0?oc=5"
source_name: "BBC"
draft: false
---

Le pape Léon a récemment entamé un pèlerinage empreint d'émotion vers la ville péruvienne de Chiclayo, une localité où il a autrefois exercé les fonctions d'évêque et où il conserve une immense popularité auprès de la population locale.

<!--more-->

Cette visite a été marquée par des foules considérables, avec une estimation de près de 1,5 million de personnes rassemblées pour saluer le souverain pontife, que de nombreux résidents considèrent comme l'un des leurs.

L'atmosphère était à la célébration fervente et au recueillement spirituel, alors que le Pape renouait avec la communauté qui a grandement façonné ses débuts dans le ministère.

Au cours de son séjour, le pape Léon a exprimé sa profonde gratitude envers les habitants de Chiclayo, remerciant Dieu pour l'opportunité qui lui était donnée de retourner sur ce qu'il a qualifié de sa « seconde patrie ».

Dans ses allocutions, il a insisté sur la centralité de la foi et sur le lien intime unissant Jésus aux fidèles, déclarant aux foules que le Christ « connaît votre histoire et continue de vous inviter à marcher à Ses côtés ».

Ses paroles ont résonné avec une rare intensité parmi l'assistance, dont beaucoup suivent le parcours de près depuis son époque d'évêque local.

L'ampleur de cet accueil chaleureux a mis en lumière l'aura indéfectible du Pape en Amérique latine, une région qui demeure un bastion névralgique pour l'Église catholique.

Les autorités locales et les riverains avaient œuvré pendant des mois pour préparer cet événement, veillant à ce que la logistique puisse absorber les millions de pèlerins venus des quatre coins du pays pour apercevoir le leader religieux.

Cette visite s'est avérée bien plus qu'un pèlerinage spirituel : elle a incarné un moment culturel capital pour la cité, qui revendique l'héritage du pontife avec une immense fierté.

Les observateurs ont souligné que ce déplacement rappelait avec force la capacité du Pape à jeter des ponts entre le Vatican et le quotidien de ses fidèles.

En retournant dans une ville où il a exercé des responsabilités pastorales de terrain, il a réaffirmé son image de dirigeant ancré dans le réel.

Les scènes poignantes de Chiclayo resteront sans doute gravées comme l'un des sommets de son pontificat, témoignant des liens viscéraux qu'il entretient avec les communautés du monde entier.
