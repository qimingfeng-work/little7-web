---
title: "Un candidat aux élections locales à Taïwan au cœur de la tourmente suite à de graves allégations"
date: 2026-11-17T08:45:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiV0FVX3lxTFBzRE5VRDQ0VWZOQnpTcVE3aE43bnZNSEdybEYybGhqMWNYUk5CaC1zYldLRnJ1RnNpMmFGaTVyRHpRS3gwYkF2d3JvMzFGckpaX0tRcGJpbw?oc=5"
source_name: "東森新聞"
draft: false
---

Un candidat à un conseil local, Gu Zhen-feng, fait actuellement l'objet d'un examen public intense à la suite d'une série d'allégations graves concernant sa conduite passée.

<!--more-->

Des rapports ont fait surface l'accusant d'implication dans une affaire qui aurait entraîné la mort d'un lycéen, ainsi que d'autres réclamations distinctes concernant un incident impliquant un mineur.

La gravité de ces accusations a jeté une ombre sur sa campagne, entraînant des appels généralisés à la responsabilité et des enquêtes sur son éligibilité à une fonction publique.

Face à la pression croissante, l'épouse de Gu l'a publiquement défendu, apparaissant dans des entretiens chargés d'émotion pour plaider afin que le public donne à son mari une « seconde chance ».

Elle a constamment maintenu son innocence concernant les accusations les plus graves, bien que le candidat lui-même ait reconnu une condamnation passée liée à une infraction sexuelle pendant son service militaire.

Il a cependant nié avec véhémence toute implication dans des activités liées à la drogue ou dans la mort du lycéen mentionnée dans les récents reportages des médias.

Les experts juridiques se sont penchés sur la situation, notant que si le candidat devait être reconnu coupable de certaines accusations liées à la drogue, cela pourrait potentiellement le disqualifier pour se présenter aux élections en vertu de la loi sur l'élection et la révocation des agents publics.

La Commission électorale de la ville de Taoyuan a déclaré qu'elle suivait la situation de près, attendant de nouveaux développements juridiques avant de prendre une décision formelle sur sa candidature.

À l'approche des élections, la controverse continue de dominer les gros titres locaux, les électeurs exprimant leur inquiétude quant au processus de vérification des candidats politiques et aux normes morales attendues de ceux qui cherchent à représenter le public, tout en soulignant la complexité du paysage politique actuel à Taïwan et l'importance de la transparence institutionnelle.
