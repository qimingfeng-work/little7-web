---
title: "利亞姆·勞森因技術違規在墨西哥城大獎賽排位賽中被取消成績"
date: Sun, 01 Nov 2026 03:09:02 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiaEFVX3lxTE9vYWlfTXk0WHZqdXVCQWM1Nkk1VElSZGNaMFZnZDA1SllmZ09ocHA5QjV4RWk0bHJBaDRiWkhic3oyM0kwXy1LcnpkeHB4TUR1M0Voa1dzZHhjdkRnaEs5bkVUdXYwSFJV?oc=5"
source_name: "中國新聞網"
draft: false
---

在墨西哥城大獎賽排位賽前，利亞姆·勞森因車輛違反技術規則，被賽事幹事取消了排位賽成績。賽事官員在賽後檢查中發現其車輛不符合嚴格的技術準則，因此決定抹除其所有單圈時間。

<!--more-->

這對勞森本就艱難的週末賽程雪上加霜，他此前還因程式性違規受到發車順位罰退。由於這些處罰，勞森將不得不從車隊後方出發，在正常比賽條件下獲得積分的機會變得極度渺茫。

車隊工程師對此次疏忽表示失望，並指出賽事監管框架不容忽視。此次事件也凸顯了賽車運動在合規性上的嚴格與殘酷。
