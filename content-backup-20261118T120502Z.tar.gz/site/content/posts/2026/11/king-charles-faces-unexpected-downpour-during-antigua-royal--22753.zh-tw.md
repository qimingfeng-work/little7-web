---
title: "英王查爾斯三世安提瓜訪問突遇暴雨，詢問雨傘下落引熱議"
date: Mon, 02 Nov 2026 01:10:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiowFBVV95cUxONlZTcmI4NTlSZ0hOSnJwdkFxcHM1Q3VjNDFIVDlyTDVmdEFjVXJSd3FneU5LSTFxRUtGbEJXM0JlV21Nd2Y3Qm9HODRtb1FGSTYxZERHWXpoN1VXT3ctYlFLb3B4aFZPNHNZekxQRURzeXY2eXNjY3VGZ1VoRzhaOUhqb1dkcG0zZUZkRTNhTFR1VzlGQW4xYTRuTHRPc09GaDV3?oc=5"
source_name: "The Telegraph"
draft: false
---

在近期對安提瓜的一次皇室出訪中，查爾斯三世國王遭遇了一場突如其來的暴雨，導致場面一度尷尬而滑稽。當國王站在雨中詢問雨傘去向時，王后卡米拉已經撐傘離開。

<!--more-->

這一幕吸引了媒體的密切關注，多家機構拍下了君主困惑的表情以及他針對雨傘丟失的直接詢問。觀察人士注意到國王的短暫失措與王后迅速撤離暴雨區形成了鮮明對比。

儘管有短暫的挫敗感，但此事突顯了戶外公開活動即便對皇室成員而言也充滿不可預測性。這一插曲被多家英國主流媒體報道，引發了公眾對皇室外事活動輕鬆一面的興趣。

國王的反應——被報道描述為一句“三詞詢問”——成為了敘述焦點，生動說明瞭天氣突然轉壞時執行正式訪問的挑戰。儘管被淋溼，行程仍按計劃繼續，這一時刻成了親切的提醒：即使是皇室成員也無法免疫天氣的反覆無常。
