---
title: "Zelensky révèle une proposition américaine sur le Donbass et dénonce les restrictions de Starshield"
date: 2026-11-15T08:36:53Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMitgFBVV95cUxQTGQwamJqbjhtTlFRWHNTSG5EZHI4ZXItamJnZlB6M0lkS2FoNS11eWpxY2s4dTVPcFVjRzVjTUVSeDhrNTJXdF9RSWtDYy16QW96YlJGWk9xdjNDZV9oNkhIa1hWcE9qZEhZLV95RHVzUFZBOHFqUDBLVGdWMHBCeUk0c0ZlTzdVakZkTnloRkFJVVdTdW5HeDgzLVFMUGZSQWdlNFQ0OHFFUFQ4a2NNaTVPQVhpdw?oc=5"
source_name: "The Independent"
draft: false
---

Le président ukrainien Volodymyr Zelensky a révélé publiquement que les États-Unis avaient précédemment proposé un plan impliquant la région du Donbass comme une voie potentielle vers l'adhésion à l'OTAN.

<!--more-->

Cette révélation survient dans un contexte de tensions persistantes concernant les garanties de sécurité de l'Ukraine et le rôle des partenaires internationaux dans le conflit.

La proposition, qui suggère un compromis territorial en échange d'assurances de sécurité, a suscité un débat intense au sein des cercles diplomatiques.

En plus de ces manœuvres géopolitiques, Zelensky a porté des accusations contre SpaceX, affirmant que l'entreprise a manqué de transparence concernant la fonctionnalité de son système satellitaire Starshield.

Le dirigeant ukrainien allègue que l'accès à ce réseau de communication vital a été restreint, compliquant davantage les opérations militaires sur les lignes de front.

Ces affirmations ont suscité l'attention des législateurs américains, des sénateurs de haut rang exigeant qu'Elon Musk conserve tous les enregistrements liés à l'accès à Starlink dans la région.

La situation reste fluide alors que la Commission des affaires étrangères du Sénat américain continue de surveiller l'intersection entre la technologie privée et la sécurité nationale.

La controverse entourant Starshield, combinée à la nature sensible de la proposition « Donbass contre OTAN », souligne les défis complexes auxquels est confrontée l'administration Biden, qui doit équilibrer son soutien à Kiev avec les risques d'escalade.

Les observateurs notent que ces développements pourraient avoir un impact significatif sur les négociations futures et le paysage stratégique de la guerre.
