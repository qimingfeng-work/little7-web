---
title: "Jaguar Land Rover : restructuration massive après des pertes en Chine"
date: 2026-11-13T17:35:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiqwFBVV95cUxOd3R1UTE4Nl9qc0hBWlQzOHd6M0JuV3ExVXdOblpGN1BOcW5tQndTYl9TWVY0YW1IQ2tHRHZybjRGeDM4V29GNEUzNDlHdUZaUFBBeXZhY2M5ZHRVTlNqeFhLeHNCYnJQd3dGNW1pMFJ0NFlNYkp6aWR5d3lqTmdpUUFhb2tITGRoeTQ2czNqSlpBR1hsbXNKQkxXN29RejNJNFJZbjR0TjhvQms?oc=5"
source_name: "The Times"
draft: false
---

Le constructeur automobile de luxe Jaguar Land Rover (JLR) a officiellement révisé ses prévisions de bénéfices à la baisse, citant des difficultés opérationnelles majeures sur le marché chinois.

<!--more-->

L'entreprise, pilier de l'industrie automobile britannique, traverse une période turbulente caractérisée par une demande fluctuante et des vents contraires économiques plus larges.

Des rapports récents du Times et du Guardian soulignent que la société a enregistré une perte trimestrielle d'environ 451 millions de livres sterling, un chiffre qui illustre la gravité de ses défis fiscaux actuels.

En réponse à ces pressions, JLR a lancé un plan de restructuration complet, incluant une réduction significative de ses effectifs.

L'entreprise a confirmé la suppression de 4 000 emplois, dont 3 000 employés ayant déjà accepté un départ volontaire dans le cadre d'une refonte stratégique sur deux ans.

Cette mesure vise à rationaliser les opérations et à stabiliser la situation financière de l'entreprise dans un marché mondial de plus en plus concurrentiel.

Malgré ces revers, JLR continue de poursuivre sa vision à long terme, notamment en ce qui concerne l'électrification de sa flotte.

La société a récemment annoncé le lancement de trois nouveaux véhicules électriques de luxe, signalant son engagement à abandonner les moteurs à combustion interne.

Par ailleurs, des signes de résilience apparaissent dans d'autres secteurs, le siège des West Midlands rapportant une hausse des bénéfices dans des segments spécifiques suite aux efforts de récupération après des incidents de cybersécurité antérieurs.

L'entreprise reste concentrée sur l'équilibre entre son redressement financier immédiat et son objectif à long terme de maintenir son statut de leader sur le segment des véhicules électriques de luxe.
