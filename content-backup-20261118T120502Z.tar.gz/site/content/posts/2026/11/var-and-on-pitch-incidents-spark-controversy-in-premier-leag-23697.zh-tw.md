---
title: "英超聯賽VAR判罰與球員行為再成熱議焦點"
date: Thu, 29 Oct 2026 10:36:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMilwFBVV95cUxQSDdVZnA0NXRrQ19uUmJQUVpCWTBTdkNGWFJzZ2k4RkxiRkpVRmg4S2MwZ0xnXzhFZU5EUmxoRTJ1YWJCR05ocHZmUkE0SnhFZHJ2WnpYU0NQZ0NBRkl1ZHdmd3dyNzY1eDZPVWdNYXRFMWFpQTgxRTRzMkxaQ2pjUHNRa1VpdnQxYlZMTTAzRk9zMVdOTzdR?oc=5"
source_name: "The Independent"
draft: false
---

最近的英超聯賽賽程再次將影片助理裁判（VAR）系統和球員行為推到了激烈足球辯論的中心。在備受矚目的比賽中，諾尼·馬杜埃凱（Noni Madueke）與亞歷克西斯·麥卡利斯特（Alexis Mac Allister）之間疑似頭頂撞擊事件引發了廣泛審視。

<!--more-->

這一衝突引發了專家和球迷的各種反應，利物浦的亞歷克西斯·麥卡利斯特受到了傑米·卡拉格（Jamie Carragher）等分析師的嚴厲批評，後者稱這名中場球員試圖讓對手被罰下的反應令人尷尬。

這一事件還讓人聯想到過去的爭議，例如托特納姆熱刺球迷回憶起過去涉及羅德里戈·本坦庫爾（Rodrigo Bentancur）的紀律處罰決定，並就裁判標準的統一性展開爭論。專家指出，這些比賽既體現了現代足球中VAR積極的一面，也體現了消極的一面。

雖然技術旨在糾正清晰且明顯的錯誤，但球場上主觀的爭執在假摔、體育精神以及比賽官員對紅牌規則的嚴格應用方面，依然意見分歧。
