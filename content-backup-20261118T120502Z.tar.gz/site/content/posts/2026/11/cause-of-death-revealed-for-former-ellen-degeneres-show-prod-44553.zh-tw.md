---
title: "資深電視製作人馬修·賴特去世原因公佈"
date: Sat, 07 Nov 2026 00:32:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMisAFBVV95cUxQbW5BRDR3UzEzMWU3OWJCU29VT2lOX2VxdlBhZmg2YXJPX1NJeTJ3cHhRMUtyT3F5U18xdGZkM21sLXFrVG9iWnJWdnRxTW1jNjBhNE14Z2tOZ3I4MkU5MFJpWU5KaGN2R3B2TUlNU0V3Y041dFZnb2lTUDBTbjFNdnZqYjl3aVRPeThGTnlMNTQ5amFqNTJ6MDc4czUwZ2JZa21LYzZ3dmZMb2E5d2tPMQ?oc=5"
source_name: "Page Six"
draft: false
---

在資深電視製作人馬修·賴特（Matthew Wright）突然離世數月後，其官方死因終於公之於眾。

<!--more-->

賴特因在熱門日間節目《艾倫·德傑尼勒斯秀》（The Ellen DeGeneres Show）中的傑出貢獻而廣為人知，他不幸離世時年僅52歲，這一訊息令整個娛樂界及其同事深感悲痛。

在賴特去世後，其悲痛的家人選擇公開更多關於其死因的細節，旨在為那些一直在尋找答案的粉絲和前同事們提供一個交代。這位資深電視高管的意外離世，曾被身邊人形容為一場難以置信的悲劇，在賴特工作多年的製作圈內引發了巨大震動。

當死訊傳出時，娛樂界紛紛表達哀悼。主持人艾倫·德傑尼勒斯曾釋出了一段充滿情感的影片悼念，紀念賴特在節目中留下的記憶與遺產。

同事們不僅銘記賴特在日間電視幕後的專業奉獻與創作才華，更懷念他為人處世的溫暖與善良。此次公佈的關於他生命最後時刻的細節，為公眾悼念這位曾為數百萬觀眾帶來歡樂的電視人畫上了一個沉重的句號。
