---
title: "Donnie Dunagan, Iconic Voice of Disney’s Bambi and Decorated Marine, Dies at 92"
date: Mon, 09 Nov 2026 17:49:00 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMipgFBVV95cUxNYnlLS2RPTXphNm04azJ3SWlmdXVOZlJSUVB3TU5OblRvTmE3UHhteDhmRno0MnhfQnJITk9pU3FJSUV3Ml9mdUtKZGtJZDh2RzBEdm9VTllLRzRtcVdtMk9MZVloZlJaS1I3WnpWenhfa2g0RXRCTzdDSDJvUmlpWnJfSUQ2cW03bGdPb0xSVzdiYlR1QVpmY2xHMmJYUWQ0ZTJXWmZ3?oc=5"
source_name: "The Guardian"
draft: false
---

Donnie Dunagan, a man whose life was defined by two vastly different but equally remarkable chapters, has passed away at the age of 92. To the world of cinema, he was best known as the original voice of the titular character in Disney’s 1942 animated classic 'Bambi.' To the United States Marine Corps, he was a highly decorated officer and a veteran of the Vietnam War who earned three Purple Hearts for his service.

<!--more-->

Born in 1934, Dunagan’s early years were marked by a brief but indelible career in Hollywood. His soft, expressive voice captured the innocence of the young deer in one of animation's most beloved films. However, as he matured, Dunagan stepped away from the spotlight of show business to pursue a life of military discipline. He enlisted in the Marines, eventually rising through the ranks to become a major.

His military career was characterized by bravery and sacrifice. Serving during the Vietnam War, Dunagan was wounded multiple times in combat, a testament to his commitment to his duties and his fellow soldiers. Despite the fame he garnered as a child actor, he remained remarkably humble about his military service, often keeping his Hollywood past a secret from his comrades for many years. It was only later in life that the two facets of his identity—the gentle voice of a forest creature and the hardened warrior—were reconciled in the public eye.

Dunagan’s passing marks the end of an era for Disney history. He was one of the last remaining links to the golden age of animation, having worked closely with Walt Disney himself. His legacy is a unique tapestry of American culture, bridging the gap between the whimsical storytelling of the silver screen and the profound sacrifices made by those in uniform. He is remembered by family, friends, and fans as a man of integrity who served his country with the same dedication he brought to his craft as an artist.
