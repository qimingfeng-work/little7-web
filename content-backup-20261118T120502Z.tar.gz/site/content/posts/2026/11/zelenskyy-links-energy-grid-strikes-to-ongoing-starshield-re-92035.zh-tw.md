---
title: "澤倫斯基呼籲美國與SpaceX放寬Starshield限制 助烏克蘭保衛能源網"
date: 2026-11-16T03:25:00Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMi4gFBVV95cUxOUndLQk1KbFRBWVEwdTRHRWN3cVdOQk5CVGtmN193ck5EbnlmZUxYUEhGN1llTV9wRTByTUJ6Ry15ZXQ1bEJyakRZendBbTR1eUlvb0RzeElFb1pjbzNQYkVkSEQxTXVlQjlyaG9VekF0bEJNYnlFa2ZKaWt1cldtTDJQQWhadlJOVU1jOGl3b0Z3dkx3akY0cU44NmNPQ3FYSmxnRkoxRjEydTAzY3BFX0dZeUpjWFN5QXIzQVZHTFF6NW9iLVZpQWNJeWlLTTduTlJjcWZkdUY1U0YwdUlBODJB?oc=5"
source_name: "The Guardian"
draft: false
---

烏克蘭總統澤倫斯基（Volodymyr Zelenskyy）日前公開談論該國能源基礎設施持續面臨的脆弱性，並將近來遭受俄軍猛烈空襲的原因，歸咎於「星盾」（Starshield）衛星網路所受到的持續限制。

<!--more-->

澤倫斯基強烈敦促美國政府以及 SpaceX 執行長伊隆·馬斯克（Elon Musk）解除這些技術限制，他認為當前的禁令嚴重阻礙了烏克蘭在衝突關鍵階段的防禦能力。

<br><br>
在近期的簡報中，烏克蘭總統特別強調，維持通訊連結與戰場態勢感知能力，對於保護民間能源電網免受俄羅斯飛彈與無人機攻擊至關重要。他呼籲國際夥伴們站在「歷史正確的一邊」，提供必要的技術支援來確保烏克蘭關鍵基礎設施的安全。

此一局勢已引起全球領導人與國會議員的高度關注，部分美國官員甚至要求 SpaceX 保留該地區 Starlink 服務存取與使用的相關資料紀錄。

<br><br>
儘管 SpaceX 一直堅稱其服務主要用於人道主義目的，但烏克蘭政府則反駁指出，這些營運限制直接助長了一波又一波的空襲，導致數百萬民眾無電可用。

隨著冬季即將來臨，關於私人衛星技術在現代戰爭中所扮演角色的爭論正急遽升溫，國際社會也正密切監控這些限制對烏克蘭地面戰局所造成的實際影響。<br><br>
