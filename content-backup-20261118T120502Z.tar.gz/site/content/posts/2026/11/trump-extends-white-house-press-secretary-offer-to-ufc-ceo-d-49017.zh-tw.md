---
title: "從八角籠到西翼？特朗普公開邀請UFC執行長達納·懷特任白宮新聞秘書"
date: Sun, 08 Nov 2026 07:04:37 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMipgFBVV95cUxNb3NSekdiWjV3eVlPZmlTeVhDeEpxcUdOSXFNaEk3dnJXWUNnQzdCQU1UcE4zSHRaeXRsTmxuaE9NR0RkMG5rZlpWTEpqRzI5REp4cEEwSURQWnE2RnI1R05JeENwUGZVeG5yTWlqUWFWS2N1NnVQMENfUW02OHR5TjItUDltOThpN1IyTzBBOGJWUXFyRTl5UEwzWXdQTVlGVjhPUENR?oc=5"
source_name: "Euronews.com"
draft: false
---

在一項令政治觀察家和體育迷同樣感到驚訝的舉動中，當選總統唐納德·特朗普公開邀請UFC（終極格鬥冠軍賽）執行長達納·懷特（Dana White）擔任他的白宮新聞秘書。這一邀請帶有新政府一貫的風格，其表述形式十分直接：“達納，請接受這份工作！

<!--more-->

”這種非傳統的排兵佈陣方式突顯了特朗普的偏好——他更傾向於任命那些與自己建立良好個人關係且具備極高公眾知名度的人選。達納·懷特長期以來一直是特朗普的堅定盟友，並在UFC走向全球知名度的過程中發揮了核心作用。

他如果從綜合格鬥推廣的世界過渡到白宮新聞簡報室的發言臺，將成為現代政治史上最不同尋常的任命之一。這一舉動的支持者認為，懷特在管理高壓媒體環境方面的經驗以及他掌控全場的能力，可能會成為這一職位的資產。

相反，批評者則認為，該職位需要對政策和外交細微差別有深刻的理解，而這些特質傳統上並非格鬥體育行業所具備的標籤。這一宣佈在整個媒體界引發了一陣猜測和幽默評論。

一些媒體甚至開玩笑地質疑，鑑於這次公開請求的突然性，特朗普是否把這位UFC老闆同另一個名叫達納·懷特的人搞混了。然而，討論的核心仍然是新政府在填補關鍵傳播角色時傾向於打破傳統政治建制派的更廣泛趨勢。

截至目前，懷特是否會接受這一職務尚不明朗。他對UFC目前的承諾相當重大，轉型為一個政府角色將涉及重大的生活方式改變和公眾監督。

無論結果如何，這一邀請本身就突顯了特朗普與他所信任的人物之間獨特的關係，標誌著他“局外人”治國理念的延續。政治世界現在正拭目以待，這位UFC高管是否真的會用西翼的講臺換掉他熟悉的八角籠。

com
