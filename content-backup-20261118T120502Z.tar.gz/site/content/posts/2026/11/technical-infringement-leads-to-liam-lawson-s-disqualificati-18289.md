---
title: "Technical Infringement Leads to Liam Lawson’s Disqualification from Mexico City Grand Prix Qualifying"
date: Sun, 01 Nov 2026 01:10:00 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMi0wFBVV95cUxPYU52TTVzNmxSRWh4YkFuUVk1cjRxVHdZZl93YUl0aE9mN3lBZFhkRUVnUWl6bUNMWk5va2w1MnJrbVFNZzlrS0pMWHRYbmZVbGJyUWstWS1lNlBQZVJPZXM4dUNwRTllMXljTEpSLWRZUEJHQ3VOV2ZhbWVoZlhsYUZCUVc0dHRESG9nTUlvbXJyQkNCZENmRWFycWxaU2szUktLcmV3UktsZnpoNGxrVnNGUS11Tk55MEdIZ0pCRUlLcGtRb3cwdFJKSElSckxDQmlJ?oc=5"
source_name: "Formula 1"
draft: false
---

The Mexico City Grand Prix weekend has encountered a significant regulatory hurdle for RB driver Liam Lawson, who has been officially disqualified from the qualifying results due to a technical infringement discovered on his vehicle. Following the session, scrutineers identified that the car failed to adhere to the strict technical regulations mandated by the FIA, resulting in the immediate exclusion of the New Zealander from the classification.

<!--more-->

This setback compounds a difficult weekend for Lawson, who had already been grappling with the aftermath of an intense exchange during the practice sessions. Earlier in the event, tensions flared between the young driver and championship leader Max Verstappen, leading to a physical and verbal confrontation on the track. Both drivers were subsequently issued a one-place grid penalty by race stewards, who determined that their on-track behavior during the practice period crossed the line of acceptable conduct.

The disqualification is a major blow to Lawson’s aspirations for the main race, as it forces him to navigate the remainder of the weekend from the very back of the pack. While the RB team works to rectify the technical irregularities that triggered the disqualification, the broader paddock remains focused on the future of the Racing Bulls seat. Speculation regarding the driver lineup for the next season remains rampant, though internal figures, including Verstappen, have declined to provide specific details on the private discussions occurring within the Red Bull family.

Despite the friction between Verstappen and Lawson, the reigning world champion indicated that he has cleared the air with his younger colleague. Verstappen has maintained a professional stance when questioned about the internal dynamics of the team, choosing to keep discussions surrounding future driver appointments private. 

For the time being, Lawson’s immediate priority will be recovering from his grid penalties and technical exclusion to salvage a competitive performance during the Grand Prix. The combination of the practice clash penalties and the post-qualifying disqualification presents an uphill battle for the driver as he attempts to prove his consistency under significant pressure. Fans and analysts alike will be watching closely to see how the team manages these setbacks as the championship schedule enters its final, high-stakes phase in the Americas.
