---
title: "Miracle en Caroline du Sud : un nourrisson retrouvé vivant après avoir été enterré"
date: Wed, 11 Nov 2026 13:57:46 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMikAFBVV95cUxQTVpZUFo3dWJzYU5PU1NUWG9Pci1mYTJ5V1hzWFZaYlBuTDE0VmRHSm5rM3J6VU1yT0ZpNjZUVFlleHROUUFTSnlsR1QwdGlIQUE2SmI5VE9DQVBlLVVnbWItUjRRNnpYblFHLThNdXU0b29CcGhDNWxPclFBdFppcDBaWnJaaGhXQlg1akR2V2s?oc=5"
source_name: "CBS News"
draft: false
---

Une opération de sauvetage éprouvante en Caroline du Sud a permis de sauver un nourrisson de 11 mois retrouvé enterré vivant dans une cage pour chien.

<!--more-->

L'enfant avait été porté disparu pendant 24 heures après avoir été enlevé par son père.

Selon les autorités locales, le bébé a été découvert « s'accrochant à la vie » après qu'une opération de recherche a conduit les adjoints du shérif à l'endroit où l'enfant avait été dissimulé.

Cette affaire a choqué la communauté locale et attiré l'attention nationale en raison de l'extrême cruauté de l'acte.

L'incident a débuté lorsque la disparition du nourrisson a été signalée, déclenchant une recherche urgente par le bureau du shérif du comté de Lexington.

Les enquêteurs ont rapidement identifié le père comme une personne d'intérêt.

En localisant le suspect et le site où l'enfant était caché, les agents ont découvert le bébé enterré dans une cage pour chien, une découverte que les responsables du shérif ont qualifiée de miracle compte tenu du temps que l'enfant avait passé dans de telles conditions.

Le nourrisson a été immédiatement transporté dans un centre médical pour des soins d'urgence.

Les poursuites judiciaires contre le père sont en cours, les autorités insistant sur la gravité des charges retenues.

Ce sauvetage témoigne de la persévérance des forces de l'ordre qui ont travaillé contre la montre pour localiser l'enfant disparu.

Bien que le bébé soit actuellement en convalescence, l'incident a laissé la communauté sous le choc et a ouvert un débat nécessaire sur la sécurité des enfants et les interventions en milieu familial.

L'enquête sur les motivations derrière les actions du père se poursuit alors que le système judiciaire se prépare à traiter cette affaire.
