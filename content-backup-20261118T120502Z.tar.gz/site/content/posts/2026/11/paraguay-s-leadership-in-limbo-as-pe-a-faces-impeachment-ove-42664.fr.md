---
title: "Crise politique au Paraguay : le président Santiago Peña menacé d'impeachment après l'effondrement de la banque ueno"
date: Fri, 06 Nov 2026 15:07:33 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMitgFBVV95cUxPdXV6WEZCVmtNQW9RV3BEWDhvUWtqRlBoaGpMQ1ZqQkk4Y2g3QWRtXzhjQ2ZFRVE2VWVRUlE3MDNuZnJ2aWw1WEtsZG5YRGo1V01EMXhqRldTMkNmNGI2RFZkeHZLVWJuWV9aTDZVSHlTTm9NNVpQeF9CRGtBWkFScnE4aEtzTDRUbkxZb2pYbE1RQ3NFS3V2bHpFUUJvcmFYRlpoSThucjBKVmtveWRWdkFGaHZPdw?oc=5"
source_name: "Reuters"
draft: false
---

La stabilité politique du Paraguay a basculé dans une incertitude profonde alors que le président Santiago Peña fait face à une menace imminente de procès en destitution (impeachment), déclenché par l'effondrement catastrophique de la banque ueno.

<!--more-->

Cette crise financière soudaine a paralysé des millions de comptes bancaires à travers tout le pays, transformant instantanément une urgence économique pure en une crise politique de grande ampleur qui menace directement la survie de l'administration actuelle.

Les agences de presse internationales, incluant Reuters et Al Jazeera, ont largement couvert les mécanismes de cet effondrement financier et ses répercussions politiques immédiates.

L'implosion de la banque ueno — une institution profondément imbriquée dans le tissu financier du pays — a laissé d'innombrables citoyens dans l'incapacité d'accéder à leur épargne, provoquant une indignation publique généralisée et d'importantes manifestations de rue.

Pour de nombreux Paraguayens, cette crise ravive des souvenirs douloureux liés à l'instabilité bancaire historique du pays, amplifiant la colère populaire contre laxisme de la surveillance réglementaire et le manque de responsabilité gouvernementale.

Les ramifications politiques n'ont pas tardé à se faire sentir avec une rapidité et une sévérité remarquables.

Des médias tels que Bloomberg et The Washington Post ont détaillé comment ce scandale en plein essor a considérablement affaibli le président Peña, largement reconnu comme un allié régional clé de l'ancien président américain Donald Trump.

Alors que les législateurs de l'opposition s'unissent pour mener à bien la procédure de destitution, l'avenir du leadership de Peña ne tient plus qu'à un fil.

Les événements en cours testent non seulement la résilience des institutions démocratiques du Paraguay, mais mettent également en lumière l'intersection dangereuse entre la malversation financière privée et les enjeux politiques nationaux de haute voltige.

Alors que le procès en destitution s'amerce, le pays reste sur le qui-vive.

L'issue de cette épreuve de force politique redéfinira probablement le paysage politique paraguayen pour les années à venir, déterminant si l'exécutif parviendra à traverser la tempête ou si cet effondrement bancaire parviendra à balayer l'actuelle direction du pouvoir.
