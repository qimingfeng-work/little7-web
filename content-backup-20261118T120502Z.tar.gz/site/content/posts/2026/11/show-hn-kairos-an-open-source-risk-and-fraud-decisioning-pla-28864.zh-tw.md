---
title: "開源反欺詐平臺 Kairos 釋出，旨在解決現代欺詐檢測難題"
date: Tue, 03 Nov 2026 21:17:36 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://www.bbc.co.uk/news/articles/c59vz44epvk9o?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
draft: false
---

一個名為 Kairos 的全新開源平臺近日正式釋出，旨在為開發者和企業提供傳統即時欺詐決策工具（如 Sift 和 Sardine）的替代方案。Kairos 的開發初衷是解決現代欺詐檢測中的兩大核心障礙：標註訓練資料的匱乏以及欺詐手段的快速演變。

<!--more-->

該平臺致力於通過技術創新，幫助企業更高效地保護數字資產。傳統的欺詐檢測系統高度依賴 XGBoost 等機器學習模型，這些模型需要海量的歷史標註資料才能發揮效用，而許多處於成長期的企業往往缺乏此類資料。

Kairos 通過將“系統一”（System One）決策模型與傳統機器學習方法相結合，有效打破了這一瓶頸。工程團隊可以直接將簡單的自然語言問題（例如“檢查電子郵件地址是否為臨時郵箱”）整合到決策邏輯中，而無需依賴龐大的資料集。

為了應對欺詐者不斷變換手段以規避靜態規則的行為，Kairos 引入了“模型上下文協議”（Model Context Protocol）伺服器。

這一功能使得 Claude Code 或 Cursor 等 AI 代理能夠自主定義決策工作流，利用企業最新的即時資料訓練模型，並自動選擇表現最優的變體。

該平臺目前支援通過 Docker 進行自託管，同時也提供全託管的雲服務版本，為不同規模的企業提供了靈活的部署選擇。
