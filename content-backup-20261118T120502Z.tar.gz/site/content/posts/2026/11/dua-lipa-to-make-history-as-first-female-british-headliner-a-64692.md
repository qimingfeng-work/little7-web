---
title: "Dua Lipa to Make History as First Female British Headliner at Coachella 2027"
date: Wed, 11 Nov 2026 10:53:47 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://www.bbc.co.uk/news/articles/cjr4g0n9d1g5o?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
image_url: "https://ichef.bbci.co.uk/ace/standard/240/cpsprodpb/8ca9/live/cefe7370-ddb4-11f1-90cd-85e940e3a009.jpg"
draft: false
---

In a landmark announcement for the music industry, Dua Lipa has been confirmed as a headliner for the 2027 Coachella Valley Music and Arts Festival. This achievement marks a significant milestone, as she will become the first female British artist to headline the prestigious event. The festival, which takes place over two weekends in the California desert, will also feature performances by Tame Impala and SZA, creating a diverse and highly anticipated lineup.

<!--more-->

Dua Lipa, known for her chart-topping hits and dynamic stage presence, has solidified her status as a global pop icon. Her inclusion as a headliner reflects her massive influence on contemporary music and her ability to captivate audiences on a grand scale. The announcement has been met with widespread excitement from fans and industry insiders, who view this as a well-deserved recognition of her career trajectory.

Joining her at the top of the bill, Tame Impala and SZA bring their own unique sounds to the desert stage. Tame Impala’s psychedelic rock influence and SZA’s soulful R&B mastery are expected to provide a balanced and eclectic experience for festival-goers. The choice of headliners highlights Coachella’s ongoing commitment to showcasing a wide range of genres and artists who are currently defining the cultural zeitgeist.

As preparations for the 2027 festival begin, anticipation is already building for what promises to be a historic weekend. For Dua Lipa, headlining Coachella is not just a personal victory but a moment of pride for the British music scene. As the industry looks forward to the event, all eyes will be on the California desert to see how these artists translate their studio success into the immersive, large-scale performances that Coachella is famous for.
