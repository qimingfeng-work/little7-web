---
title: "Taïwan : Le débat sur l'énergie solaire dans les réservoirs s'intensifie"
date: 2026-11-18T07:26:01Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMipgNBVV95cUxORWVTMzdoRDdrZnB3djFtZ0M4ZjUtV1NCcVV4dkJlN2V1MncyR3BUc3BwYU9kM1dYZ2ZwMlhJWUJCNnkxOE1Xb1doUFBoNWJUM0kxNmJaUl9DZEZqQmRhS29iWHQtRFhPdWQ1U1BVZzdMYmlDTmlkWVVJVy1tU3AzLVU2Y0pBUXJFX19sQkItM1pBaXBkX0RTanNBSzdKY00wODJRNjhNa09tR2xHYmFZSXRDZm5TSHNkV2p6di1OamdUbzBzTXRCbXphQ2lyVFdLRF9QX3lQVWM3cjQzd3BVMEJVM0ctNW5pd3UtMy1oR3dzTjNDa2NBRFdYYXdPbVgxOFJIb2dFZGdxaXJ3WGtEZkJoa0pYdkF4Nk9jZklUMjZxZWY2cTFvWGVmMC1jVnNTNDdJOEJBZzRISmJjaG1HUnQwUGE0SkFLTC0wdmJMMDFOWk1IZVJ1dmoweU5zbVJZWkdKLWhkb2doY3hzb0FtRnNXdVFLbUZCdVEyNXFqTnNJZnkzYzlScFlIVTV2WUFMRU9WTjRvaV9aX3BxUHdfZVBGMmdsZw?oc=5"
source_name: "Yahoo新聞"
draft: false
---

Un débat politique houleux a éclaté à Taïwan concernant l'installation de panneaux solaires sur les réservoirs, en particulier le réservoir de Feitsui.

<!--more-->

La controverse a commencé lorsque la législatrice Cheng Li-wen a publiquement remercié le maire de Taipei, Chiang Wan-an, pour sa position ferme contre l'installation de panneaux solaires sur le réservoir, invoquant des préoccupations environnementales et de sécurité de l'eau.

Cette décision a suscité de vives critiques de la part des camps politiques opposés, qui soutiennent que la résistance à l'énergie solaire est une forme de théâtre politique ignorant la nécessité plus large de la transition vers les énergies renouvelables.

Le discours a pris plusieurs tournants inattendus, diverses personnalités politiques s'exprimant sur la question.

Certains ont souligné que les administrations précédentes, y compris l'ère Ma Ying-jeou, avaient autorisé des projets similaires, ce qui a conduit à des accusations d'hypocrisie de la part du parti au pouvoir.

Pendant ce temps, d'autres ont remis en question la transparence des évaluations d'impact environnemental de l'administration actuelle.

Le débat a également abordé le sujet plus large de l'énergie nucléaire, avec des appels à redémarrer les centrales nucléaires comme solution aux besoins énergétiques du pays, compliquant encore davantage le récit.

À l'approche des élections locales de 2026, la question de l'énergie solaire est devenue un indicateur de batailles idéologiques plus larges.

Le Parti démocrate progressiste (DPP) a accusé l'opposition d'utiliser la question pour bloquer les initiatives d'énergie verte à des fins électorales, tandis que le Kuomintang (KMT) maintient que leur principale préoccupation est la protection des ressources en eau locales et de l'environnement.

Au milieu des accusations mutuelles, le public est laissé à naviguer dans un réseau complexe d'affirmations et de contre-affirmations.

L'incident met en lumière la lutte continue à Taïwan pour équilibrer le besoin urgent d'énergie durable avec la préservation des paysages naturels et les demandes de la gouvernance locale.

Avec les deux camps campant sur leurs positions, le débat sur la politique énergétique restera probablement un thème central à l'approche des prochaines élections.
