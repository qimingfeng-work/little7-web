---
title: "Netflix Announces New Magic: The Gathering Animated Series 'Planeswalker'"
date: 2026-11-13T19:48:07Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMisgFBVV95cUxNc2lrRFM5Y1g1V3pZNmFucmVGN0ZZSWdnUGFsQjhrRU1QNi0xb1MwalJsV0R5RTdsVWRLY0VkWE5OU05EM1NGdTVITTNuTGxncFJEOHBmcXhpQ2xBT3o0MGNxSUZyNFV4TEMxeXBBSWhoWnlVdEZjNElhTmR3RE5DUkh3VURqUjFPQ1FnWkMzWW5QTjNpUW9QUlpVeXY4RWVNV0w0OW0xTjdVdVJHM1o4SVFR?oc=5"
source_name: "Magic: The Gathering"
draft: false
---

Netflix has officially unveiled its latest venture into the world of fantasy gaming with the announcement of an animated series titled 'Planeswalker,' based on the iconic card game Magic: The Gathering. The project, which has been in development for some time, is scheduled for release in 2027. Fans of the long-running franchise have been eagerly awaiting news regarding the adaptation, and the recent reveal of a first-look photo and a trailer has generated significant excitement within the gaming community.

<!--more-->

The series promises to bring the rich lore and complex characters of the Magic: The Gathering universe to life through high-quality animation. 'Planeswalker' will focus on the powerful mages capable of traveling between the game's various dimensions, a core element of the source material's narrative. By centering the story on these characters, the show aims to appeal to both long-time players who are familiar with the game's deep history and newcomers who are interested in epic fantasy storytelling.

Netflix's decision to adapt this property is part of a broader strategy to capitalize on popular gaming franchises. With the success of previous animated adaptations, the platform is investing heavily in the production values of 'Planeswalker' to ensure it meets the high expectations of the fanbase. The creative team behind the series is reportedly working closely with the game's developers to maintain authenticity while crafting a compelling narrative arc that works well in an episodic format.

As the 2027 release date approaches, more details regarding the cast, plot specifics, and visual style are expected to emerge. The announcement has already sparked widespread discussion on social media, with fans dissecting the first-look images for clues about which iconic planes and characters might appear in the show. For now, the reveal serves as a major milestone for the Magic: The Gathering brand as it expands its footprint into the world of prestige streaming television.
