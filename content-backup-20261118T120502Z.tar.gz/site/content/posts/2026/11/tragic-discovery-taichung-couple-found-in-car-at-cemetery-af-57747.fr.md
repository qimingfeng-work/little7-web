---
title: "Drame à Taichung : un couple retrouvé dans un parking de cimetière"
date: Tue, 10 Nov 2026 04:26:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiVkFVX3lxTFA0RkVEMC1WZEs2TF9RTTRrRHBkMVp6NzhVdGR2bDM3WkZlTGZwT1BqVk9UcTFybzMxSWlfVVpKVE5OSVlxWjNkNXZLOGpxRF9xVjRvNV9n?oc=5"
source_name: "東森新聞"
draft: false
---

Un incident sombre s'est déroulé à Taichung, où un couple marié a été découvert dans son véhicule sur le parking d'un cimetière après avoir été porté disparu.

<!--more-->

Les autorités ont été alertées après que le couple a laissé des messages inquiétants à leur famille, déclenchant une recherche immédiate.

En localisant le véhicule, les secours ont trouvé les deux individus dans un état critique.

Malgré les efforts rapides des services d'urgence pour les transporter à l'hôpital, le mari a été déclaré décédé à son arrivée, tandis que l'épouse reste dans un état critique et reçoit actuellement des soins médicaux intensifs.

Les autorités ont bouclé la zone pour mener une enquête approfondie sur les circonstances entourant l'incident.

Les rapports préliminaires suggèrent que le couple était en proie à des problèmes personnels, auxquels ils faisaient allusion dans les derniers messages envoyés à leurs proches.

La police locale tente actuellement de reconstituer la chronologie des événements ayant conduit à cette tragédie.

La découverte a provoqué une onde de choc dans la communauté, soulignant l'importance de la sensibilisation à la santé mentale et le besoin de systèmes de soutien pour ceux qui sont en détresse.

Alors que l'enquête se poursuit, les responsables ne divulguent pas plus de détails par respect pour la vie privée de la famille en cette période difficile.

L'attention reste portée sur le rétablissement médical du conjoint survivant et sur la conclusion formelle de l'enquête policière.
