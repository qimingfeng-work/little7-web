---
title: "Loose Women star Lisa Maxwell’s daughter Beau Jessup passes away at 27 in New York"
date: 2026-11-13T08:19:37Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiogFBVV95cUxQNllhU25OX0lvMGxUUUFMLVVwRGdBY2ZONnBnT3lDQWREM0lKTF9oaXF6ZEpzczBlUk5GQWgtTVVsNjNpTGVQNmE3VWhGRUx3MzhyeHdhVjhaaXBTRzRiYTBaei1wY2EtSFVTNjFBeWd3ZVVMNFlFMVVFUXUwdUV1SUZKZEtBTTBISmlhSkpvMVRQVEdiTUNBdktuTjY2aGZMa1E?oc=5"
source_name: "London Evening Standard"
draft: false
---

Tributes have poured in from across the entertainment world following the sudden death of Beau Jessup, the only daughter of British television star and actress Lisa Maxwell. Jessup, who was just 27 years old, passed away while living and studying in New York City. News of the tragic loss has deeply affected family, friends, and fans of the well-known television personality.

<!--more-->

Lisa Maxwell, widely recognized for her role as a panelist on the ITV daytime talk show 'Loose Women' and her acting work in 'The Bill', has not yet released a detailed public statement regarding the circumstances of her daughter's passing. Representatives for the family have asked for privacy as they navigate this profoundly difficult period of grief and mourning.

Beau Jessup was an accomplished young woman in her own right. She previously gained media attention and entrepreneurial recognition for creating a successful business while living in China, a venture that helped British parents choose Chinese names for their newborns. Her professional drive and intelligence were frequently cited by her mother in past interviews, with Maxwell often expressing immense pride in her daughter's global ambitions and academic pursuits in the United States.

The heartbreaking news has also cast a poignant light on Maxwell's recent career choices. Reports indicate that the actress is slated to star in an upcoming television drama centered around the grief of losing a child—a project that was filmed entirely prior to this tragic real-life event. Colleagues and fellow television stars have taken to social media to share their condolences, offering support to Maxwell and her family during this devastating time.

As details regarding memorial arrangements remain private, the wider entertainment community continues to send messages of sympathy to the grieving mother. The loss of such a young life with a promising future has resonated deeply with viewers and supporters who have followed Maxwell's career over the decades.
