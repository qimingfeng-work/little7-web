---
title: "Massive Crowd Braves Rain to Support Chiang Wan-an at 'Peace Parade'"
date: 2026-11-14T09:35:20Z
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMihgNBVV95cUxPRDZMNmxBUE9Ubm00dXAyRXo1b0FlUEYxVjRNbWZ4RkFteFg4cHdaN0l3eGpyTGE2UnNrVXpXWVJEbnFfbTZTRUx1Wm1maDhxdlV4ZHMwMlA4WFZMeGZaeVlFM2pyZjZ4c21pVzZ2cUdOUU4zY3doSm1uQlJXejN6bjRrOGR1M1BpMnE3ZVdmSDB4SHdlbHk3RDJfVVRmMEFUY0F1aU44Vms1VTluZmhxZk1TLUVxR0RGX2tLWEVSVUR2WTd5UmY0S3pNQTFMRlRKV2FQc1dsQXIwa3hFUUFfeFp3YjdxTVRiRkVZU0xia2NIOEhyQmNPMW15Q2J0dWl5b3dKOGtNT0xPWFRpMHh6Ym5oU3JRV3d6NHZ4MmdPa3JoeUNsUmtVSHBzZ1plZmlBcDNyS2MyRUZVQVBOYWhTZFJ2VUdFM1BzZm82U0ZVOERoWmg0eHdsdXlJVHZzZWlSd19idmUzTEluaXdtRHM5SXQ4X0ZsQ0pKX0FnRkcyWTNWekpTX3c?oc=5"
source_name: "Yahoo新聞"
draft: false
---

Tens of thousands of supporters gathered in Taipei this weekend, braving persistent rain to participate in the 'Peace Parade' in support of mayoral candidate Chiang Wan-an. The event, which served as a major rally for his campaign, saw a massive turnout that organizers estimated at over 80,000 people, creating a significant visual display of political momentum in the heart of the city.

<!--more-->

Despite the inclement weather, the atmosphere remained high-spirited as supporters marched to show their solidarity. The rally reached a climax when key figures from the Blue camp joined Chiang on stage, emphasizing a message of stability and urban governance. The speakers focused on the candidate's vision for a safer and more secure Taipei, aiming to resonate with families and residents concerned about the city's future. The presence of prominent political allies served to unify the party's base and project an image of strength as the election date approaches.

However, the event was not without its controversies. Some media outlets highlighted discrepancies in crowd size estimates, pointing to aerial footage that showed empty seating areas, which sparked debates online regarding the actual level of support. Despite these minor criticisms, the campaign team maintained that the enthusiasm on the ground was genuine and indicative of a strong grassroots movement. The 'Peace Parade' has effectively set the stage for the final stretch of the campaign, with both sides now intensifying their efforts to capture the undecided vote in what is shaping up to be a highly competitive race for the Taipei mayoralty.
