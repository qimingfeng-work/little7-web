---
title: "英國議會大廈面臨嚴重老化危機 議員警告若再拖延維修恐遭“巴黎聖母院式火災”"
date: Wed, 04 Nov 2026 00:01:58 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMingFBVV95cUxNYXNWZ2llZFV6b0JCdnczaXZPZHg2QWQ2ZnhxVmtTZEdJRkxLNUo0WTYzWl9LLW12bHJLMDNUNzdxZzdiRTF0T01DYzk3Y3BRTmNMWE9pX1VFNGIzOFhqaGNNbmpuRkRHQ1J4eE0zVFl1UFpKcENQaTBYNmJVWTJoVWptaXNlS1p6Z1FtaTNKMFNTbTJxYkFPQlZCZWlrQQ?oc=5"
source_name: "The Guardian"
draft: false
---

英國議會大廈正面臨前所未有的審查。多位議員嚴厲警告稱，這座具有歷史意義的建築群物理老化狀況堪憂，面臨發生“災難性事件”的嚴重風險。

<!--more-->

他們特別指出，如果全面翻新工程繼續延誤，大樓將面臨類似“巴黎聖母院大火”的迫在眉睫的安全威脅。由於數十年來的維護工作一再擱置，這座維多利亞時期的建築群內部電線嚴重老化，消防滅火系統也早已過時，導致其脆弱性日益凸顯。

隨著修繕成本持續飆升，議會委員會一直在探討應對這一浩大工程的最佳採購與專案管理方案。一些人主張採取分階段推進的方式逐步處理老舊問題；另一些人則認為，只有開展全面且徹底的修復，才是保護建築遺產、確保政客、工作人員及遊客安全的唯一途徑。

然而，要在如何實施和資助該專案上達成政治與資金共識，目前看來極其困難。英國議會公共賬目委員會（PAC）已發出緊急警告，指出任何進一步的猶豫不決都將帶來沉重的財務和運營代價，並強調拖延只會進一步推高最終成本並加劇安全隱患。

修繕斑駁脫落的石雕、升級關鍵公用設施以及清除大量石棉，需要一場規模空前的後勤大作戰。隨著最後期限的逼近，在避免這場可能摧毀英國民主心臟的災難發生之前，決策者們正承受著敲定最終翻新戰略的巨大壓力。
