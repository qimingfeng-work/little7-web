---
title: "Mohamed Hadid Engaged to Divorce Coach Keni Silva"
date: 2026-11-16T20:44:00Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiugFBVV95cUxPRTlYcHBsRHJYbHVJRmVkVFRRa0xoNUdzb0tIbXRuZUlWVlVVaVJ6Z0RqZ2J3U2RSc0ltaE95ZFIyak1Uak1iQ0NtRDl1Z19VWlllTUxvLXo5djZma2xwSkJHLXBYckhiR3N3WERwdkpnS1FQYlNMLTkwV3pqMzRxcXpDbnE3UlNWMnB6Z1ZWWEl6QzlURWRoWDVxUWNaT0VaR1Z2MmZ5NFJleVJWd25MZ2UtTGVEWS02RXc?oc=5"
source_name: "Page Six"
draft: false
---

Mohamed Hadid, the real estate developer and father of supermodels Bella and Gigi Hadid, has announced his engagement to Keni Silva, a divorce coach. The couple, who have a significant age gap, shared the news of their upcoming nuptials at the Vogue Arabia Ball 2026, marking what will be Mohamed Hadid's third marriage. The announcement has drawn considerable media attention, given his high-profile family and his history in the public eye.

<!--more-->

Keni Silva, who works as a divorce coach, has been a steady presence in Hadid's life leading up to this engagement. The couple's decision to formalize their relationship has been met with interest from various fashion and lifestyle publications, including Page Six and Vogue Arabia. The engagement represents a new chapter for the 76-year-old developer, who has been a frequent fixture in celebrity news for decades.

Family members, including his famous daughters, have yet to make official public statements regarding the engagement, though the news has circulated widely across social media and entertainment platforms. The transition from a divorce coach to a future spouse has been noted by many as an ironic twist, given the complexities of high-profile separations often seen in Hollywood. 

As preparations for the wedding begin, the couple seems focused on their future together. The engagement serves as a reminder that personal milestones for high-net-worth individuals continue to captivate the public imagination, regardless of the surrounding discourse. The couple is expected to host a ceremony that reflects their shared interests and social standing within the luxury community.
