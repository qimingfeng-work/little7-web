---
title: "Amazon Partners with Uber Eats for Prime Delivery Services"
date: Thu, 05 Nov 2026 11:00:00 +0000
lang: "en"
mode: "llm_rewrite"
source_url: "https://techcrunch.com/2026/11/05/amazon-ditches-grubhub-taps-uber-eats-for-prime/"
source_name: "TechCrunch"
draft: false
---

In a significant shift for its logistics and service offerings, Amazon has officially announced a new partnership with Uber Eats. This collaboration designates Uber Eats as the primary restaurant delivery partner for Amazon Prime members across the United States, marking a departure from previous arrangements, including the company's prior association with GrubHub.

<!--more-->

This strategic move is designed to enhance the value proposition of the Prime membership program. By integrating Uber Eats' extensive network of restaurant partners, Amazon aims to provide its subscribers with a more seamless and reliable food delivery experience. The integration is expected to allow Prime members to access various delivery perks and promotions directly through the Amazon platform, leveraging Uber's robust delivery infrastructure.

Industry analysts suggest that this partnership is part of Amazon's broader strategy to keep Prime members engaged within its ecosystem. By expanding beyond traditional retail and grocery delivery into the restaurant sector, Amazon is positioning itself as a comprehensive service provider for daily consumer needs. For Uber Eats, the deal represents a massive expansion of its potential customer base, tapping into the millions of existing Prime subscribers who may not have previously utilized their platform.

While the transition involves moving away from GrubHub, the move signals a consolidation of services aimed at optimizing delivery efficiency. As the competition in the 'quick-commerce' and food delivery space intensifies, Amazon's decision to align with a major player like Uber Eats reflects a focus on scale and reliability. Customers can expect to see these new features rolled out as the companies align their technical systems to ensure a smooth transition for users across the country.
