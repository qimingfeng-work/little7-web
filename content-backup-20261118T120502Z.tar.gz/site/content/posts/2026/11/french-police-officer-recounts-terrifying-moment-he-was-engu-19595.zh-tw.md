---
title: "巴黎騷亂持續，一名警察在抗議中遭燃燒瓶襲擊受傷"
date: Sun, 01 Nov 2026 09:15:26 +0000
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://github.com/l0ng-ai/openidea"
source_name: "Hacker News"
draft: false
---

法國巴黎近期爆發激烈騷亂，一名匿名警官在街頭衝突中被抗議者投擲的燃燒瓶擊中，制服瞬間起火，幸得同事及時撲救。該起事件加劇了法國國內關於公共安全、執法策略及抗議暴力程度的討論。

<!--more-->

目前，當局正就針對應急人員的暴力行為展開調查。
