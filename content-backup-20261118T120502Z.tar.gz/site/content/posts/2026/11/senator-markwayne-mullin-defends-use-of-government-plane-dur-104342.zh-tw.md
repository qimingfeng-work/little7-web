---
title: "FAA 停飛期間搭乘政府專機觀賽，參議員馬克韋恩·穆林引發爭議"
date: 2026-11-17T19:07:56Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMitwFBVV95cUxNNnJnaU9Ra3R2WnpSSXN0eFJXc0Z1UlhVb0dKWkxXMlFzNVdrN3h6eEs0aGxOYk9OZUREcTFTYUVYLTFuWDI4MnVWR1FIYklBSTZUMHg1VDdVbnJ2alVtOFBPczNUYzhoWERxUnVjX3hNM21KMExxOS1SbkpLN0pBSXVZaTRmTHZWam9ySUc0Y19ydVRMWGlwWm1fRWtXTVJCNzVidUhtYi04SWtjNjNFdFJuemlqR2M?oc=5"
source_name: "PBS"
draft: false
---

參議員馬克韋恩·穆林（Markwayne Mullin）近日因被報導在聯邦航空總署（FAA）全國停飛導致數千名美國旅客滯留期間，使用政府專機前往觀看大學美式足球賽，而面臨嚴格審查。

<!--more-->

這起涉及前往路易斯安那州立大學（LSU）對戰德州大學比賽的行程，引發了關於民選官員使用納稅人資助資源是否適當的激烈辯論。批評者指出，該航班的時間點特別缺乏敏感度。

當 FAA 發布罕見的停飛令，導致全美航空交通癱瘓，無數家庭與商務旅客滯留在機場時，一位在職參議員使用政府專機去參加體育賽事的畫面，招致了政治評論員與公眾的強烈譴責。

此爭議凸顯了高層政府官員享有的特權，與其所代表的選民在日常生活中面臨的困境之間，日益緊張的關係。穆林參議員在辯護中堅稱，他的行程安排符合現行法規，且對其日程而言是必要的。

他辯稱，使用該飛機並非濫用公款，而是國會議員平衡專業職責時的後勤需求。儘管他提出了說明，但這種情況的觀感卻難以處理，包括 CNN 與《紐約時報》在內的主要新聞媒體，都強調了參議員的機動性與航空危機期間公眾廣泛挫折感之間的強烈對比。

此事件重新引發了關於政府差旅透明度與問責制的更廣泛對話。雖然官員常以安全與日程需求作為使用私人或政府包機的理由，但公眾日益要求更高的行為標準，特別是在國家面臨不便之時。

隨著事件餘波持續，參議員面臨持續壓力，需解釋為何在國家航空基礎設施實質癱瘓期間，他的私人行程具有優先權。
