---
title: "Une frappe aérienne israélienne contre l'hôpital Nasser à Khan Younis fait au moins six morts et de nombreux blessés"
date: 2026-11-12T03:32:54Z
lang: "fr"
mode: "llm_translate"
source_url: "https://www.bbc.co.uk/news/articles/ckzd9p7e4eqeo?at_medium=RSS&at_campaign=rss"
source_name: "BBC World"
image_url: "https://ichef.bbci.co.uk/ace/standard/240/cpsprodpb/61be/live/ca670730-de47-11f1-9cac-a1aa02a901fa.jpg"
draft: false
---

Une récente frappe aérienne israélienne a pris pour cible l'hôpital Nasser, situé à Khan Younis dans le sud de la bande de Gaza, entraînant la mort d'au moins six personnes et en blessant au moins vingt autres.

<!--more-->

Selon les déclarations officielles émanant des responsables de l'agence de la défense civile de Gaza, le bombardement a touché de plein fouet le département de chirurgie de l'établissement médical, provoquant des dégâts structurels considérables au sein de l'infrastructure de santé.

Cet événement dramatique a immédiatement suscité de vives préoccupations internationales concernant la protection et la sécurité des infrastructures médicales dans la zone de conflit.

Le service de chirurgie, qui constitue une zone absolument vitale et critique pour la prise en charge des patients souffrant de traumatismes graves, a été sévèrement endommagé, compliquant de manière drastique les efforts des équipes médicales pour prodiguer les soins indispensables aux personnes déjà affectées par les hostilités en cours.

Des équipes de premiers secours et des unités de la défense civile ont été rapidement déployées sur les lieux afin de déblayer les décombres et de transférer les blessés vers d'autres unités médicales encore opérationnelles, bien que la capacité d'accueil de ces structures alternatives demeure extrêmement tendue et saturée.

Les organisations humanitaires internationales n'ont cessé de rappeler le statut particulier de protection dont bénéficient les hôpitaux en vertu du droit international humanitaire.

Toutefois, le contexte de guerre a trop souvent vu des structures sanitaires prises dans des tirs croisés ou ciblées en raison d'allégations persistantes concernant la présence d'activités de miliciens en leur sein.

Dans ce cas précis, les répercussions directes sur le service chirurgical soulignent la situation extrêmement précaire dans laquelle se trouvent les patients et le personnel soignant, contraints d'exercer leurs fonctions au mépris d'un danger constant.

Alors que la situation sur place demeure extrêmement volatile, les autorités locales continuent d'évaluer l'ampleur exacte des dégâts matériels et le bilan définitif des victimes, tandis que la communauté internationale observe avec une inquiétude croissante la détérioration continue des conditions humanitaires dans l'enclave palestinienne.
