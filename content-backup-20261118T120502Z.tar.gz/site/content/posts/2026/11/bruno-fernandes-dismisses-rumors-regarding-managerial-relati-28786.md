---
title: "Bruno Fernandes Dismisses Rumors Regarding Managerial Relationship"
date: Wed, 04 Nov 2026 00:45:33 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://www.bbc.co.uk/sport/football/articles/cqkg5dgvygr1o?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
draft: false
---

Manchester United captain Bruno Fernandes has firmly pushed back against recent media reports concerning his professional relationship with club head coach Michael Carrick, describing the circulating stories as completely untrue. Speaking to sports journalists, the midfielder expressed frustration over what he characterized as a barrage of falsehoods propagated in the public sphere.

<!--more-->

Fernandes stressed that unity and clear communication within the squad are paramount as the team navigates a demanding competitive season. Addressing the media directly, he clarified that speculations regarding any friction behind closed doors at Old Trafford are unfounded and intended to manufacture unnecessary controversy around the coaching staff and senior players.

Club supporters and football analysts have largely welcomed the definitive statement, viewing it as an attempt to stabilize the locker room environment and maintain focus on upcoming fixtures. Maintaining harmony between key players and the coaching staff remains essential for Manchester United as they strive for consistency and success in domestic and European competitions.
