---
title: "Tensions au sein de l'équipe de transition : Trump envisage de remplacer Pete Hegseth au Pentagone"
date: Wed, 04 Nov 2026 22:29:42 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMi1gFBVV95cUxQMklJaVBENktZYUVEYUZwYUZCVEtYZ0M3X0R2Tll4NGFxU0NrQjgwVUZWdklLMXN2TDVjRlFYTURmVU1ZY01TWVdqZlZOQ0FsN3k5Q2diSGVMT2ZJSDYzdjVaUDhyMkZZak52Wm5JcmxYaXVvNzNYN1pkNWhiZkVjbHBxZlc2RE8wUGlOMUsxYWlDN0NrTExWcWFIT05wR2VHY0JyRFJBZWJqcGl3M2VPS3RQTmlld0JJdEN0TTFFeHZsRHliMFhMLXlUUHV2Zll4WWZvVWN3?oc=5"
source_name: "WKMG"
draft: false
---

Au lendemain d'un cycle électoral de mi-mandat éprouvant, le président élu Donald Trump évaluerait l'avenir de sa future équipe de défense.

<!--more-->

Selon des sources citées par CBS News, M.

Trump envisagerait de nommer le gouverneur de Floride, Ron DeSantis, pour remplacer Pete Hegseth à la tête du Pentagone.

Cette délibération interne intervient alors que le Parti républicain est aux prises avec les conséquences politiques de ses récentes défaites électorales, que certains stratèges attribuent à des positions politiques controversées et à des tensions géopolitiques persistantes.

Les rapports indiquent que l'atmosphère au sein de l'équipe de transition est devenue de plus en plus tendue.M.

Hegseth, initialement pressenti pour le poste de secrétaire à la Défense, fait face à des critiques croissantes au sein même des rangs du GOP.

Ce mécontentement découle d'une évaluation plus large de la performance du parti lors des élections de mi-mandat, où des revers inattendus ont instauré un climat de défiance parmi les dirigeants et conseillers républicains.

Le débat a glissé d'une analyse post-électorale classique vers un examen critique de la viabilité des candidats au cabinet pour la nouvelle administration.

Donald Trump lui-même a envoyé des signaux contradictoires concernant l'avenir de M.Hegseth.

Bien que le président élu ait publiquement suggéré que M.

Hegseth pourrait être un choix « très populaire » pour un siège au Sénat représentant le Tennessee, les discussions privées concernant son mandat au ministère de la Défense trahissent un manque de confiance totale.

L'éventualité de faire appel à Ron DeSantis, une figure de proue dotée d'une expérience exécutive significative, indique que M.

Trump privilégie désormais la stabilité politique et la viabilité électorale à l'approche de son investiture.

Alors que l'équipe de transition navigue à travers ces frictions internes, l'attention se porte sur l'impact potentiel de ces changements de personnel sur l'agenda global de l'administration.

Le remplacement possible d'un candidat de haut niveau comme Hegseth souligne la nature volatile du paysage politique actuel, où les résultats des mi-mandat forcent une recalibration rapide de la stratégie et des nominations.

Il reste à voir si cela mènera à un changement formel au Pentagone, mais ces délibérations soulignent les enjeux élevés liés à la constitution d'un cabinet capable de gérer simultanément les pressions politiques intérieures et les défis de sécurité internationale.
