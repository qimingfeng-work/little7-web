---
title: "Le gouvernement britannique s'apprête à assouplir ses objectifs de vente de véhicules électriques"
date: Mon, 09 Nov 2026 14:29:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMirAFBVV95cUxNc3FXbmdXYVFyM20xR3E5RW91VUdEWEMySzJZaGphTVhrdXRfNW5ZLUlzZVYyQVRuVVJicGdKYUpDSkdqMEdjY0RraTNNMjE1X3JFQUFHRFMzUThtMTdIeUVzWklXMUZBQTdVc1hYVjlCN3lncU9lRWF0Y2JQOXBWb3loZDJNdlAyOXFpSGplalYwdkJ0ZDF4QndYYTlxNjB5WndkcjVZYm1KbWJo?oc=5"
source_name: "The Telegraph"
draft: false
---

Le gouvernement travailliste britannique s'apprêterait à revoir à la baisse ses objectifs ambitieux en matière de vente de véhicules électriques (VE), dans le cadre d'un recul plus large concernant certains de ses engagements relatifs à la neutralité carbone.

<!--more-->

Faisant suite à une contestation importante de la part de l'industrie automobile, qui a éprouvé de grandes difficultés à respecter les délais de transition rapide imposés, le cabinet devrait annoncer une réduction de ses objectifs fixés pour l'horizon 2030.

Des rapports concordants suggèrent que l'objectif de vente de VE pourrait être ajusté à hauteur de 60 %, témoignant ainsi d'une approche beaucoup plus pragmatique de la stratégie de décarbonation du pays.

Cette décision d'atténuer ces objectifs intervient après un intense travail de lobbying mené par les dirigeants de l'industrie, qui ont fait valoir que les buts initiaux étaient totalement irréalistes au vu des limitations actuelles des infrastructures de recharge et de la demande réelle des consommateurs.

Bien que le gouvernement demeure officiellement attaché à ses objectifs environnementaux à long terme, cette mesure représente un changement tactique face aux réalités économiques et logistiques incontestables.

Cet ajustement devrait être officiellement dévoilé dans le courant de la semaine, marquant une évolution notable dans la trajectoire de la politique climatique du gouvernement.

Ce virage politique a déclenché un débat plus vaste au sein de la société sur la recherche d'un équilibre délicat entre l'ambition environnementale et la stabilité économique.

Alors que certains groupes de protection de l'environnement ont vivement critiqué cette mesure, la qualifiant de recul pour l'agenda vert du Royaume-Uni, les parties prenantes de l'industrie ont quant à elles salué cette flexibilité bienvenue, soulignant qu'une transition plus graduelle permettra aux fabricants et au secteur de l'énergie d'aligner plus efficacement leurs investissements.

Alors que le gouvernement navigue à travers ces pressions concurrentes, l'objectif primordial reste de garantir que la transition vers la mobilité électrique demeure à la fois durable et économiquement viable pour la nation.
