---
title: "任天堂《塞爾達傳說：時之笛》重製版預購遭亞馬遜推遲，玩家群體引發熱議"
date: Thu, 05 Nov 2026 13:38:32 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMi0wFBVV95cUxQbmZkVWNfRVBRQzlHM0loNXFQN2dvOGVZWkJVb0gxc2hCNmRqd2ZwT25Hcl9pb19DN2dHNEVOLWt1MC1teFdUYnNyallWR2kxSERWR25kdFNnM2czSjVScHh0bUN4QVVEYzUyTnpvRF9yYmRmdERuS2JSNGZQRkNiWGdOUW5hMFU2YTZQdUE0Wmo3Z2RCOC1zVjJEcDBNbUVoR011VG5JTloxeThXMkJCaTdhM2tvOUozRG93LUpZX3RUemZac2JtcGg2S3ZKb19xMjNn?oc=5"
source_name: "Kotaku"
draft: false
---

近日，遊戲界因亞馬遜突然推遲大量《塞爾達傳說：時之笛》（The Legend of Zelda: Ocarina of Time）重製版的預購訂單而陷入混亂。

<!--more-->

這款備受期待的作品將登陸任天堂Switch 2平臺，由於其在遊戲史上的經典地位，許多粉絲早在數月前便已支付定金鎖定購買資格。然而，亞馬遜突如其來的延遲通知令大量消費者措手不及，迫使他們紛紛轉向其他零售商，社交媒體及各大遊戲論壇上充斥著玩家的抱怨與不滿。

任天堂對這款重製版寄予厚望，將其視為假日銷售策略的核心支柱。通過重塑這款近30年前的經典之作，任天堂旨在連線懷舊的老玩家與新一代遊戲受眾。

該遊戲被視為任天堂當前硬體推廣戰略的基石，而此次分銷環節出現的物流問題，無疑為原本盛大的釋出活動蒙上了一層陰影。在部分地區，由於粉絲對該作的期待值極高，甚至出現了在零售店門口徹夜排隊，以確保能在午夜首發時第一時間拿到遊戲的盛況。

行業專家分析認為，此次延遲可能與全球供應鏈的複雜性有關，或是零售商未能預料到如此巨大的市場需求。儘管預購受阻，但玩家對該作的熱情並未減退。

任天堂持續通過其“開發者訪談”（Ask the Developer）系列節目進行宣傳，深入剖析重製版背後的技術革新與創意過程。在玩家等待訂單履行的同時，這一事件也再次提醒業界，協調全球高需求娛樂產品的同步發售是一項極具挑戰的任務。

來源: Kotaku
