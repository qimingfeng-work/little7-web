---
title: "輝達執行長黃仁勳捲入間諜疑雲，股東提告引發治理危機"
date: Tue, 10 Nov 2026 05:05:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMikgFBVV95cUxQQmYzb2FsbEhkaFhoajJOUWQtVTlISTJDczRlUHJydUJHaXpmcmlObGcwbzNndFVub296REhvNHRuZDZ6NkFrRHJCdVJyVjZnSGlkZW8tM2loOGFVaHNEa2xScDYxdFVlckdaa2VTTUEzVW96aDRpMnVITFFfdUQyNFlHQlRoSUhpM1BhNTZPWXF5dw?oc=5"
source_name: "Business Insider"
draft: false
---

輝達（Nvidia）執行長黃仁勳近期因其個人生活及與中國女商人 Alice Huang 的疑似關聯，成為輿論風暴中心。事件已從私下的猜測演變為公開的審查，多家媒體報導了一系列記錄兩人多年互動的照片。

<!--more-->

隨著股東對輝達及黃仁勳提起法律訴訟，指控執行長與一名被部分報導指為潛在中國情報人員的女子有所往來，事態已變得極為嚴重。這些指控的影響深遠，特別是考慮到輝達在全球半導體產業的關鍵地位及其在敏感技術領域的深度參與。

此爭議引發了高層人士的反應，包括前總統唐納·川普（Donald Trump）近期表示，黃仁勳曾主動聯絡他，澄清自己並不知曉 Alice Huang 的間諜活動指控。

儘管有此保證，局勢依然動盪，市場分析師與產業觀察家正質疑此醜聞是否會影響輝達的公司治理與長期穩定。隨著法律程式展開，焦點仍集中在執行長的個人交往是否可能損害國家安全利益或違反公司政策，進而威脅到他職業生涯中精心打造的「完美」公眾形象。

來源: Business Insider
