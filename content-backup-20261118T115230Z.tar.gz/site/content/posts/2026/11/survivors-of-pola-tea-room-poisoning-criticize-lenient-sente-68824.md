---
title: "Survivors of Pola Tea Room Poisoning Criticize Lenient Sentencing as Health Struggles Persist"
date: 2026-11-12T03:38:07Z
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiUEFVX3lxTE9BeTBhLWtuLVVMbVIyTUpXU0JHU0JZTjBVWHRiTFFzT0RycEh0UUhXVGVkWnVhb0NVN3JDNVNtVzRjYzRzTFRNckI4bDh1WXdC0gFWQVVfeXFMUDNBVExGZ1hyell6bzY1SEZMTi1NX1ltQ3UwdTV1d3V0blI4TTgwWE4zV3VxNzZmY3VHU3BTaXpVVTlZQ1o1d256NmpTR3BpU01rU21QRHc?oc=5"
source_name: "udn"
draft: false
---

The recent court ruling regarding the fatal food poisoning incident at Pola Tea Room has sparked significant public outcry and deep frustration among the victims. With six lives lost in the tragedy, the district court's decision to sentence the owner, Li Fang-hsuan, to only one year and ten months in prison has been widely criticized as inadequate. For those who survived the ordeal, the legal outcome feels like a failure of justice, especially as they continue to grapple with severe, long-term health consequences.

<!--more-->

One survivor, who recently met with legislator Shen Po-yang to discuss food safety reforms, expressed profound disappointment with the verdict. The survivor revealed that their health has deteriorated to such an extent that they are now facing the prospect of long-term dialysis. The physical and financial toll of the incident is ongoing, making the relatively short prison sentence feel like an insult to the suffering endured by the victims and their families.

Legislator Shen Po-yang confirmed the meeting, noting that he listened to the survivor's concerns regarding the current state of food safety regulations and the perceived leniency of the judicial system in such cases. The dialogue highlighted a growing sentiment that existing laws are insufficient to hold business owners accountable for catastrophic failures in food hygiene and safety management.

Taipei Mayor Chiang Wan-an also weighed in on the controversy, echoing the public's dissatisfaction. Chiang argued that the current penalties under the Food Safety Act are not stringent enough to serve as an effective deterrent against such negligence. He emphasized that the government must re-evaluate the legal framework to ensure that justice is served for victims of food poisoning and that businesses are held to a much higher standard of accountability. As the debate continues, the case has become a focal point for broader discussions on how to strengthen food safety protections in Taiwan to prevent future tragedies.

Sources: udn
