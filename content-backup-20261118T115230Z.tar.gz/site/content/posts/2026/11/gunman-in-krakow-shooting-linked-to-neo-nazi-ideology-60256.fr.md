---
title: "Fusillade tragique à Cracovie : les influences idéologiques du tireur révélées"
date: Tue, 10 Nov 2026 15:39:14 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMisAFBVV95cUxQUWZjZEQ0Vk5jTkRJNHJVTkNSaVZwNW5Jb0R1enEyZDkzWlJBMXVaU3V2end5V0NBQVQ2ZWpEdFJ3RTRLYU1yOEtDTHpwa1FlVmVTbkpfcndRMHQxeGt2U2ZJVFpiYjYtTWpfelozLWZWRmx3bGxzTE4tOWgyemEtWktlMEJSTDR4ZHhHYVQyVXBYekhHRmVfNTF6YS11WEtzQ3VxXzBFQXNCMmtEYmNYdNIBtgFBVV95cUxNTGFnT2Juck1qajdCdV9YNGVEdm1wVEZMSTZHaU93WE9BSGprQ0h3U3BhVXFtWGNEUUx6em41S054bFk3RlgyWTdCVE1fWWpLM2IzbnJ5MmtUV3p6WDF1cnByT2RVdXVwUktXamVMMXBCT3BOOEpTTUxuNENNOEVVNERHVDQwT3NoQk94eXJaTmJPeC1vQTdHNFNRb3dGMkhjWDVzb1VZdlhZMmdYcWFEdkQwd2JFZw?oc=5"
source_name: "Al Jazeera"
draft: false
---

Une fusillade tragique à Cracovie, qui a entraîné la mort de six personnes, a pris une tournure sombre alors que les enquêteurs révèlent les influences idéologiques troublantes du tireur.

<!--more-->

Les autorités polonaises ont confirmé que l'auteur était profondément fasciné par Anders Behring Breivik, le tueur de masse néo-nazi norvégien responsable des attentats terroristes de 2011 en Norvège.

Cette révélation a provoqué une onde de choc en Pologne, déclenchant un débat national sur la montée de la rhétorique extrémiste et l'influence des groupes de haine internationaux.

L'attaque, qui a également blessé un jeune de 19 ans originaire de York, a dévasté la communauté locale.

Parmi les victimes figurait un peintre « exceptionnel », dont la mort a été pleurée par ses amis et collègues.

En signe de solidarité et de deuil, des milliers de personnes ont rejoint une marche silencieuse dans les rues de Cracovie, honorant les victimes et condamnant la violence qui a brisé le sentiment de paix de la ville.

Les responsables gouvernementaux ont déclaré que le tireur avait visité des sites web dédiés à Breivik et à d'autres figures extrémistes, suggérant que l'attaque n'était pas un acte de violence aléatoire mais une manifestation calculée de croyances radicalisées.

L'incident a suscité des appels à une surveillance plus stricte du contenu extrémiste en ligne et à une approche plus robuste pour identifier les individus susceptibles d'être à risque de radicalisation.

Alors que l'enquête se poursuit, les dirigeants polonais se sont engagés à soutenir les familles des victimes et à prendre une position ferme contre les idéologies qui ont alimenté cette tragédie insensée.

Source: Al Jazeera
