---
title: "Noel Fielding sort de son silence après la condamnation de Russell Brand"
date: 2026-11-13T21:18:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMilwFBVV95cUxOM3ZRWFJ4bWVyclZ5YjZkY2EyN1JCVzJiVlhBSFJZN1hxaEdJZVFHR3kxSTlaQlcxSXdPLUJ5ZU5qa3ExSVc3WHRpVmYzR0hfQ2tJUGxQVEM1ZWVKeUU4NDZmcWZFWVBIQkg5R1BpeUp4aXpZUmVEWFdhZ2Z5R1MtZ0picG02bFRFU1RBNHlqMTl4dVFzSndn?oc=5"
source_name: "The Sun"
draft: false
---

L'humoriste et présentateur de l'émission 'Bake Off', Noel Fielding, a officiellement rompu son silence concernant la récente condamnation pénale de son ancien partenaire de scène, Russell Brand.

<!--more-->

Dans une déclaration formelle, Fielding a exprimé son profond choc et son horreur en apprenant la nature des crimes commis par Brand, cherchant ainsi à se distancier explicitement des actions qui ont conduit à une condamnation publique généralisée de l'ancien comédien.

Depuis un certain temps, Fielding faisait face à une pression croissante de la part des médias et du public, qui exigeaient qu'il s'exprime sur son ancienne association avec Brand.

Les critiques avaient précédemment qualifié son silence de 'assourdissant', arguant que, compte tenu de leur longue histoire de collaboration professionnelle, une réponse était nécessaire pour clarifier sa position morale.

Avec cette déclaration, Fielding a cherché à répondre à ces préoccupations, en soulignant sa condamnation ferme des comportements qui ont entraîné la chute judiciaire de Brand.

La situation a déclenché un débat plus large sur la responsabilité des personnalités publiques lorsque leurs anciens associés sont impliqués dans des activités criminelles graves.

Bien que Fielding ait tenté de poursuivre sa carrière, notamment à travers son rôle dans 'The Great British Bake Off', l'association passée avec Brand continue d'être un sujet de discussion récurrent dans l'industrie du divertissement.

La déclaration de Fielding constitue une tentative définitive de tirer un trait sur leur relation professionnelle et d'aborder la gravité de la situation actuelle.

Alors que l'industrie du spectacle traite les retombées de cette condamnation, l'attention reste focalisée sur les victimes et sur les conséquences juridiques des actes de Brand.

La reconnaissance publique de Fielding marque un moment significatif dans le discours continu entourant ce scandale, illustrant les défis auxquels sont confrontées les célébrités lorsqu'elles doivent naviguer entre loyautés passées et impératifs éthiques contemporains.

Source: The Sun
