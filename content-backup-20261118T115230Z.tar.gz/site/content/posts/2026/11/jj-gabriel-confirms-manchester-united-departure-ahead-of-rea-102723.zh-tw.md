---
title: "曼聯小將 JJ Gabriel 確認離隊，傳將轉投皇家馬德里"
date: 2026-11-17T22:51:00Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMingFBVV95cUxQMFg2dlR2ZTZDS3I3WUZBLV9WazVnNHBieU1YcC0zSU9KUW1LelBBaU8wUWs2VGV4czBfUXdkRXV3MHBfX3ZhTEE3MVlIOUNKNmtlU05BN083TEZFTWFaeEx0ckN1aFp4Uno2TDVzVjlsVlgxWnhnVUF1amF2UHh2Rnd2STFpRzVQY09RVDN3RnU0MWw2UVNxWS11VFc4UQ?oc=5"
source_name: "The Guardian"
draft: false
---

曼聯青訓小將 JJ Gabriel 已正式確認離開老特拉福德球場，結束了他與紅魔的合約。這位年輕天才透過社群媒體發布了一則感人的告別宣告，表達了對效力曼聯期間的深切感激。

<!--more-->

Gabriel 在宣告中提到，俱樂部給了他許多「永遠珍藏」的回憶，這標誌著他職業生涯中一個重要的轉折點。包括《衛報》、《BBC》及《天空體育》在內的多家主流媒體報導指出，這名小將極可能轉會至西甲豪門皇家馬德里。

據悉，皇馬已關注這名潛力新星一段時間，且談判似乎已圓滿達成協議。儘管轉會的具體財務細節仍是外界熱議的話題，《運動畫刊》更針對交易總成本進行了詳細分析，但目前各界焦點仍集中在球員的未來發展以及兩傢俱樂部的戰略調整上。

Gabriel 的離隊是歐洲頂級俱樂部爭相在球員生涯早期搶先簽下潛力新星的廣泛趨勢之一。對於曼聯而言，這次離隊意味著失去了一名極具潛力的希望之星；而對皇家馬德里來說，這被視為對球隊陣容深度的一項長期投資。

隨著轉會程式進入最後階段，球迷與專家們都期待看到 Gabriel 如何適應伯納烏球場的壓力和高期待。曼聯球迷對此反應不一，儘管他們認可 Gabriel 的天賦，但也理解加盟全球最負盛名的足球機構所帶來的巨大吸引力。

來源: The Guardian
