---
title: "利茲聯 1-0 戰勝熱刺：奧卡福制勝球背後的爭議與反思"
date: Sat, 07 Nov 2026 20:44:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMilwFBVV95cUxNbTk3SkdsVUJCZEwyYlNVcHpmV1pvVVRVSnJiSDB0TDl0STJrY3Buem5Pcmt4S1RSclRqTXNuWmhNT1VKb3cyYUZMS2dVMXJvamUyaFhiak85UmtSamdJaU1wRWZ4bFdQNVNtNFlhZ1Q2S0FCR19vOFQ3UGh4Z1ZHZFllNUxEbDJwc0VGd2VpRHVMQTZYQWpj?oc=5"
source_name: "The Guardian"
draft: false
---

利茲聯隊憑藉諾亞·奧卡福（Noah Okafor）的關鍵進球，以 1-0 艱難戰勝托特納姆熱刺隊，終結了此前五場不勝的尷尬紀錄。

<!--more-->

儘管這場勝利對利茲聯而言是急需計程車氣提振，但比賽過程卻被傑登·博格（Jayden Bogle）對馬蒂斯·特爾（Mathys Tel）的一次鏟球爭議所籠罩。據報道，托特納姆熱刺已向職業比賽裁判有限公司（Pro Ref）表達強烈不滿，質疑為何該動作未被判罰紅牌。

比賽本身過程緊張，雙方在開局階段均難以找到節奏。下半場奧卡福的進球成為全場唯一亮點，幫助利茲聯走出低谷。

然而，賽後的輿論焦點完全被博格的鏟球動作佔據。許多觀察家認為該動作極其魯莽，理應受到比黃牌更嚴厲的處罰。

熱刺管理層對此表示憤慨，強調此類動作可能導致嚴重傷病，並質疑裁判決策對比賽公平性的影響。受害者馬蒂斯·特爾目前正在接受醫療觀察，這進一步加劇了熱刺方面的抗議緊迫性。

此次事件再次點燃了關於英超裁判判罰一致性以及影片助理裁判（VAR）在審查此類動作時所扮演角色的激烈辯論。對於利茲聯而言，這場勝利是賽季的重要轉折點。

教練組對球隊在面對頂級對手時展現出的韌性感到滿意，特別是在防守端守住了微弱的領先優勢。然而，博格鏟球引發的爭議陰雲可能會沖淡勝利的喜悅，俱樂部目前正準備應對聯賽管理機構可能進行的審查。

隨著調查的深入，足球界對此事的看法依然分裂：一方認為應尊重裁判的現場判罰，另一方則堅持認為未將博格罰下是影響比賽結果的重大失誤。未來的焦點將轉向聯賽官方的正式回應，以及該事件是否會促使英超對類似鏟球動作的判罰標準進行調整。

來源: The Guardian
