---
title: "La NASA lance son recrutement pour le programme Artemis : vers une présence humaine durable sur la Lune"
date: Sun, 08 Nov 2026 16:50:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMijwFBVV95cUxOc3Z0WDBDc21jMkVBYW5qMjdab0NVUWFuN2JFaVBiMnhkbFg2TndoT1BjSTJzeUlxQ3JiLURiMkNSaFQtZmdHUWQ5aUE1NE8ySHFHQTk0bnVTTXhZYkxrMWtVR3ZNNUNaYzRSelJrU2Z0cGd3UUZIWDZYN09KZl9uRmUyaTdoTGdoR1BnNHA4UQ?oc=5"
source_name: "The Guardian"
draft: false
---

La NASA a officiellement ouvert ses portes à la prochaine génération d'explorateurs spatiaux en lançant une campagne de recrutement ambitieuse.

<!--more-->

L'objectif est clair : trouver les individus qui vivront et travailleront sur la Lune dans le cadre du programme Artemis.

Cette initiative marque une étape charnière dans l'histoire de l'humanité, visant non seulement le retour sur la surface lunaire, mais aussi l'établissement d'une présence durable, véritable tremplin pour les futures missions habitées vers Mars.

L'appel à candidatures a suscité un intérêt mondial, les médias soulignant le caractère historique de cette mission.

Le programme Artemis dépasse le cadre de la simple exploration ponctuelle ; il s'agit de construire une infrastructure pérenne.

Les candidats retenus auront pour mission de mener des recherches scientifiques de pointe, de tester des technologies innovantes et de résoudre les défis logistiques complexes liés à l'habitation en milieu spatial profond.

La NASA a précisé qu'elle recherche une grande diversité de profils, allant de l'ingénierie à la médecine, en passant par des expertises scientifiques spécialisées.

Ce projet représente un jalon majeur pour le programme spatial américain, qui s'appuie désormais sur des partenariats internationaux et commerciaux pour étendre l'influence humaine au-delà de l'orbite terrestre basse.

Le processus de sélection sera extrêmement rigoureux, mettant l'accent sur la résilience psychologique, l'aptitude technique et la capacité à travailler efficacement dans des environnements isolés et à haut risque.

Pour les futurs astronautes, cette opportunité offre le privilège unique d'être aux avant-postes de l'histoire de l'exploration spatiale.

Alors que l'agence progresse, l'accent reste mis sur la constitution d'une équipe robuste, capable de répondre aux exigences extrêmes de la vie lunaire et d'assurer le succès de missions de longue durée.

gov), NBC News, KTLA

Source: The Guardian, The Washington Post, NASA (.
