---
title: "Haas Retains Rafael Camara for Las Vegas Grand Prix with Driver Lineup Adjustments"
date: 2026-11-16T08:35:56Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMia0FVX3lxTE4wbWQ5UHF5TnFHUEM4TlFEUFppOHNacWR4MEdoOHExRk9mWDdFT1pOQVZ6NUw4RlY1Z3pZZHFfRkU0NTlRSGlsaGNJMlljSWlNb0M5cGl1TmNNUUhmUWw0bmlKd0wzdzM4ems0?oc=5"
source_name: "BBC"
draft: false
---

The Haas Formula 1 team has officially confirmed its driver lineup plans for the upcoming Las Vegas Grand Prix, opting to keep promising Brazilian talent Rafael Camara in the cockpit for the main race. The decision comes as teams finalize their strategies for the high-stakes street circuit in Nevada, where precision and adaptability are paramount.

<!--more-->

Alongside Camara's continued participation, Haas has announced notable adjustments to its practice sessions. Ryo Hirakawa is slated to step into the car during the opening Free Practice session (FP1), providing valuable feedback and data collection for the team. This dual approach allows Haas to balance the development needs of experienced drivers with the ongoing evaluation of emerging racing talents.

Camara's retention highlights the team's confidence in his performance capabilities as the motorsport season enters its critical final stretch. Navigating the unique challenges of the Las Vegas Strip Circuit requires absolute focus, and team principals believe that maintaining continuity with Camara while integrating fresh insights from Hirakawa will yield the best competitive advantage.

Motorsport enthusiasts and fans of the sport are closely watching how these strategic lineup changes will influence team dynamics and track performance under the bright lights of Las Vegas. Free practice sessions will offer the first glimpse of how the modified roster adapts to the demanding layout.

Sources: BBC
