---
title: "Wolfenstein 3 Officially Confirmed to be in Development at MachineGames"
date: 2026-11-13T00:30:00Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMinAFBVV95cUxPN3RRMzAwRF9wVHJId3JqYXpmZi1JeXZ1LVM0TjFGQnVLOXpKck9RYkxadDg2QzNNaTdZNFpLWndhVHhiRC1oZFBQWFA3cENUTGtnMlplZi1yczNSUHNCdG1BRnR3bFRtSkE5WHNsRkVJTVZzbFdUZlFhRlpmelNBamlWejY0bXVOcngtR19KdEhPdXNqTzBSM210aEw?oc=5"
source_name: "Push Square"
draft: false
---

The long-standing speculation surrounding the future of the Wolfenstein franchise has finally been put to rest. MachineGames, the studio renowned for its work on the series since the 2014 reboot, has officially confirmed that the next installment, colloquially referred to as Wolfenstein 3, is currently in active production. This announcement has been corroborated by various industry reports and statements from key figures within the gaming sector, including Xbox leadership.

<!--more-->

Since the release of Wolfenstein: Youngblood in 2019, fans have eagerly awaited news regarding a direct sequel to the mainline narrative that concluded with Wolfenstein II: The New Colossus. While MachineGames has been busy with other high-profile projects, such as the development of Indiana Jones and the Great Circle, the confirmation of a new Wolfenstein title signals that the studio is returning to its roots. The news has been met with significant enthusiasm across the gaming community, as players look forward to continuing the fight against the regime.

While specific details regarding the plot, setting, or release window remain under wraps, the confirmation serves as a major milestone for Bethesda and its parent company, Microsoft. As the industry shifts toward larger, more ambitious titles, the return of such a storied first-person shooter franchise is expected to be a cornerstone of the Xbox gaming portfolio. Fans are now closely watching for official trailers or further updates from Bethesda Softworks as development continues to progress.

Sources: Push Square
