---
title: "Tarik Skubal Free Agency Heats Up: Mets and Dodgers Among Six Teams in Pursuit"
date: 2026-11-17T08:40:50Z
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMinANBVV95cUxPMXg5N2Z6RExDNzNBQkE2aWloYkh2YkVGaW03YWNHbTBDaFJOQUJlRDVfWFZVQVZoUUhaYXFwMk5rLXppOEZkMGd3TWpWU3kwRmRCQzNTZVpYZlk1NUctTEctd2NWVjh6OXZOa0hnS0ttbDhIMWR2NzE1dnk4cGVESDJ1ZU9LWlJqQTJGMHlmNWlSNVZhcGtqeVNFMWprRjd5WWVGNW5IQnN2dW1ZUWRZYUU3TnBEQzNENWVTbDlfamo4MDZ3VTljXzZ3blplcU1ZbUVRRy1Kbk54Y3lmTHdfYmMzdDF4VndEZFotU0ptaGJwLWgtaTI0SHRscWRtaDlzeGJzV2hHUko4bFBGdjB2MUVkTlJyRExOSnpfVU53cW9udk0tSFBYNjhITXh0ZDdGaFRkZTBfQ3BNVHZWN08xWDBnRGEyOXRVRUwxdVVidzBtTnpzTzgzV0RkTVNncHFxMGtKa1pLR1Q2WWZBbTkxRDlwU050ZlRaTzBrVkRyM2JQeTdJdWt0a1pMcTJRNk5WcGdicThSUkZVbkxl?oc=5"
source_name: "Yahoo運動"
draft: false
---

The race to sign star pitcher Tarik Skubal has officially intensified, with reports indicating that the New York Mets have already held face-to-face meetings with the player in Los Angeles. As the free agency period gains momentum, industry insiders suggest that at least six teams are actively vying for his services, with the Los Angeles Dodgers reportedly leading the pack as a primary suitor.

<!--more-->

Market valuations for Skubal have reached staggering heights, with some projections suggesting a contract potentially worth $350 million over eight years, while more aggressive estimates have floated figures as high as $500 million. These numbers have sparked intense debate among sports media outlets, with some commentators, including those at Sports Illustrated, questioning the wisdom of such massive financial commitments, warning that teams might eventually regret the scale of these deals.

Beyond the Dodgers and Mets, the list of interested parties continues to grow, with the Chicago White Sox emerging as a potential 'dark horse' in the negotiations. The Dodgers' interest is particularly notable given their desire to retain a Cy Young-caliber ace, especially in light of concerns regarding Shohei Ohtani's recovery and health status. As the bidding war unfolds, the baseball world is watching closely to see which franchise will secure the high-demand arm and at what cost to their long-term payroll flexibility.

Sources: Yahoo Sports
