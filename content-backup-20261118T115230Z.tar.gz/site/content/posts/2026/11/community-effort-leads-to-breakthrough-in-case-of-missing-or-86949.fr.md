---
title: "La disparition mystérieuse d'une femme de l'Oregon résolue grâce à la mobilisation de sa communauté"
date: 2026-11-15T04:02:24Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMilgFBVV95cUxOTHo4bEMyZzEwNXVvajRYRWhUTzY5aEVERzRPSzhGU0I4WGtPZ2w2OG1IQmFYQjJfSU8yU1ZZeEV2eV80TGVhY1VIRWp1QlBuZDBFbVU2Y3ZaWFBjUGpvMzhaMUdNU1kwWnJySzR0ejlLbnZuaGZFRjhvZFd2YXVxRzQ1VFhoa0IycU1SSkJqeGRwdG1KVlE?oc=5"
source_name: "CBS News"
draft: false
---

La disparition mystérieuse d'une habitante bien-aimée de l'Oregon et de ses chiens a déclenché une recherche menée par la communauté à grande échelle, fournissant finalement aux enquêteurs les indices essentiels nécessaires pour résoudre l'affaire.

<!--more-->

Susan Lane-Fournier, initialement portée disparue en tant que randonneuse, est devenue le centre d'une enquête très médiatisée qui a attiré l'attention nationale, y compris une couverture par l'émission « 48 Hours » de CBS News.

Lorsque Lane-Fournier s'est évanouie dans la nature, la communauté montagnarde locale a refusé d'accepter la version initiale selon laquelle elle s'était simplement égarée ou perdue dans la nature sauvage.

Amis, voisins et bénévoles se sont unis pour mener leurs propres recherches et maintenir la pression sur les forces de l'ordre afin qu'elles traitent la disparition comme un crime potentiel.

Leur intuition s'est avérée exacte ; alors que les premiers rapports la qualifiaient de randonneuse perdue, ceux qui la connaissaient le mieux soupçonnaient un acte criminel dès le tout début.

La persévérance de la communauté à recueillir des informations et à partager ses inquiétudes avec les autorités s'est révélée déterminante pour guider les détectives vers la vérité.

Au fil de l'enquête, il est apparu clairement que l'affaire était bien plus sinistre qu'un simple accident de randonnée.

L'effort de collaboration entre les résidents locaux et les enquêteurs professionnels a finalement mis au jour la tragique réalité de la situation, permettant l'identification du responsable.

Cette affaire a depuis été mise en avant comme un exemple parfait de la manière dont une communauté soudée peut jouer un rôle primordial dans le processus judiciaire.

En refusant de laisser l'enquête s'essouffler et en fournissant aux enquêteurs un contexte essentiel sur la vie et les habitudes de Lane-Fournier, la communauté a veillé à ce que son histoire ne soit pas oubliée et que les auteurs de sa mort soient traduits en justice.

La diffusion prochaine de l'émission « Murder at Mount Hood » devrait approfondir la chronologie des événements et le tribut émotionnel payé par ceux qui l'aimaient.

Source: CBS News
