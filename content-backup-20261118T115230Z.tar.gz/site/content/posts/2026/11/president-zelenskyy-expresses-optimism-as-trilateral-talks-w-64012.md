---
title: "President Zelenskyy Expresses Optimism as Trilateral Talks with Russia and US Continue in Abu Dhabi"
date: Wed, 11 Nov 2026 08:44:46 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://www.theguardian.com/world/live/2026/nov/11/europe-ukraine-russia-us-talks-abu-dhabi-zelenskyy-latest-news-updates"
source_name: "The Guardian World"
image_url: "https://i.guim.co.uk/img/media/b47f5b5a8987f90d8391829d14e309dddde388a1/320_0_3195_2556/master/3195.jpg?width=140&quality=85&auto=format&fit=max&s=acae4844f6171b647547d91c900186bd"
draft: false
---

Ukrainian President Volodymyr Zelenskyy has expressed a positive outlook following the initial day of trilateral negotiations held in Abu Dhabi. The talks, which involve representatives from Ukraine, Russia, and the United States, are aimed at finding a diplomatic resolution to the ongoing conflict. Zelenskyy specifically highlighted a notable shift in the approach taken by American mediators, noting that he was 'happy' with the changes in their messaging as the discussions entered their second day.

<!--more-->

The trilateral meetings are seen as a critical diplomatic effort to address the hostilities that have devastated the region. US officials have reportedly emphasized their commitment to achieving a 'final end' to the war, a stance that appears to have resonated well with the Ukrainian leadership. As the second day of talks commenced, representatives from both Russia and Ukraine confirmed that the dialogue is ongoing, reflecting a cautious but persistent effort to reach a breakthrough.

The international community is closely monitoring the situation in Abu Dhabi, as any progress made during these sessions could have profound implications for regional stability. The involvement of the United States as a mediator adds a new layer of complexity and potential leverage to the negotiations. While the path to a lasting peace remains fraught with challenges, the willingness of the parties to engage in sustained dialogue is being viewed as a necessary step forward.

President Zelenskyy’s comments suggest a degree of renewed confidence in the diplomatic process, particularly regarding the role of US envoys. As the talks continue, the focus remains on whether these discussions can translate into concrete actions on the ground. The world waits to see if this diplomatic window in Abu Dhabi will lead to a meaningful de-escalation or if the conflict will continue to persist despite these high-level efforts.

Sources: The Guardian World
