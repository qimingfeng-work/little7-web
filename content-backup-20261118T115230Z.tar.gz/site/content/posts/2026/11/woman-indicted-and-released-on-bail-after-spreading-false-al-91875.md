---
title: "Woman Indicted and Released on Bail After Spreading False Allegations Against Shen Po-yang"
date: 2026-11-16T01:01:00Z
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiSEFVX3lxTE54UnlsWHd5Q0stMEtxTkRITXg2YXJXX1FHNGNsRFJGb0ZLeG5mUWR0VzQ4cDNkRnVFWWtUQm1hUG43eFJ4aGk5ZdIBTEFVX3lxTE55OXd3X0tQLTVTZVJzaGozUzFmNVFvSHhHVE82azZvOFBrQXd3U2xPbEM4aUNxb3oxVXZ3QVI2WVJvSWxOLWlRaWhheUw?oc=5"
source_name: "三立新聞網SETN.com"
draft: false
---

A recent legal case involving the defamation of Taiwanese politician Shen Po-yang has concluded with the suspect admitting to the fabrication of malicious rumors. The incident, which gained significant traction online, involved a female netizen who falsely claimed that Shen had invited a woman to a motel. The allegations were quickly investigated by the authorities, leading to a swift legal response.

<!--more-->

Following a thorough investigation by the Investigation Bureau, it was determined that the claims were entirely baseless and intended to influence the outcome of an election. The suspect, after being confronted with evidence of her deceit, confessed to the fabrication. She was subsequently released on a bail of NT$200,000 while awaiting further legal proceedings. The case has served as a stark warning regarding the consequences of spreading disinformation during sensitive political periods.

Public reaction to the incident has been intense, with various political figures and commentators weighing in on the integrity of the electoral process. Critics of the smear campaign, including Taipei Mayor Chiang Wan-an, have questioned why such cases are handled with varying degrees of urgency, suggesting that political bias should not dictate the speed of justice. The suspect, who had initially challenged Shen to take legal action, issued a late-night apology following the bureau's intervention. As the legal process continues, the case remains a prominent example of the challenges posed by online misinformation in modern democratic discourse.

Sources: SETN.com
