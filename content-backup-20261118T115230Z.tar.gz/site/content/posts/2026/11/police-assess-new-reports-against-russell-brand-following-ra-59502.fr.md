---
title: "Russell Brand : la police britannique enquête sur de nouvelles allégations"
date: Tue, 10 Nov 2026 12:21:31 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiuwFBVV95cUxQUUJyMU0zT3kzM0pyaG5oZ1E0cG50YXdqc2dzeXdjbkV6R1hEdWhyWFAwR2RZdnhCdFBzTnRQNk1qREswVDZnY2o2RW9LLXBkMC0tZFZGQzMzdXRPZW1DQ08wUUtLRUlLaHQ1TGhtWnBzcmZfNldMWnV2RWJYNkZwM3N3UlFtbDh0YlBjRHBMbThwcWVxRkw2X25nbzAyOC1GckFXSmctcmxMa2NRdXZhZ1FPYmJtcXhVN01z?oc=5"
source_name: "NBC News"
draft: false
---

La police britannique évalue activement une nouvelle vague de rapports et d'allégations visant le comédien et acteur Russell Brand, suite à sa récente condamnation pour viol et agression sexuelle.

<!--more-->

Brand avait précédemment écopé d'une peine de prison supérieure à dix ans, une étape juridique qui a incité de nombreuses autres personnes à se manifester avec leurs propres récits de mauvaise conduite.

La police métropolitaine et d'autres agences ont reconnu l'afflux de nouvelles informations, notant que des équipes spécialisées examinent chaque rapport avec soin.

Des personnalités éminentes et des défenseurs publics se sont également exprimés sur les problèmes plus larges de contrôle coercitif et d'abus, pointant du doigt un échec systémique à traiter de tels comportements plus tôt.

Des figures de l'industrie du divertissement, dont la productrice Jemima Goldsmith, ont publiquement discuté des expériences éprouvantes liées à l'accusé.

Les experts juridiques suggèrent que ces évaluations supplémentaires pourraient conduire à de nouvelles étapes d'enquête, en fonction de la nature des nouvelles preuves fournies aux forces de l'ordre.

Les groupes de défense ont salué le courage de ceux qui se manifestent, soulignant l'importance de tenir les individus responsables, indépendamment de leur statut de célébrité ou de leur influence publique.

L'affaire continue de susciter un débat national sur la culture de l'impunité dans le milieu du spectacle.

Source: NBC News
