---
title: "水晶宮開季戰績不佳痛失總教練，傳湯馬斯·法蘭克將接掌兵符"
date: 2026-11-12T13:36:00Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMipgFBVV95cUxQcUpUeGthNDhvR1cwLTZXdWFTbXJvTExJc3FGYk1YYkxaazNGc3hoTGVjS0xOWjNmd3Q1MkQzVHF2eVByckNVUklDVkVraFJpRjRmcFpieGtHOG1IVFFyOW5uT0UzR0FiVzU5UEdySGRXUm0yTklLeTdzZEpHSXdlcDRYVmFQVkRlUTZVaGRvbG9sb0I2OGI3Z2d1WTNORjROcmFQUlFn?oc=5"
source_name: "The Guardian"
draft: false
---

英超球隊水晶宮（Crystal Palace）在經歷一連串慘淡的戰績後，已正式與總教練皮埃爾·薩奇（Pierre Sage）分道揚鑣，這讓球隊目前在英超積分榜上敬陪末座。在此之前，薩奇經歷了充滿挑戰的16場執教期，期間他始終難以落實其戰術構想並取得必要的積分。

<!--more-->

在當前賽季已進行10場比賽的情況下，球會高層認為更換領導階層對於避免潛在的降級危機至關重要。球會在官方宣告中感謝薩奇的付出，但也坦承戰績並未達到董事會或球迷的期望。

球迷們對此反應不一，有人認為薩奇因球隊傷兵滿營及陣容侷限而抽到了一手爛牌，但也有人認為他在其指導下的球隊表現存在根本性缺陷。隨著一連串令人失望的敗仗接踵而至，他承受的壓力急遽升高，使得他的帥位變得難以維續。

在開除薩奇之後，據傳水晶宮正與湯馬斯·法蘭克（Thomas Frank）進行深入談判，以延攬他擔任新任總教練。法蘭克以其紀律嚴明的執教風格以及能夠將球隊陣容潛能發揮到極致的能力而聞名，被視為穩定球隊並協助其爬出降級區的理想人選。

據說談判進展迅速，球會希望能在下一輪賽事開打前確認新教頭人選。任命新主帥被視為扭轉球隊命運、恢復球迷信心的關鍵一步。

來源: The Guardian
