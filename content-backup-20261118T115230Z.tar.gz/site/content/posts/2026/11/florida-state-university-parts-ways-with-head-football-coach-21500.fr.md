---
title: "L'Université d'État de Floride licencie Mike Norvell : une transition nécessaire pour le programme de football"
date: Sun, 01 Nov 2026 20:41:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMikAFBVV95cUxOSDlJSTVtRHNYVldhaWN1YVlMbmhlTUlWQjBDeGd1a3l6YkpmeVRZaEctX0gtekZfYTlVQzJlQWxaNU1BeEFNTngzaDFkd1hZdHNsaFNVaHRzR2NudzZWZWVreUk5elZwdHh2bG9sMUxQQVRKbV9uRTlMbTc3M0hObVUtaEN6bmpnVHA2aHhMUzY?oc=5"
source_name: "ESPN"
draft: false
---

L'Université d'État de Floride (FSU) a officiellement mis fin aux fonctions de son entraîneur principal de football, Mike Norvell, marquant un changement de leadership majeur après une saison 2024 décevante.

<!--more-->

L'université a justifié cette décision par la nécessité d'adopter une nouvelle orientation stratégique, les Seminoles ayant peiné à maintenir une constance compétitive, terminant avec un bilan médiocre de 3 victoires pour 5 défaites.

Ce licenciement fait suite à une série de revers pour le programme, dont une défaite récente contre Clemson qui a mis en lumière l'incapacité de l'équipe à surmonter des difficultés récurrentes sur le terrain.

La direction de l'université a conclu qu'un changement fondamental était requis pour stopper la perte de vitesse du programme et entamer le processus de restauration des Seminoles au rang de force dominante du football universitaire.

Norvell, arrivé à Tallahassee avec de grandes attentes, avait pourtant dirigé un programme ayant connu des succès notables, notamment une saison régulière invaincue l'année précédente.

Toutefois, la campagne actuelle s'est révélée incapable de maintenir cette trajectoire.

Malgré le soutien constant de l'administration durant son mandat, la chute rapide des résultats sur le terrain a convaincu les officiels que le programme avait atteint un plateau, rendant un changement de gestion inévitable.

Dans cette phase de transition, le département des sports a entamé la recherche d'un nouvel entraîneur capable de revitaliser l'effectif et de reconstruire la culture au sein du vestiaire.

Les spéculations sur les remplaçants potentiels vont déjà bon train, les experts du secteur compilant des listes de candidats de haut niveau.

Les critères de sélection se concentreront probablement sur les capacités de recrutement, l'innovation tactique et l'aptitude à naviguer dans le paysage complexe du sport universitaire moderne, incluant le portail des transferts et les règles liées au droit à l'image (NIL).

Pour le reste de la saison, la FSU devrait adopter une structure de direction intérimaire, permettant au directeur sportif de mener une recherche approfondie pour un successeur permanent.

Bien que le départ de Norvell ait provoqué une onde de choc parmi les supporters et au sein de l'Atlantic Coast Conference, la direction a insisté sur le fait que cette décision difficile a été prise dans l'intérêt de la santé et de la compétitivité à long terme du programme.

Les fans et les anciens élèves attendent désormais des détails sur la manière dont l'administration compte gérer cette période de transition, alors que la quête du prochain leader des Seminoles commence officiellement.

L'université s'est engagée à la transparence tout au long du processus afin d'identifier un candidat capable de ramener ce programme historique vers les sommets.

Source: ESPN
