---
title: "Le monde du football en deuil après le décès tragique de l'attaquant de Tenerife Jesus de Miguel"
date: Tue, 03 Nov 2026 09:09:18 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://www.bbc.co.uk/sport/football/articles/ck62yvz046pjo?at_medium=RSS&at_campaign=rss"
source_name: "BBC World"
draft: false
---

Le monde du football est en état de choc et en deuil à la suite de la mort tragique de l'attaquant de Tenerife, Jesus de Miguel.

<!--more-->

Le joueur de 30 ans a perdu la vie après avoir subi une blessure fatale lors d'un match comptant pour le championnat de la deuxième division espagnole.

L'incident s'est produit lors d'une action de jeu tout à fait routinière, mais une violente collision sur le terrain a entraîné une détresse médicale immédiate pour l'athlète.

Malgré l'intervention rapide des équipes médicales présentes sur la pelouse et son transfert en urgence vers un hôpital voisin, il n'a pas pu être sauvé.

Jesus de Miguel, qui était une figure respectée au sein de son club ainsi que dans l'ensemble de la communauté du football espagnol, se trouvait au sommet de sa carrière.

La nouvelle de sa disparition a provoqué une onde de choc à travers toute la ligue, entraînant une vague d'hommages de la part de ses coéquipiers, des joueurs adverses et des supporters.

La rencontre a été immédiatement suspendue dès que la gravité de la situation est apparue évidente, et la direction du club a depuis exprimé sa profonde douleur face à la perte de l'un de ses attaquants clés.

Les autorités compétentes et les responsables du football examinent actuellement les circonstances exactes de cette collision afin de comprendre comment un événement aussi tragique a pu se produire au cours d'un match standard.

Pour l'instant, l'attention reste focalisée sur le soutien à apporter à la famille du joueur et à l'effectif du Tenerife alors qu'ils doivent faire face à cette perte soudaine et dévastatrice.

Cet incident tragique sert de rappel sombre des risques physiques inhérents aux sports professionnels et a relancé les discussions concernant les protocoles de sécurité des joueurs lors des matches à haute intensité.

Source: BBC World
