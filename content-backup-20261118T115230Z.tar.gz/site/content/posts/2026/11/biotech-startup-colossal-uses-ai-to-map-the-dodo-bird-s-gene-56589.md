---
title: "Biotech Startup Colossal Uses AI to Map the Dodo Bird's Genetic Resurrection"
date: Mon, 09 Nov 2026 23:22:59 GMT
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMijAFBVV95cUxOUWpKRW51a3A4ZzFSekYyY2lGcjVfOXZvaU1yRGduOTh6aXVyc0E1a1R3WTFzNnpreTlIMU5UNldsYVo1LUxESDd3WWxhTnl0X2Z4cTdHWmhqQTRBUXc2UTVmRUJQX1h6MTVRdnU0MU83Q0ctX0FNWkJWSk4zdGVKbGlnbVJPc2dGTHJ2aA?oc=5"
source_name: "TechNews 科技新報"
draft: false
---

Colossal Biosciences, a prominent biotechnology startup known for its ambitious de-extinction projects, has reached a significant milestone in its quest to bring the dodo bird back to life. By leveraging advanced artificial intelligence, the company has successfully identified 2,300 key genetic targets, effectively creating a 'treasure map' for the dodo's resurrection.

<!--more-->

The dodo, a flightless bird native to Mauritius that went extinct in the 17th century, has long been a symbol of human-caused extinction. Colossal's approach involves sophisticated genomic sequencing and CRISPR gene-editing technology. By comparing the dodo's ancient DNA with that of its closest living relative, the Nicobar pigeon, researchers can pinpoint the specific genetic sequences required to reconstruct the bird's traits.

AI plays a critical role in this process by processing vast amounts of genomic data that would be impossible for humans to analyze manually. The software helps the team navigate the complexities of avian genetics, ensuring that the edited genome is functional and viable. This breakthrough is not merely about bringing back a single species; it serves as a proof-of-concept for broader conservation efforts and the restoration of lost biodiversity.

While the project remains highly complex and faces significant ethical and scientific challenges, the identification of these 2,300 targets marks a shift from theoretical research to practical application. Colossal plans to continue refining its genetic models, aiming to eventually produce a living, breathing dodo that can thrive in a restored habitat. This initiative highlights the growing intersection of artificial intelligence and synthetic biology, suggesting that the tools of the future may hold the key to undoing the mistakes of the past.

Sources: TechNews
