---
title: "NBA賽場突發衝突：球迷向裁判擲球引發爭議"
date: Thu, 05 Nov 2026 12:41:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMisAFBVV95cUxOU2ZrbWdwR2tJNmRDOXU3WU0telJVeHNZcEVfb1ZNc1VRU0sxbFNJN1IwTlJNS3YxZW5XR3lYTHRieWJKMGJOUWllbDljQW92MDRTNEIyUnVoNFRBMEh4bS1nV09zMW0wcTlXTURaUm5RX2JvNVNDX3RsekNoeDByXzcwNUs0Z3AwellfZVVPMnlQSlJjVnJZQWd4amNDWlEzUHhsaWlQTWIyNXhLb2d2YQ?oc=5"
source_name: "New York Post"
draft: false
---

在近期洛杉磯湖人隊對陣薩克拉門托國王隊的NBA比賽中，賽場氣氛一度緊張，一名觀眾與賽事裁判之間的衝突導致比賽被迫短暫中斷。事件起因於一名球迷向場內的一名女性裁判投擲籃球，這一行為立即引發了湖人隊球星盧卡·東契奇（Luka Doncic）的強烈譴責。

<!--more-->

當時正處於火熱競技狀態的東契奇，對該觀眾的行為感到極為不滿。他直言不諱地表達了對這種缺乏體育道德行為的憤怒，並質問該球迷：“他到底在幹什麼？

”該事件迅速觸發了場館安保機制，涉事球迷被立即驅逐出場。NBA聯盟對裁判及球員的安全有著極其嚴格的保護政策，在職業體育環境中，此類幹擾比賽的行為幾乎是零容忍的。

拋開爭議插曲，本場比賽本身也是東契奇個人進攻能力的又一次精彩展示。儘管現場氣氛一度混亂，他依然砍下了40分，延續了其本賽季帶領湖人隊保持競爭力的火熱手感。

雖然媒體的報道焦點在球迷驅逐事件與高強度比賽之間搖擺，但東契奇本人始終專注於保持賽場節奏。此次事件凸顯了NBA在管理球迷行為方面所面臨的持續挑戰。

隨著球員和裁判在極高壓環境下工作，聯盟日益重視執行相關規則，以保護場內人員免受騷擾或身體幹擾。迅速驅逐涉事觀眾的行為傳遞了一個明確訊號：無論比賽多麼激烈，無論場上有何等巨星，任何此類違規行為都將導致即時的嚴重後果。

來源: New York Post, ESPN, Yahoo Sports, Fox News, Los Angeles Times
