---
title: "L'Angleterre et le pays de Galles adoptent une réforme historique pour effacer les condamnations liées à l'avortement"
date: 2026-11-16T11:45:33Z
lang: "fr"
mode: "llm_translate"
source_url: "https://www.bbc.co.uk/news/articles/cqjd7n37r2r9o?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
image_url: "https://ichef.bbci.co.uk/ace/standard/240/cpsprodpb/ed68/live/71f67330-e1ab-11f1-8ee3-23d0d09d2796.jpg"
draft: false
---

Une réforme juridique d'envergure est entrée en vigueur en Angleterre et au pays de Galles, garantissant que les femmes ayant été, par le passé, arrêtées ou condamnées pour avoir pratiqué des avortements illégaux verront désormais leur casier judiciaire automatiquement effacé.

<!--more-->

Cette nouvelle politique constitue un tournant majeur dans le paysage juridique et social entourant les droits reproductifs dans la région, offrant un soulagement bienvenu aux personnes qui portaient le fardeau d'un casier judiciaire pendant des décennies en raison de lois jugées archaïques.

Sous l'ancien cadre juridique, de nombreuses femmes ont fait face à des sanctions sévères, incluant des peines d'emprisonnement potentielles et des antécédents judiciaires à vie, pour avoir recherché ou exécuté des procédures d'interruption de grossesse non autorisées.

Les détracteurs de ces anciennes législations ont longtemps soutenu qu'elles étaient désuètes, excessivement punitives et qu'elles touchaient de manière disproportionnée les femmes les plus vulnérables.

L'introduction de ces pardons automatiques vise à réparer des injustices historiques et à aligner le système judiciaire sur les conceptions modernes des soins de santé et de l'autonomie corporelle.

Les experts juridiques et les associations de défense des droits ont largement salué cette initiative, soulignant qu'une décision d'ordre médical ne devrait jamais être assimilée à une infraction pénale.

Le caractère automatique de ces mesures de clémence signifie que les personnes concernées n'auront pas à traverser un parcours administratif complexe ou émotionnellement éprouvant pour réhabiliter leur nom.

Au contraire, l'État prend proactivement des mesures pour effacer ces taches de leur dossier, garantissant ainsi un sentiment de justice et de clôture attendu depuis de nombreuses années.

Alors que la mise en œuvre de ces grâces se déroule à travers l'Angleterre et le pays de Galles, les autorités s'attachent à garantir que la procédure demeure fluide et accessible.

Ce changement de politique ne représente pas seulement une reconnaissance symbolique des préjudices passés, il renforce également la tendance mondiale en cours vers la décriminalisation de la santé reproductive et la protection effective des droits des femmes à l'ère moderne.

Source: BBC News
