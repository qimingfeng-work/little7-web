---
title: "英國政壇LGBT+權益辯論升溫：教育大臣批評巴德諾赫缺乏支援意願"
date: Wed, 11 Nov 2026 17:28:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMirgFBVV95cUxQaHA5S2JlTUZMaWdaTzdId3BHYm51WV9OTVV4dzJTWFdKSFZZMV9Qcmt0d1VEdlp0YS1BOTlWNnRoVFFKQmlQWlhiN1lkb1hGc1hpUU5UdGFBclhjbGg3OE53NlBCRDBqZExjbm9xTmlMVlJBTDlQbkI2RlkxUGFtcFRKUDdNOFRqQVF6QU13MFRoM3MxTGRqWjRYXy12bWhRSzRhT2RhbG9jQ3dNMlE?oc=5"
source_name: "The Guardian"
draft: false
---

英國教育大臣布莉姬·菲利普森（Bridget Phillipson）近日公開抨擊保守黨政治人物凱米·巴德諾赫（Kemi Badenoch），指責她「對支援 LGBT+ 群體毫無興趣」。

<!--more-->

這番言論發生在英國政壇關於跨性別者權益及「轉化治療」（conversion practices）禁令的激烈辯論背景下。這兩位政治人物之間的緊張關係，凸顯了英國政府在處理社會議題時日益加深的立場分歧。

爭論的核心在於《轉化治療法案草案》，該法案旨在保護弱勢群體免受傷害，但同時也引發了關於言論自由與宗教表達的擔憂。

包括 JK 羅琳在內的知名人士對現行跨性別法律提出批評，認為其未能保護女性空間；而人文主義組織（Humanists UK）則反駁稱媒體對轉化治療的報導存在誤導。此外，英格蘭與威爾斯天主教會及基督教組織也分別表達了立場。

這場多面向的辯論反映了立法在個人認同、宗教信仰與公民權利交織下的複雜性。隨著政府在不同壓力間尋求平衡，這些社會議題預計將成為未來立法議程中的核心爭議。

來源: The Guardian
