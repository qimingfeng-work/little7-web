---
title: "費城針對猶太裔商家的抵制運動引發社群緊張局勢"
date: Sun, 08 Nov 2026 19:06:58 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMipgFBVV95cUxNQURwRlVlSU93ZzM5R0I4cXQzZzhuMjNJWjkwaEEwaHFzaXdpcEk2bWNXUU9zQUxOR1J2NjJkZ0ZkR0ZmZGlBTVZUMWdKS3Z3bVkzNkJRSXBnTWVDbXNXc3AtQmVWT3Z2QXEyNzUxT3NJMHpZQTFvSXV2MFI1bWpUc1p3UHpBYnBuWFVJTHNXc2Y2TWEyOXNMdlNNM21SWGpLZzNzcFZR?oc=5"
source_name: "NBC News"
draft: false
---

在費城，針對猶太人擁有的餐廳和當地企業的抵制運動引發了嚴重的社會緊張局勢。倡導團體對這些計劃中的抗議活動表示深切擔憂，譴責這種具有分裂性的示威行為，並警告稱這些行為不成比例地影響了基於身份認同的當地企業家。

<!--more-->

為了回應這場抵制運動，反抗議者和社群成員組織起來支援受影響的商家。該地區出現了新的廣告牌和公共宣傳活動，呼籲市民“抵制抵制”，並與企業主站在一起。

當地領導人也挺身而出，試圖化解日益增長的敵意。著名人物如雷吉·傑克遜（Reggie Jackson）公開反對日益嚴重的排猶主義，將當前的氛圍與他在20世紀60年代親眼目睹的歷史性歧視進行了對比，呼籲社會警惕仇恨的蔓延。

當地政府和社群組織正在密切監測局勢，以防止事態進一步升級並確保公共安全。隨著討論的持續，公民領袖們呼籲保持冷靜、加強對話，並重申對賓夕法尼亞州多元化社群內包容性和相互尊重的承諾。

這一事件凸顯了在當前複雜的社會環境下，如何平衡言論自由與保護少數群體免受歧視之間的微妙關係。社群各界正努力通過對話尋求共識，以維護費城多元文化的和諧與穩定。

來源: NBC News
