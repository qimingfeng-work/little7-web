---
title: "The Inside Story: Mauricio Pochettino's Path to Manchester United and the Carrick Interregnum"
date: 2026-11-12T16:12:39Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://www.bbc.co.uk/sport/football/articles/cqdr1jlr1707o?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
image_url: "https://ichef.bbci.co.uk/ace/standard/240/cpsprodpb/b6bd/live/ff1daf40-dead-11f1-8253-3f203a001288.jpg"
draft: false
---

The managerial transition at Manchester United has been a subject of intense speculation, with Mauricio Pochettino emerging as the primary target for the club's leadership. Behind the scenes, the process of identifying the former Tottenham and PSG manager involved a strategic assessment of his tactical philosophy and his ability to manage high-pressure environments. The club's hierarchy viewed Pochettino as a long-term solution capable of implementing a cohesive identity at Old Trafford, marking a significant shift in their search for stability.

<!--more-->

During the period of uncertainty following the departure of the previous manager, Michael Carrick was thrust into the role of caretaker. The transition was far from seamless, and reports indicate that Carrick was left in a state of limbo regarding the club's long-term intentions. During this week of waiting, Carrick was reportedly kept in the dark about the specifics of the search, receiving limited guidance on how long his tenure would last or what the board's ultimate objectives were. This period of ambiguity highlighted the internal challenges Manchester United faced while attempting to secure their preferred candidate.

Ultimately, the pursuit of Pochettino reflected the club's desire to move away from short-term fixes and toward a more structured, project-based approach. While the negotiations were complex, the board remained committed to their vision of appointing a coach with proven experience in elite European football. For Carrick, the experience served as a challenging introduction to the complexities of top-flight management, as he navigated the team through a critical week while the club's future was being decided in boardrooms far removed from the training pitch.

Sources: BBC News
