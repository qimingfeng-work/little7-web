---
title: "Escalade du conflit au Moyen-Orient : des explosions secouent Riyad suite à des frappes de rebelles houthis"
date: Tue, 10 Nov 2026 00:48:40 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiU0FVX3lxTFBLM3c0UFp6Zkd2ZXdKLW15a1ZTQVJaNy03TXhndnJhSWdBMjJkSFZXRVdTNnM5YWwxT25OSXZzcUtVQkNYY1ZTU1JELTF0NnlpYVNr?oc=5"
source_name: "第一财经"
draft: false
---

La capitale saoudienne, Riyad, a été secouée par une série de puissantes explosions, marquant une escalade significative dans le conflit régional en cours impliquant les rebelles houthis du Yémen.

<!--more-->

Des rapports indiquent que la ville a subi de multiples déflagrations, que les autorités ont attribuées par la suite à une opération militaire coordonnée lancée par le mouvement houthi.

Le groupe a revendiqué l'exécution de quatre frappes militaires distinctes contre des cibles stratégiques situées sur le territoire saoudien, exacerbant ainsi les préoccupations sécuritaires à travers toute la région du Golfe.

Les évaluations initiales suggèrent que, bien que les attaques aient causé des dommages matériels à des infrastructures, notamment au bâtiment de la compagnie Saudi Aramco, les systèmes de défense de la coalition menée par l'Arabie saoudite se sont avérés largement efficaces.

Des responsables militaires ont confirmé l'interception réussie d'au moins quatre missiles balistiques tirés par les forces houthies, prévenant ainsi des destructions plus massives.

En dépit de ces succès défensifs, l'incident souligne la menace persistante que font peser les attaques de projectiles à longue portée contre les pôles économiques et urbains cruciaux de l'Arabie saoudite.

Dans un geste de représailles, l'armée de l'air saoudienne aurait mené une série de frappes aériennes dans les environs de Sanaa, la capitale du Yémen actuellement sous contrôle houthi.

Des rapports locaux en provenance de la région indiquent que ces contre-attaques ont fait au moins onze morts.

Cet échange de tirs rapide met en évidence la nature volatile du conflit, qui continue d'osciller entre des périodes de calme relatif et des confrontations militaires soudaines de haute intensité.

Les observateurs internationaux restent préoccupés par le fait que de telles escalades puissent déstabiliser davantage la région, compliquant les efforts diplomatiques en cours pour parvenir à un cessez-le-feu durable.

Alors que les deux parties continuent d'échanger des accusations et des frappes militaires, la population civile des deux nations demeure la partie la plus vulnérable dans cette lutte prolongée.

Source: Yicai
