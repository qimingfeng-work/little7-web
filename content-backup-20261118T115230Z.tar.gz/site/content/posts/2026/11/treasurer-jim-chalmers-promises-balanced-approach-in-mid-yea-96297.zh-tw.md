---
title: "澳洲財長吉姆·查爾默斯：年中預算更新將聚焦財政責任"
date: 2026-11-16T22:21:10Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://www.theguardian.com/australia-news/2026/nov/17/myefo-mid-year-budget-update-australia-treasurer-jim-chalmers"
source_name: "The Guardian World"
image_url: "https://i.guim.co.uk/img/media/0f10e0a245449557757da5e695d170a3df66fbde/1109_0_5520_4419/master/5520.jpg?width=140&quality=85&auto=format&fit=max&s=0dbbb8a06c2f036cc766fecb07638969"
draft: false
---

澳洲財政部長吉姆·查爾默斯（Jim Chalmers）表示，即將到來的年中預算更新將聚焦於財政責任，並承諾政府將會「削減足夠的支出，但不會過度」。

<!--more-->

隨著政府面臨證明其經濟策略合理性的壓力，查爾默斯強調，「年中經濟與財政展望」（MYEFO）旨在緩解當前的產能壓力，同時不抑制經濟成長。此次更新正值政府面臨挑戰之際，政府一直在應對連續五次升息帶來的後果。

由於通貨膨脹仍是持續的擔憂，且失業率資料顯示出上升跡象，財長面臨巨大壓力，必須證明政府有一套連貫的計畫來管理生活成本危機。查爾默斯強調，預算更新將包含「實質性節約」，旨在強化政府對抗通貨膨脹的承諾。

然而，挑戰在於如何在這些節約措施與支援陷入困境的經濟之間取得平衡。評論家與市場觀察人士正密切關注 MYEFO，看政府是否能成功在財政整合與支援弱勢家庭之間找到平衡點。

財長的言論顯示出一種謹慎的態度，旨在避免可能導致衰退的「過度」情境，同時也避免可能使預算長期面臨結構性赤字的「不足」情境。隨著政府努力推銷其經濟敘事，MYEFO 將成為檢驗其信譽的關鍵測試。

財長對緩解產能壓力的關注，顯示政府正尋求減少可能導致通膨升溫的政府支出，同時保護必要服務。這項策略是否足以同時滿足市場與飽受高成本之苦的公眾，還有待未來幾週觀察。

來源: The Guardian World
