---
title: "Spéculations politiques à Taïwan : une alliance Ko Wen-je et Chiang Wan-an en vue ?"
date: 2026-11-17T01:54:37Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiUEFVX3lxTE8tN1NZQnVyMGhQY212dEdnd0JaSXlCN2Uxd3FIaGtyX2N6TTZCOGctQWFFZmE0cnlLMW1xcG8wN3ZNbFRMalVnZU54OXVzcXl40gFWQVVfeXFMT18zM2pheHpnTXpiZDkxSV9XUGswbE55YTRjZ3R0NEItZlFnZHMxa19tWjRvUEZtTUM1MDYwdEJPamtrOUh1S0hBZmhERU9Zem51ejlOZXc?oc=5"
source_name: "UDN"
draft: false
---

Les spéculations se sont intensifiées quant à savoir si la figure du Parti populaire taïwanais, Ko Wen-je, fera une apparition de campagne conjointe pour soutenir le maire de Taipei, Chiang Wan-an, avant les prochains événements politiques.

<!--more-->

Interrogée sur la possibilité d'une collaboration politique de haut niveau, la maire de Taichung, Lu Shiow-yen, a répondu de manière énigmatique, suggérant que le public assisterait bientôt à une scène que de nombreux partisans trouveraient attrayante et bienvenue.

L'alignement potentiel a suscité des réactions mitigées dans divers cercles politiques.

Alors que certains analystes considèrent les apparitions conjointes comme une manœuvre stratégique pour consolider l'élan de l'opposition, d'autres soutiennent que les électeurs sont finalement plus concentrés sur des questions politiques de fond que sur des alliances tactiques entre partis.

Alors que les acteurs politiques manœuvrent avant les scrutins, tous les regards restent fixés sur la question de savoir si l'événement de coalition annoncé se concrétisera.

Source: UDN
