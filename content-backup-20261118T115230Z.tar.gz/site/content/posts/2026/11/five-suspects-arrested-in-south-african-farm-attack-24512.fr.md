---
title: "Afrique du Sud : cinq arrestations après le meurtre brutal d'un fermier"
date: Mon, 02 Nov 2026 10:48:47 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://www.bbc.co.uk/news/articles/cv4g13z0px8yo?at_medium=RSS&at_campaign=rss"
source_name: "BBC World"
draft: false
---

Les autorités sud-africaines ont annoncé l'arrestation de cinq individus soupçonnés d'être directement impliqués dans la torture et l'assassinat par balle de Donovan Marx, un agriculteur âgé de 50 ans.

<!--more-->

Ce fait divers tragique a immédiatement capté l'attention des médias nationaux et internationaux, tout en étant récupéré par divers groupes politiques pour attirer l'attention sur les défis sécuritaires chroniques et alarmants auxquels fait face la communauté agricole dans le pays.

Cette agression meurtrière survient dans un climat social extrêmement volatil et polarisé, où des organisations d'extrême droite et des lobbys agricoles affirment régulièrement l'existence d'un prétendu « génocide » coordonné visant spécifiquement les agriculteurs blancs.

Néanmoins, ces accusations graves ont été fermement et largement discréditées par des chercheurs indépendants, des sociologues et des responsables gouvernementaux.

Ces derniers rappellent que les attaques de fermes s'inscrivent plus globalement dans un problème systémique et généralisé de criminalité violente et endémique qui frappe aveuglément toutes les démographies et toutes les régions d'Afrique du Sud, sans distinction raciale.

L'interpellation des suspects marque une avancée judiciaire notable dans l'enquête en cours, les forces de police s'efforçant de déterminer avec précision les motivations réelles derrière ce déchaînement de violence.

Cet incident continue d'exacerber les tensions politiques et raciales, les associations de défense des populations rurales exigeant un renforcement drastique de la protection dans les zones reculées, tandis que les critiques appellent à la retenue pour éviter d'exploiter des faits divers isolés afin d'alimenter une rhétorique nationaliste et divisionniste.

L'enquête judiciaire poursuit son cours alors que les communautés locales réclament justice et la fin de ce climat permanent de peur et d'insécurité.

Source: BBC World
