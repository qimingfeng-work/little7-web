---
title: "Le producteur taïwanais légendaire Lee Ya-ming fait une apparition remarquée pour soutenir son fils Dino Lee"
date: 2026-11-13T03:44:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiSEFVX3lxTE5iY3VUOHBVaUJpRHlkWF9oX0dmSGJHZ21XWXRpaHRlXzItdDcxbjNrODAyN2FtRDQ5a0d4cV92VnJGNVk5QnJPU9IBTEFVX3lxTE4zLTBDenNGSGlrcTktUEVYaFlLTWJsMnB6SDZoQlpQYng0VDN1U0FYMXgwREs4UU9EUndhZ1N1TUVkRlpvRGdvSnJsWHc?oc=5"
source_name: "三立新聞網SETN.com"
draft: false
---

Le célèbre producteur de musique taïwanais et figure incontournable de l'industrie, Lee Ya-ming, a récemment fait une apparition publique remarquée, captivant l'attention des médias et suscitant un vif intérêt auprès du public.

<!--more-->

Connu pour ses contributions monumentales à la scène de la pop mandopop, Lee est sorti de sa réserve habituelle pour soutenir son fils, le chanteur et acteur Dino Lee, lors d'un duel culinaire chaleureux qui a mis en lumière leur relation père-fils très complice.

Cet événement mémorable s'est déroulé lors de la grande finale de l'émission de variétés culinaires « Open Fire », où Dino Lee participait à l'ultime épreuve.

À la surprise générale et pour le plus grand plaisir du public et de l'équipe de production, le maestro de la musique, âgé de 70 ans, a fait une apparition surprise en tant qu'invité d'honneur pour goûter la création culinaire de son fils.

En savourant le plat préparé par Dino, le vétéran de l'industrie, habituellement impassible, s'est montré visiblement ému.

Il a confié qu'il s'agissait de la première fois de sa vie qu'il expérimentait un geste aussi touchant de la part de son fils, manquant de verser des larmes devant les caméras.

Cette tendre interaction entre le père et le fils a constitué l'un des moments les plus forts et les plus émouvants du programme, contrastant fortement avec la rivalité légère et humoristique qui régnait par ailleurs dans l'émission.

Les fans et les médias locaux se sont empressés de relayer les rares photos et extraits vidéo de cette apparition de Lee Ya-ming, louant la chaleur authentique et le respect mutuel qui unissent ces deux générations d'artistes.

Outre ce moment familial particulièrement émouvant, la finale a été riche en rebondissements et en divertissements.

Dans une autre séquence de l'émission, l'invité vedette A-wei a gentiment pris à partie le membre de la distribution Yang Ming-wei, lui arrachant son gilet dans une tentative humoristique d' « usurpation » et plaisantant sur le fait qu'il prendrait la place de Yang dans l'émission dès aujourd'hui.

Ces pitreries bon enfant ont ajouté une touche comique vibrante à cette compétition culinaire aux enjeux pourtant élevés.

Globalement, cette finale de saison a su marier avec succès la dynamique familiale pleine d'émotion et le divertissement haut en couleur propre aux émissions de variétés.

L'apparition inattendue de Lee Ya-ming a non seulement offert un moment de télévision mémorable aux téléspectateurs, mais elle a également mis en relief les liens indéfectibles qui unissent la famille Lee, laissant une impression durable dans le cœur des amateurs de divertissement taïwanais.

com

Source: 三立新聞網SETN.
