---
title: "Le gouvernement australien rejette la proposition de remplacer les médiateurs internes des chaînes publiques ABC et SBS"
date: Wed, 11 Nov 2026 03:10:37 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://www.theguardian.com/media/2026/nov/11/labor-abc-sbs-ombudsmen-antisemitism-envoy-gaza-coverage-ntwnfb"
source_name: "The Guardian World"
image_url: "https://i.guim.co.uk/img/media/cd680a105c1ab118ab566555314592b71ad7d6bb/667_0_6665_5332/master/6665.jpg?width=140&quality=85&auto=format&fit=max&s=60218c2094641086f8dda621bf99dedd"
draft: false
---

Le gouvernement travailliste australien a officiellement rejeté la recommandation visant à démanteler les médiateurs internes de la chaîne publique Australian Broadcasting Corporation (ABC) et du Special Broadcasting Service (SBS).

<!--more-->

La proposition, formulée par l'envoyée spéciale du gouvernement chargée de la lutte contre l'antisémitisme, Jillian Segal, suggérait de remplacer les mécanismes de contrôle interne existants par un organisme externe et indépendant.

Cette recommandation faisait partie d'un ensemble plus large de priorités actualisées publiées par Mme Segal le mois dernier, visant à répondre aux préoccupations concernant la couverture médiatique du conflit en cours à Gaza.

Dans son rapport, Mme Segal soutenait qu'un médiateur indépendant externe serait mieux placé pour surveiller les reportages des radiodiffuseurs publics et veiller à ce qu'ils « respectent leurs propres normes déclarées d'exactitude et d'impartialité ».

Cette suggestion est apparue dans un contexte de surveillance accrue sur la manière dont les médias financés par l'État traitent des questions géopolitiques sensibles, les critiques réclamant souvent une supervision plus rigoureuse des décisions éditoriales.

Cependant, des sources gouvernementales ont indiqué que l'administration d'Anthony Albanese ne voyait aucune nécessité à une telle restructuration radicale.

Des responsables ont fait remarquer que l'Australie disposait déjà d'un cadre réglementaire des médias solide, comprenant notamment l'Autorité australienne des communications et des médias (ACMA), chargée de veiller au respect des normes de radiodiffusion dans l'ensemble du secteur.

En maintenant le système actuel de médiation interne, le gouvernement démontre clairement sa préférence pour les structures institutionnelles existantes plutôt que pour la création de nouvelles couches bureaucratiques externes.

Bien que le gouvernement ait salué l'importance du travail accompli par l'envoyée spéciale pour lutter contre l'antisémitisme, il reste fermement attaché au principe de l'indépendance éditoriale de l'ABC et du SBS.

La décision de rejeter cette proposition reflète une réticence générale à s'immiscer dans la gouvernance interne des médias publics, même face aux pressions exercées à l'encontre d'une couverture jugée controversée.

Pour l'instant, les procédures d'examen interne au sein de l'ABC et du SBS continueront de servir de principal mécanisme de traitement des plaintes du public, préservant ainsi le statu quo malgré les récents appels à la réforme.

Source: The Guardian World
