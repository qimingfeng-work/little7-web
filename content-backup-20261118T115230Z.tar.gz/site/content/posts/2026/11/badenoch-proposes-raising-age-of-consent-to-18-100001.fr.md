---
title: "Débat sur l'âge du consentement : Kemi Badenoch propose de le relever à 18 ans"
date: 2026-11-16T22:01:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiqAFBVV95cUxNcERsRGdZNHNEQ0ZqeExrUElxT3VuVFpLd19SVjJvTEdoRVZpeFk4YWhZWFlVOHVZV1ZJbWxKYlpMLXFkTDA0dkVva1cwZkJPWmI2cU5USG5xV0RQNVZJSWloQU5kWnVuZi1CUlltSDhPVTQ0c2htVzBuTGtkZy1aUmQwZC0wWmtDVnpzc2YzMm1zWmhtczZTeGxmU3p3V284dnd3SHp0Z3A?oc=5"
source_name: "The Independent"
draft: false
---

Kemi Badenoch a déclenché un débat national en proposant que l'âge du consentement soit relevé à 18 ans en toutes circonstances.

<!--more-->

Cette proposition intervient dans un contexte de préoccupations croissantes concernant les abus liés aux écarts d'âge et une série d'affaires très médiatisées qui ont mis en lumière le potentiel d'exploitation dans les relations impliquant des différences d'âge significatives.

La discussion a été alimentée par des allégations récentes contre des personnalités publiques, notamment les accusations d'une femme affirmant avoir été violée par Russell Brand à l'âge de 16 ans.

Ces histoires ont incité les chefs de police et les législateurs à reconsidérer l'adéquation de la législation actuelle.

Beaucoup soutiennent que les lois existantes sont obsolètes et ne parviennent pas à protéger les jeunes contre les comportements prédateurs, même lorsque ces relations sont techniquement légales.

Les partisans du changement soutiennent que relever l'âge du consentement fournirait une limite juridique plus claire et protégerait les adolescents contre la manipulation par des adultes plus âgés.

« Adolescente, je sortais volontiers avec un homme deux fois plus âgé que moi, mais la loi n'aurait pas dû le permettre », a noté un commentateur, reflétant un sentiment croissant selon lequel la loi devrait privilégier la protection des mineurs sur l'autonomie des adultes dans ces scénarios.

L'argument est que le déséquilibre de pouvoir inhérent à de telles relations rend le consentement véritable difficile, voire impossible, à donner pour un mineur.

Cependant, la proposition n'est pas sans critiques, qui soulèvent des inquiétudes quant aux implications pratiques d'un tel changement et au risque de criminaliser des comportements consensuels entre adolescents plus âgés.

Malgré la controverse, l'élan en faveur d'une réforme semble se renforcer.

Alors que le gouvernement examine ses prochaines étapes, le débat constitue un moment crucial pour la société afin de réévaluer la manière dont elle définit le consentement et protège ses membres les plus vulnérables contre les abus.

Source: The Independent
