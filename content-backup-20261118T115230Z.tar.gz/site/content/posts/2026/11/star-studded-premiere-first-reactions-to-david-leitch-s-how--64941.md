---
title: "Star-Studded Premiere: First Reactions to David Leitch’s 'How to Rob a Bank'"
date: Wed, 11 Nov 2026 11:12:23 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMirwFBVV95cUxPZkRkdU9nZlotVnkzYVoycER3cjFMb0hOcEdxWFVWbmM1bHZGTWRNLW0yQ1J3VmFoR3hxNjBhTE9udEdnREdqLTV1RkcwU1BncE1naXJiQWE1Y0RSVDJod19ITF9kUURSazR6ZDNpajJaZmE5cEFrZE5PRlBpZ2tOUEw2bkRaUVh1eTdQNWhXbGlCLXFkeXFNcjBrbVZub0drWUR3TzBGUEJjcmI5RGRZ?oc=5"
source_name: "The Hollywood Reporter"
draft: false
---

The red carpet was ablaze at the recent New York premiere of David Leitch’s latest project, 'How to Rob a Bank.' The film, which promises a high-octane blend of intense gunfights and adrenaline-fueled car chases, features a compelling performance from leads Nicholas Hoult and Pete Davidson. Early reactions from the premiere suggest that Leitch has once again delivered a visually striking and fast-paced cinematic experience that plays to his strengths as an action director.

<!--more-->

Beyond the film's content, the premiere served as a major fashion event. Zoë Kravitz captured the spotlight, returning to the red carpet with a bold, gold-themed aesthetic that drew significant praise from fashion critics. Her appearance, alongside co-stars like Pete Davidson, underscored the star power behind the production. The event was a vibrant display of Hollywood glamour, with attendees and media outlets alike focusing on the chemistry between the cast members and the film's anticipated impact on the box office.

While the film is still in its early stages of public reception, the initial buzz surrounding 'How to Rob a Bank' is overwhelmingly positive regarding its entertainment value. Critics have noted that Leitch’s signature style is present throughout, providing a gritty yet polished look at the heist genre. As the movie prepares for its wider release, audiences are eager to see if the chemistry between Hoult and Davidson translates into a successful run at the theaters. For now, the premiere has successfully set a high bar for the film's promotional tour, cementing its status as one of the most talked-about projects of the season.

Sources: The Hollywood Reporter
