---
title: "Former Guangzhou Communist Party Chief Guo Yonghang Expelled from Party and Office"
date: Mon, 02 Nov 2026 08:00:30 GMT
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMicEFVX3lxTFBsQ2dndk5rb0Vsd1BXbGRxQVBZd2oxUWlsZHVvQ01fV0lCOTduR1NDV0VpeDVnV01SMTdnbUxpOHdzdHlVamdwb3dtV2V5SlpsRDhlbnA3dEdma3EyS1REb24zY1hyME1zMHRvbTFidEo?oc=5"
source_name: "中华网"
draft: false
---

Guo Yonghang, the former party chief of Guangzhou and former senior official within Guangdong provincial politics, has been formally stripped of his party membership and public office following a comprehensive corruption investigation. The disciplinary action, commonly known as a double expulsion, was announced after anti-corruption authorities uncovered severe violations of discipline and law during his tenure.

<!--more-->

According to official investigation findings, Guo was found to have engaged in extensive corrupt practices, characterized by authorities as deep-seated greed and financial misconduct. The official通报 explicitly detailed allegations that he abused his considerable political influence for personal enrichment, partook in illicit power-for-money transactions, and improperly interfered in judicial activities to subvert fairness and rule of law.

Additionally, investigators noted ethical breaches, including the acceptance of unauthorized high-end medical services and luxury benefits free of charge. The decisive action against Guo underscores China's ongoing, unyielding anti-corruption campaign targeting high-ranking officials who abuse public trust and administrative authority for private gain.

Sources: 中华网
