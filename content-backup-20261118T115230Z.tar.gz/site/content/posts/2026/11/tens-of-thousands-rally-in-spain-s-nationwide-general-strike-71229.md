---
title: "Tens of Thousands Rally in Spain's Nationwide General Strike as Clashes Erupt in Barcelona"
date: 2026-11-12T03:14:24Z
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiZ0FVX3lxTFBhRU1wdHY0T0VFSUtMeW14TF9WMzR5aE5KanIxeHl5T21wSFRwUjF2NG00Ti1YMzNZTlFTSmE4WGI1d0wwazFMZnN3ZURzWjVWblNBTUxRcFVFQl9Od1FxZzF2QW02RDjSAWxBVV95cUxPWVZsUk5lNmduTXhHUjR1elJDVFNobFI0dFZvSlFwWXpUcVhHVEJvdElYZHR3VndUWDZ4TzQwdmc4Y05mT18zTmJnZWxMOXcyYzFKTm9Zbm95d3lSdHhmOHdFZTVhRm13ZWVwbjI?oc=5"
source_name: "BBC"
draft: false
---

Spain recently experienced widespread social unrest as tens of thousands of citizens took to the streets for a nationwide general strike, protesting severe housing crises and skyrocketing living costs. The demonstrations turned violent in Barcelona, where intense clashes broke out between protesters and law enforcement officers, resulting in numerous arrests and heightened security concerns.

<!--more-->

The massive wave of protests coincides with parliamentary debates and the recent passage of housing security measures. However, protestors argue that government actions fall woefully short as exorbitant rents consume an unsustainable percentage of average incomes—with some reports indicating rent can devour nearly 99 percent of a worker's salary. Approximately four million people have been impacted or mobilized by the deepening housing crunch, which has transformed into a major political flashpoint ahead of upcoming national elections.

As public frustration boiled over, the demonstrations led to at least 73 arrests nationwide following the confrontations with police. Labor unions and civic organizations coordinated the general strike to demand immediate government intervention, while political analysts note that the rising public anger is reshaping the electoral landscape, even as far-right parties see shifts in their polling numbers.

Sources: BBC
