---
title: "Le projet de panneaux solaires sur le réservoir de Feitsui ravive les tensions politiques à Taïwan"
date: 2026-11-17T08:23:16Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMijgNBVV95cUxNVjgwbDdtMjZTV1Fqb1FyU3VHd1ROaHlWQUZZNE14WmdReDVUTm53TzBlVWw2aXFQTXR6dHF4RkJ1VjlZcm9kMmRSVGFGU1NwNjZ5WkU2VWtLX1dZUF84Vjk4NmE3M0xxcEdjLV9XeGlaLTNKOWU0d3hlbFN3RVNYakRBVGNJLUdFeG1WVGVzRzhsSjZlMFVrNlVYOG5KdS1WVUJPaDh6YzcwTjRaRFJqRXFyV1VyNjNHRk4tS2FJUHFyOXpqc1drUEtYMy1YdWNKTEJhVWJoWmR1T2tiRTRHT3h6ZzlNVjFCbVdpaFg5SENpZGl0cWtmSWN4S1c3T0ZFRlFLTzk2YVRCZ0J2WlZSVWFlWlRaWVFCWDdLMVJQYjN4TEd5RVRrdmVSYmcyZEJnVFQ2eHJMcWJqUmlGZFQ4bE04N1RkTDNDb1U5a0dEOFo3SHpTRzZydDkwMnUxZVVJR29YNGpDTTdKOEtSck9IRmNvZW1HWXVRbGp4WkxoVjNva3lqMTN4UmVuLVNzdw?oc=5"
source_name: "Yahoo新聞"
draft: false
---

La proposition d'installer des panneaux solaires sur le réservoir de Feitsui a récemment déclenché un débat politique houleux à Taïwan, attirant diverses personnalités de haut rang et des responsables locaux.

<!--more-->

La discussion porte sur l'impact environnemental, la nécessité de tels projets et les implications politiques pour la mairie de Taipei.

Le commentateur Huang Wei-han a suggéré que, quel que soit le vainqueur de l'élection municipale de Taipei, la question de la production d'énergie solaire au réservoir est peu susceptible d'être un obstacle obligatoire, ce qui implique que le projet manque de soutien politique ou pratique général.

Le maire de Taipei, Chiang Wan-an, a fermement exprimé son opposition à l'installation de panneaux solaires sur le réservoir, invoquant des préoccupations concernant la qualité de l'eau et la préservation de l'environnement.

Sa position a contraint d'autres personnalités politiques à clarifier leurs positions.

Par exemple, Shen Po-yang, qui a initialement exprimé un point de vue nuancé, a clarifié plus tard son opposition, reflétant la sensibilité du sujet.

Pendant ce temps, le Premier ministre Cho Jung-tai a cherché à désamorcer la situation en déclarant qu'il n'y avait actuellement aucun plan pour mettre en œuvre un tel projet, tentant ainsi de mettre fin à la controverse.

Au-delà du réservoir de Feitsui, la question plus large des panneaux solaires sur les plans d'eau est devenue un point chaud de la politique énergétique de Taïwan.

L'homme politique de l'opposition Hsieh Lung-chieh a appelé à plusieurs reprises au retrait des panneaux solaires du réservoir de Wushantou, mettant le gouvernement central au défi d'agir.

Ces débats mettent en évidence la tension entre la volonté du gouvernement de promouvoir les énergies renouvelables et les préoccupations des dirigeants locaux concernant l'utilisation des terres, l'impact écologique et l'opinion publique.

Alors que le discours se poursuit, il reste clair que toute décision vers des installations solaires à grande échelle sur les infrastructures hydrauliques fera l'objet d'un examen minutieux et d'une résistance politique.

Source: Yahoo News
