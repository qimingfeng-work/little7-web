---
title: "英國零售業再受衝擊：前 WH Smith 連鎖店 TG Jones 遭掛牌出售"
date: 2026-11-17T12:28:38Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMihAFBVV95cUxPLVc2TWg4WThmYXRYbk5yYlJxclJfRUMtbFVUUnh4b2xyRTY4aXpHVkJuMDU4XzZrcXQ4bmhobXRFWS02bF90Y1djc3dfTV9RSklPMnZfT3ZNYlRQd0g3Zm5sZXlXVWhyZjJ6UWljdE5hVENSTE5YQVpiZHI2cFRlMzdMSkE?oc=5"
source_name: "Financial Times"
draft: false
---

英國零售業面臨另一波重大動盪，前身為 WH Smith 連鎖店的 TG Jones，在被私募股權公司收購不到 18 個月後，再度被掛牌出售。此舉標誌著這家陷入困境的商業街零售商，其經營策略出現了急轉彎。

<!--more-->

這項撤資決定是在經歷了一段嚴重的財務壓力後做出的，該期間公司在全國範圍內關閉了 130 家門市。零售業目前正苦於應對營運成本上升、消費者習慣改變以及來自電子商務的持續競爭。

TG Jones 曾進行大規模重組以試圖品牌現代化，但最終未能達到投資人設定的成長目標。產業分析師認為，此項出售案反映了私募股權領域的一種廣泛趨勢，即投資公司日益傾向於退出無法帶來快速回報的零售投資。

大規模的門市關閉對地方商業街產生了連鎖反應，引發了對失業問題以及城鎮中心活力衰退的擔憂。隨著潛在買家評估該品牌在飽和市場中的生存能力，剩餘 TG Jones 門市的未來仍充滿不確定性。

隨著出售程式啟動，利害關係人正密切關注是否有新買家能扭轉頹勢，或者該品牌將面臨進一步縮編。此情況凸顯了現代經濟中傳統零售連鎖店的脆弱性，即便是有名氣的品牌也必須不斷適應才能生存。

目前，各界焦點仍集中在這些關店潮對零售業勞動力造成的影響，以及對英國商業街基礎設施的更廣泛衝擊。

來源: Financial Times, The Guardian, Sky News, The Independent, The Telegraph
