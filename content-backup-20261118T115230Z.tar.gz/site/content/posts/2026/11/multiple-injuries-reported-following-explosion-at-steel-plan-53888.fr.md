---
title: "Explosion dans une aciérie en Turquie : Enquête en cours sur les causes de l'accident industriel"
date: Mon, 09 Nov 2026 10:29:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiVkFVX3lxTE0wUHJEalFGMUhEcjlwQVFtaHV1dkFHRFNRV3g0MXFSNXpRQXVxRm1qZUtUbWtYRWotY0lkXzFfMFFWa0Z6RE5HdHk3VFVwM3FLSzhDaURB?oc=5"
source_name: "搜狐网"
draft: false
---

Un grave accident industriel s'est produit aujourd'hui dans l'ouest de la Turquie, où une explosion dans une usine de fabrication d'acier a fait plusieurs blessés.

<!--more-->

Les services d'urgence ont été immédiatement dépêchés sur les lieux après que des rapports ont fait état d'une puissante déflagration ayant secoué le site industriel.

Les autorités locales ont confirmé que plusieurs travailleurs ont été blessés lors de l'incident, bien que le nombre exact de victimes et la gravité de leur état soient encore en cours d'évaluation.

Les enquêtes préliminaires suggèrent que l'explosion pourrait avoir été causée par une défaillance technique au sein des machines de production de l'usine.

Le site, qui joue un rôle important dans l'économie locale, a été temporairement fermé pour assurer la sécurité des environs et permettre une enquête approfondie par les inspecteurs de la sécurité.

Les pompiers et les équipes médicales ont travaillé pendant plusieurs heures pour contenir les conséquences de l'explosion et transporter les blessés vers les hôpitaux voisins.

Bien que la situation soit actuellement sous contrôle, l'incident a soulevé des inquiétudes concernant les normes de sécurité industrielle dans la région.

Les responsables du gouvernement local ont promis une enquête transparente sur la cause de l'explosion, soulignant que toute négligence constatée serait traitée conformément à la loi.

La communauté locale a exprimé son choc face à l'événement, de nombreuses familles attendant des nouvelles de leurs proches qui étaient en poste au moment de l'explosion.

Alors que les efforts de nettoyage se poursuivent, l'accent reste mis sur le rétablissement des travailleurs blessés.

D'autres mises à jour sont attendues à mesure que l'équipe médico-légale termine son analyse du site.

Cet incident sert de rappel brutal des risques inhérents associés à la fabrication industrielle lourde et de la nécessité de protocoles de maintenance rigoureux pour prévenir de telles tragédies.

La sécurité des travailleurs demeure la priorité absolue des autorités régionales dans ce contexte de crise.

Source: Sohu News
