---
title: "Départ surprise du PDG de Nvidia : Les marchés financiers en pleine tourmente"
date: 2026-11-12T22:02:38Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMipgFBVV95cUxObThxM3BRRC1qQ3NIMk1DekU3b2RoTW9IOUdCZ3J3VFNqQm9mRV95dXE3S1NLYmVMUWpxeEk5eXFTMjRxdmd3ejU1MGZyVFcwVTV4TXVIbFJ3VlYwT3pqNWY3Y0pqeGJYVUZHbFBBLUEyXzBxMWdSSTBLRTAtMkhMRFh0a0tCM3MtVVQzVkxBMVQyODdobXpVak5aVVJBaHdVR3NpcHp3?oc=5"
source_name: "Reuters"
draft: false
---

Les marchés financiers traversent actuellement une période de turbulences importantes suite au départ inattendu du PDG de Nvidia, Jensen Huang.

<!--more-->

En tant que l'une des figures les plus influentes de l'industrie des semi-conducteurs, le départ de M.

Huang a provoqué une onde de choc dans le secteur technologique, entraînant une rotation notable des actions liées aux puces électroniques et soulevant des inquiétudes quant à l'avenir des initiatives majeures en matière d'intelligence artificielle.

La réaction du marché a été immédiate, les actions de Nvidia chutant d'environ 4 % dans la foulée de l'annonce.

Les implications de ce changement de direction dépassent largement le cadre de la salle du conseil.

Des rapports indiquent que cette transition, combinée à une surveillance accrue de la part des régulateurs américains, a placé environ 3 milliards de dollars de projets d'IA en Chine dans une situation précaire.

Ces projets dépendaient fortement du matériel et de l'orientation stratégique de Nvidia, et l'incertitude soudaine laisse les investisseurs et les partenaires s'interroger sur la viabilité de ces entreprises à long terme.

Les tensions géopolitiques entourant la technologie de l'IA et les exportations de puces ajoutent une couche de complexité à une situation déjà volatile.

Les analystes de marché conseillent aux investisseurs de faire preuve de prudence alors que le secteur des puces s'ajuste à ce nouveau paysage.

La « tempête Nvidia » a provoqué un déplacement de capitaux, les traders évaluant quelles entreprises sont les mieux placées pour résister à un ralentissement potentiel des dépenses en IA.

Si certains considèrent cette baisse comme une correction temporaire, d'autres avertissent que la combinaison de l'instabilité de la direction et de la pression réglementaire pourrait conduire à une période de sous-performance prolongée pour le géant des puces.

Alors que l'industrie attend plus de clarté sur l'orientation stratégique de Nvidia sous une nouvelle direction, l'attention reste portée sur la manière dont l'entreprise gérera sa chaîne d'approvisionnement mondiale et maintiendra sa domination sur le marché du matériel d'IA.

Pour l'heure, les salles de marché restent extrêmement sensibles, chaque mouvement de l'équipe de direction étant scruté à la recherche de signes de stabilité ou de nouvelles perturbations.

Les semaines à venir seront critiques pour déterminer si Nvidia peut regagner la confiance des investisseurs ou si le marché continuera de se tourner vers des alternatives plus stables.

Source: Reuters
