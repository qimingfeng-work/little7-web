---
title: "Australie : controverse autour des « forêts fantômes » et des crédits carbone"
date: 2026-11-18T09:30:36Z
lang: "fr"
mode: "llm_translate"
source_url: "https://www.theguardian.com/environment/2026/nov/18/phantom-forests-in-australian-arid-outback-used-to-create-carbon-credits-meant-to-offset-emissions-report-claims"
source_name: "The Guardian World"
image_url: "https://i.guim.co.uk/img/media/06bf441bd0b1ae5e44706521aa2d8dfb287f3adb/126_0_3779_3024/master/3779.jpg?width=140&quality=85&auto=format&fit=max&s=93eb27396e961a3d060c9f56600717d0"
draft: false
---

Un débat houleux concernant l'intégrité de la politique australienne sur le changement climatique a été relancé à la suite d'un nouveau rapport alléguant l'existence de « forêts fantômes » dans l'arrière-pays aride du pays.

<!--more-->

Selon un groupe d'universitaires, incluant des chercheurs de l'Université nationale australienne et de l'Université de Nouvelle-Galles du Sud, ces zones sont utilisées pour générer des crédits carbone qui permettent aux entreprises de combustibles fossiles de compenser leurs émissions, malgré le peu de preuves d'une réelle régénération forestière.

L'étude a examiné 50 projets de régénération forestière enregistrés pour produire des crédits carbone.

Les chercheurs ont constaté que, malgré des conditions humides favorables qui auraient dû stimuler la croissance, il n'y avait qu'une augmentation négligeable de la couverture forestière et de la canopée dans les zones désignées.

Cette divergence a conduit les universitaires à qualifier ces sites de « forêts fantômes », suggérant que les crédits carbone générés à partir de ceux-ci pourraient ne pas représenter de réels avantages environnementaux ou une séquestration de carbone effective.

Les entreprises de crédits carbone ont fermement rejeté ces conclusions, défendant la légitimité de leurs projets et les méthodologies utilisées pour calculer les compensations carbone.

Elles soutiennent que la recherche ne prend pas en compte les complexités de la gestion des écosystèmes dans les régions semi-arides et que le processus de régénération est une entreprise à long terme qui ne peut être jugée uniquement par des données de canopée à court terme.

L'industrie maintient que ces projets sont vitaux pour atteindre les objectifs nationaux d'émissions et encourager des pratiques de gestion durable des terres.

Cependant, le rapport a fourni des munitions aux critiques qui soutiennent que le système actuel de crédits carbone est défectueux et sujet au « greenwashing ».

En permettant aux entreprises de continuer à polluer sous couvert d'une conservation environnementale qui pourrait ne pas avoir lieu, le système est accusé de ne pas s'attaquer aux causes profondes du changement climatique.

La controverse souligne une tension plus large entre le besoin de solutions climatiques basées sur le marché et l'exigence d'une surveillance scientifique rigoureuse et transparente.

Alors que le débat se poursuit, les décideurs politiques subissent une pression croissante pour revoir les normes régissant les programmes de compensation carbone.

L'équipe universitaire à l'origine du rapport appelle à une enquête plus approfondie sur la validité des crédits existants et à un durcissement des réglementations qui régissent la manière dont ces projets sont vérifiés.

Pour l'instant, le différend reste un point de discorde central dans les efforts continus de l'Australie pour équilibrer l'activité économique et la responsabilité environnementale.

Source: The Guardian World
