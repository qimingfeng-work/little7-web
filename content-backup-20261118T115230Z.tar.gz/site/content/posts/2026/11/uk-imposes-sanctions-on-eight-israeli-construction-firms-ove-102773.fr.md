---
title: "Le Royaume-Uni impose des sanctions contre huit entreprises de construction israéliennes impliquées dans les colonies"
date: 2026-11-17T14:21:42Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMitgFBVV95cUxNZ01PYUtvQVNTSXN4TlA0UHQ2dXpseHotOWpBTG5zN0IzMF9iS1dRSEloQkJvRU5NdFNqd0NHYVRJbDlXRVU5RWpfOVRyZDNYakYyOG1FbU8zQjFxUjcxbjcxOUU1ZW5ZMHFIb2c0QjRaUTczd0J5dXdiODJNSnh3NE8xMEFRQVdDUkl6QlR4bGN0NWxxLUF4TTJTVFpDOGpHc3g5UnFUcVhoeTBONl9TOWMwT1hUQdIBuwFBVV95cUxQbEhfbUFIQW84dGhMaDFVVG03d1VqZkx0RGpDRnFEc05sMnhDc1ZNWk56bXBlRlFnUTNDc2FyVnJEalhCY2MteWdoVVpGMVdtOWY0NzNvbTZ3REdCaWVNOUZiMUZrRGUtUnVJV2hMTUtTeTloSG1fUlphTDFqMDN3cFRmQXNMNUJaTG5nMVR6cjEtcFF3RzVVczhTWG5nZVYzWUQ4SU9DelBuakZ0ZC1UemhqRnZObG9SV1hJ?oc=5"
source_name: "Al Jazeera"
draft: false
---

Le Royaume-Uni a franchi une étape diplomatique majeure en imposant des sanctions ciblées à l'encontre de huit entreprises de construction israéliennes.

<!--more-->

Ces sociétés sont directement impliquées dans le développement et l'expansion des colonies situées en Cisjordanie occupée.

Cette décision, annoncée par des responsables britanniques, dont le ministre Ed Miliband, marque un tournant significatif dans la posture du gouvernement britannique face au conflit israélo-palestinien et à la politique de colonisation, largement considérée comme illégale au regard du droit international.

Les entreprises visées sont accusées de faciliter l'extension de ces colonies, une pratique qui constitue depuis des décennies un point de friction majeur entre Israël et la communauté internationale.

En ciblant spécifiquement ces entités économiques, Londres cherche à exercer une pression financière concrète et à signifier son désaccord profond avec des activités qui, selon les autorités britanniques, compromettent gravement les chances d'une solution à deux États.

Cette mesure intervient dans un contexte de critiques internationales croissantes concernant la dégradation de la situation humanitaire en Cisjordanie et le déplacement forcé des populations locales.

En réaction à cette annonce, le gouvernement israélien a exprimé une vive opposition, promettant de riposter contre ce qu'il qualifie de mesure injuste et politiquement motivée.

Les responsables israéliens ont systématiquement défendu ces projets de construction, invoquant des justifications historiques, religieuses et sécuritaires pour légitimer leur présence sur ces territoires.

La tension entre Londres et Jérusalem devrait persister alors que les deux parties tentent de gérer les retombées diplomatiques de ces sanctions.

Ce changement de politique reflète une tendance plus large parmi les nations occidentales : celle de tenir les entités privées pour responsables de leur rôle dans les différends géopolitiques.

Alors que le gouvernement britannique subit une pression interne pour jouer un rôle plus actif et plus ferme dans les affaires du Moyen-Orient, ces sanctions servent de démonstration tangible de son engagement envers les normes juridiques internationales.

Si l'impact à long terme sur les entreprises de construction et sur la politique globale de colonisation reste à évaluer, cette décision souligne le fossé grandissant concernant l'avenir de la Cisjordanie et le respect du droit international.

Source: Al Jazeera
