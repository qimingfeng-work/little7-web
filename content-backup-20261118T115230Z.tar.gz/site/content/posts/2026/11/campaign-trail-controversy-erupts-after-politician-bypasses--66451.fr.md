---
title: "Un incident de campagne à Taiwan suscite le débat en ligne autour de Chiang Wan-an"
date: Wed, 11 Nov 2026 12:03:00 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiSEFVX3lxTFBZdHF1Tl9mRFNJOUNUYml5WVRnWGNTU2RJeHhNMGFTZUtvODUyZ3VLN1lUVTFEOHdCaS1WMmNDclB5a21QR0tDTdIBTEFVX3lxTE8zRWphVVo2RHhOSzlTY2J4SDJnWmR0bVdpNXRTQnh1TWtaeDVUakI3U3J2VTZvTVJyRW5GTXAySkQ2UTIwNFUxTVllb0U?oc=5"
source_name: "三立新聞網SETN.com"
draft: false
---

Un récent événement de campagne organisé dans une circonscription hautement disputée a déclenché une vive controverse en ligne après que le célèbre homme politique Chiang Wan-an a apparemment contourné l'étal d'un vendeur local lors d'une promenade de quartier, provoquant ainsi des réactions mitigées tant au sein du public que parmi les observateurs politiques locaux.

<!--more-->

Le vendeur a affiché une déception visible d'avoir été ainsi ignoré, ce qui a rapidement incité de nombreux internautes à débattre avec passion pour savoir si cette décision reflétait un manque de tact ou un calcul politique délibéré de la part de l'équipe de campagne.

Les partisans de Chiang ainsi que les législateurs alliés se sont empressés de voler à son secours, publiant de longues déclarations officielles pour contrer les critiques et affirmant avec force que les candidats font constamment l'objet d'un examen injuste et disproportionné, indépendamment de leurs actions sur le terrain.

Malgré cette polémique mineure qui n'aura finalement duré que quelques jours, Chiang a choisi de poursuivre sa stratégie de proximité agressive, unissant ses forces à celles d'autres figures politiques influentes pour mener des campagnes de terrain intensives au cœur de zones traditionnellement acquises à l'opposition.

Parallèlement, d'autres personnalités politiques de premier plan, telles que Ko Chih-en, ont multiplié les visites sur le terrain dans les marchés traditionnels locaux afin d'interagir directement et chaleureusement avec les administrés.

Ces interactions de proximité sont largement perçues par les experts comme absolument cruciales pour consolider la confiance des électeurs et maintenir une dynamique positive alors que les différents candidats parcourent les régions pour soutenir leurs alliés locaux à l'approche des scrutins à venir.

com

Source: 三立新聞網SETN.
