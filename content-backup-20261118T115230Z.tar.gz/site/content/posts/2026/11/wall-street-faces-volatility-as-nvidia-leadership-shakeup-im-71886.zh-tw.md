---
title: "輝達領導層變動引發華爾街震盪，歐洲市場表現相對抗跌"
date: 2026-11-12T15:00:00Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMi4gFBVV95cUxNZEw3RV9SNnVLZkp1d1ZtVWMwWXo3alR4RWJWYVVrc0gwZHktNlk5MzczZE1KMER5VW96SUtReHF5bS1wbnJVajN4MnV1WkJ5Vm1OaTFKUUVnSkV1MWt3TllrWTZzSlZieXZXbE9sNE81M2tCSEo0LWpHVUVkb2dicE5JRjl1ZXo3Q0xIa3lPTUJadGV5WEZqXzQ2RmlwakdWcHBQejRsbFlSUHJkMWdFejFORWFiTXF0Si1jZldyUmpueWFGTmZTODJuaklMc0N0UnpIRzZMMkpjUW1sQW4zZzBR?oc=5"
source_name: "Proactive financial news"
draft: false
---

華爾街經歷了動盪的交易日，投資人對輝達（Nvidia）領導層的意外訊息做出反應。作為近期人工智慧（AI）股票熱潮的主要驅動力，該晶片製造商一名關鍵高管的離職，在科技產業引發了不確定性的漣漪。

<!--more-->

此訊息觸發了更廣泛的拋售，市場參與者重新評估今年以來主導股市的AI驅動漲勢的穩定性。當美國市場努力應對輝達變動帶來的影響時，歐洲的情況則呈現出不同的敘事。

倫敦富時100指數（FTSE 100）在午盤交易中上漲，資料顯示英國GDP成長正在加速。零售與消費類股在維持指數正面動能方面發揮了重要作用，有助於抵銷先前拖累能源相關股票的油價疲軟所帶來的擔憂。

市場分析師認為，美國科技股的拋售與歐洲市場的韌性表現之間的背離，反映了投資人焦點的轉移。雖然AI股票對公司治理與成長預測依然敏感，但更廣泛的市場情緒正越來越多地受到宏觀經濟指標的影響，例如國家成長率與財報。

隨著投資人度過這段波動期，焦點仍集中在科技股目前的跌勢，究竟是暫時的修正，還是市場領導地位出現了更持久的轉變。com

來源: Proactive financial news, London South East, Finimize, Sharecast.
