---
title: "西班牙列車脫軌事故後續：遇難者身份確認工作進展緩慢"
date: Mon, 02 Nov 2026 01:10:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiowFBVV95cUxONlZTcmI4NTlSZ0hOSnJwdkFxcHM1Q3VjNDFIVDlyTDVmdEFjVXJSd3FneU5LSTFxRUtGbEJXM0JlV21Nd2Y3Qm9HODRtb1FGSTYxZERHWXpoN1VXT3ctYlFLb3B4aFZPNHNZekxQRURzeXY2eXNjY3VGZ1VoRzhaOUhqb1dkcG0zZUZkRTNhTFR1VzlGQW4xYTRuTHRPc09GaDV3?oc=5"
source_name: "The Telegraph"
draft: false
---

在西班牙發生本世紀歐洲最嚴重的鐵路事故後，當局已確認了69名遇難者中的大部分身份。這場悲劇造成了慘重的人員傷亡，其中54名為西班牙籍，其餘遇難者包括來自美國、日本、加拿大、阿根廷、墨西哥、突尼西亞和捷克的公民。

<!--more-->

對於遇難者家屬而言，遺體辨認過程極其痛苦，法醫專家在某些情況下不得不依賴殘缺遺骸來確認逝者身份。這起上週發生的高速列車碰撞事故震驚了國際社會，並促使相關部門對脫軌原因展開調查。

漫長的身份確認過程使等待訊息的家屬陷入了巨大的情感折磨。在全國哀悼遇難者的同時，調查人員正努力確定導致災難的具體故障。

此次事故再次提醒人們高速鐵路基礎設施的脆弱性，以及此類悲劇對全球受害者家庭造成的深遠影響。

來源: The Guardian World
