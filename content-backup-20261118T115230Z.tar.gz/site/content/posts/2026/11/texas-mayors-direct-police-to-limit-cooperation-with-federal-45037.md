---
title: "Texas Mayors Direct Police to Limit Cooperation with Federal Immigration Authorities"
date: Sat, 07 Nov 2026 08:15:55 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiW0FVX3lxTE9GdU1NT1VMR3lESjY1ekRRNDhVR2hKWEVtTTlMZGFDSzcyNkNpR2FFWHl1c2VoSlVaNXFfemVQZW0xdEdkWU1jRzgzcUtPT3lhQ09WOXlDTzZoX3c?oc=5"
source_name: "BBC"
draft: false
---

In a notable shift in local policy, municipal leaders in major Texas cities, including Austin and Houston, have instructed their police departments to limit cooperation with U.S. Immigration and Customs Enforcement (ICE). These policy adjustments come as city leaders urge law enforcement agencies to revise their enforcement guidelines before state-level leadership changes take full effect. The directives aim to redefine how local police interact with federal immigration authorities during routine operations, such as traffic stops.

<!--more-->

Houston Mayor John Whitmire formally directed the Houston Police Department to reduce its collaboration with ICE, a decision that follows recent political shifts and midterm election outcomes in the state. Similarly, leaders in Austin have emphasized the importance of fostering trust between immigrant communities and local law enforcement. Proponents of these changes argue that when police officers step back from enforcing federal immigration laws, immigrant residents are more likely to report crimes, cooperate as witnesses, and seek assistance from emergency services without fear of deportation.

The policy adjustments have sparked considerable debate among lawmakers and law enforcement officials across Texas. Supporters maintain that focusing police resources on local public safety and violent crime builds stronger, safer neighborhoods. Conversely, critics express concern that limiting cooperation with federal agencies could create friction with state authorities and undermine broader immigration enforcement efforts. As these new guidelines are implemented, municipal and state leaders are bracing for ongoing discussions regarding the appropriate balance of local and federal responsibilities.

Sources: BBC
