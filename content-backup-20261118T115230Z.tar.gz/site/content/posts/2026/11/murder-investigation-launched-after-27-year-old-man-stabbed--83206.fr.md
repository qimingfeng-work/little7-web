---
title: "Enquête pour homicide ouverte après un meurtre au couteau à Manchester"
date: 2026-11-14T13:03:30Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiwwFBVV95cUxPOXJWNzM3UnljdmdBQk5oY3otS1B3dDdvXzh2c0NHWW95VW1vTnJQZF9GdkVHWWlDNC1pSEVZSHFVRk5ZTXptYVBSZGtwN19rSnFTTTlnZjh0R3BpcmJIUUxlTHFVT0p2My1JTEo2YmJjQTdGVzQ0aWdWSmx4X2dHTlFWZEFiNzcwRFVmYThYOW1fOGc3bzNRcnNXeUFMUFQ0N3JKVmsyMkdYRVZhbmpneUZtVUdVQUpjcHVmNV85aDlQM3c?oc=5"
source_name: "Sky News"
draft: false
---

Les autorités policières du Grand Manchester ont lancé une enquête complète pour homicide suite au décès par arme blanche d'un homme de 27 ans.

<!--more-->

Cet incident tragique a suscité une réponse importante de la part de la police locale, qui lance désormais un appel à témoins pour recueillir toute information susceptible d'éclairer les circonstances de cette agression violente.

Selon les détails communiqués par la police du Grand Manchester, les agents ont été dépêchés sur les lieux après avoir reçu des signalements concernant une agression grave.

À leur arrivée, le personnel médical d'urgence a tenté de prodiguer des soins à la victime, qui souffrait de graves blessures par arme blanche.

Malgré tous leurs efforts, le jeune homme a succombé à ses blessures sur place.

Les détectives chargés de l'enquête ont bouclé la zone pour mener des examens médico-légaux approfondis.

Des équipes de recherche spécialisées passent le voisinage au peigne fin à la recherche d'armes potentielles et d'autres preuves cruciales.

Les autorités examinent également les images de vidéosurveillance des environs et interrogent les résidents locaux pour reconstituer les événements ayant mené à cette attaque fatale.

Les responsables de la police ont souligné que l'enquête n'en était qu'à ses débuts.

Ils exhortent toute personne ayant été témoin d'une activité suspecte ou possédant des images de dashcam ou de téléphone portable pertinentes à se manifester pour aider à l'enquête en cours.

Les leaders de la communauté ont exprimé leur choc face à cette violence, tandis que la police s'est engagée à renforcer les patrouilles dans le quartier pour rassurer la population.

Source: Sky News
