---
title: "Le PDG de Nvidia, Jensen Huang, au cœur de la tourmente sur fond de controverses politiques"
date: 2026-11-17T20:32:55Z
lang: "fr"
mode: "llm_translate"
source_url: "https://arstechnica.com/tech-policy/2026/11/trump-was-in-bed-with-jensen-critics-balk-at-huangs-wish-to-return-to-nvidia/"
source_name: "Ars Technica"
image_url: "https://cdn.arstechnica.net/wp-content/uploads/2026/11/Huang-Trump-billboard-via-TOP-1100x648.jpg"
draft: false
---

Le PDG de Nvidia, Jensen Huang, se retrouve au centre d'une tempête médiatique croissante alors que des rumeurs circulent concernant son éventuel retour au sein de l'entreprise à la suite de sa récente démission.

<!--more-->

La situation s'est complexifiée en raison d'un examen minutieux de la part du public et de critiques politiques virulentes, les détracteurs remettant en question ses associations passées ainsi que le calendrier de son départ.

Les critiques se sont montrées particulièrement véhéentes, certains suggérant que les orientations politiques antérieures de M.

Huang — faisant spécifiquement référence à sa proximité perçue avec Donald Trump — sont incompatibles avec les valeurs actuelles et l'image publique de l'entreprise.

Dans une tentative d'apaiser la montée du sentiment négatif, M.

Huang a publié une déclaration publique exprimant son profond patriotisme, déclarant : « J'aime notre pays.

» Toutefois, ces excuses n'ont guère réussi à satisfaire ses détracteurs, d'autant plus qu'elles coïncident avec une période d'intensification des enquêtes réglementaires visant les pratiques commerciales de Nvidia.

L'entreprise navigue actuellement dans un paysage complexe d'investigations gouvernementales, et l'incertitude entourant sa direction n'a fait qu'accentuer la volatilité autour de ce géant de la technologie.

Les analystes de l'industrie soulignent que le timing de cette controverse est particulièrement précaire.

Nvidia, un titan de l'industrie des semi-conducteurs, fait face à une pression considérable pour maintenir sa domination sur le marché tout en gérant de délicates transitions de direction interne.

La réaction du public face au retour potentiel de M.

Huang met en lumière une tendance plus large où la direction des entreprises est de plus en plus jugée à travers un prisme politique.

Alors que l'entreprise se prépare à publier ses prochains résultats financiers, le conseil d'administration et les parties prenantes subissent une pression immense pour résoudre ces questions de leadership afin d'assurer la stabilité tant pour les investisseurs que pour les employés.

Source: Ars Technica
