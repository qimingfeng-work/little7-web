---
title: "Débat houleux en Italie autour d'un projet de loi visant à réintégrer des médecins antivaccin"
date: 2026-11-12T10:20:09Z
lang: "fr"
mode: "llm_translate"
source_url: "https://www.theguardian.com/world/2026/nov/12/italy-anti-vax-medics-return-vote-meloni"
source_name: "The Guardian World"
image_url: "https://i.guim.co.uk/img/media/1216eca72c56425b39a534e6deaf07ffe9f8d877/0_0_3976_3181/master/3976.jpg?width=140&quality=85&auto=format&fit=max&s=ce164b9a1580b0419f9d7e93333eb712"
draft: false
---

L'Italie est actuellement le théâtre d'un débat houleux concernant un projet de loi législatif qui pourrait permettre la réintégration sur le front médical de médecins radiés de l'ordre en raison de leurs prises de position anti-vaccination.

<!--more-->

Le retour potentiel de ces professionnels a suscité l'alarme parmi les défenseurs de la santé publique, qui craignent que la réintroduction d'individus ayant rejeté le consensus scientifique pendant la pandémie ne mine la confiance envers le système de santé tout entier.

L'avancement de ce texte législatif dépend largement du soutien de personnalités politiques d'extrême droite, au premier rang desquelles figure Roberto Vannacci.

L'influence croissante de ce dernier dans le paysage politique italien a profondément modifié le discours public à l'approche des élections de 2027, faisant de la réintégration de ces praticiens un enjeu hautement symbolique pour certaines fractions de l'électorat.

Les partisans du projet de loi plaident pour le pardon professionnel et invoquent la nécessité impérieuse de faire face aux pénuries de personnel soignant, tandis que les critiques y voient une concession dangereuse à la rhétorique anti-science.

Le coût humain de la pandémie demeure un souvenir vivace pour de nombreux Italiens.

Antonio Cremasco, un résident de Bassano del Grappa, constitue un rappel poignant de la gravité de cette crise sanitaire.

Ayant passé quarante jours dans un établissement hospitalier, dont vingt en soins intensifs, M.

Cremasco a fait l'expérience directe du potentiel salvateur de l'intervention médicale.

Pour lui, la décision de se faire vacciner constituait une étape logique dans son parcours de guérison et une protection indispensable contre de futures maladies.

Son expérience contraste fortement avec les points de vue défendus par ceux qui ont activement fait campagne contre les efforts de vaccination.

Alors que le débat politique se poursuit, la communauté médicale demeure profondément divisée.

De nombreux médecins soutiennent que le serment d'Hippocrate et l'engagement indéfectible envers la médecine fondée sur les faits ne sont pas négociables.

Réintégrer ceux qui ont ouvertement défié les directives de santé publique pourrait, selon eux, créer un précédent pour le moins périlleux.

À l'approche des échéances électorales de 2027, le sort de ce projet de loi restera vraisemblablement un point de friction majeur au sein de la guerre culturelle plus vaste, reflétant les fractures profondes qui traversent la société italienne en matière d'autorité, de science et de liberté individuelle.

Source: The Guardian World
