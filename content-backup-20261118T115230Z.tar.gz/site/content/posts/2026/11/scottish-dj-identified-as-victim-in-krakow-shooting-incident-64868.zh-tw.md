---
title: "蘇格蘭 DJ 在波蘭克拉科夫遭槍擊，疑與極右翼極端主義有關"
date: Wed, 11 Nov 2026 11:33:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMioAFBVV95cUxNWFNHSE54cFB1aEsxb29BOTZiYTdSVkRCNWlQUmNscFpDUElkZFRVa3NhT20xdzRyc2ktY3ZEMWRva2xYTENTZldjdUl2eTNSLTdBeXhyYW4wRERVRFVXVGlSazk0R3A3SkItYWoyb25uWEZ0TUZwMGZ1NE01bXpTU09pazRLQk9iaWFhTFNQN0dGdk1nVFBnWGJyTzZaTW5O?oc=5"
source_name: "The Telegraph"
draft: false
---

一名蘇格蘭 DJ 在波蘭克拉科夫遭遇槍擊事件，這起事件震驚了當地社群以及受害者的家鄉。該名男子當時正在該市旅遊，不幸捲入了一場暴力襲擊，事件中還導致一名來自約克的 19 歲男子受傷。

<!--more-->

波蘭當局已針對此案展開重大調查，並將其視為具有潛在意識形態色彩的嚴重刑事案件處理。根據波蘭司法部長的說法，槍手似乎受到極端意識形態的影響。

從嫌疑人的數位足跡中收集的證據顯示，他曾瀏覽過與 2011 年挪威大屠殺兇手安德斯·佈列維克（Anders Behring Breivik）相關的網站。這一連結促使調查人員在其背景中尋找「極右翼極端主義的強烈痕跡」。

此事件引發了波蘭執法部門的迅速反應，他們正努力釐清這場襲擊是有預謀的恐怖行動，還是突發的暴力爆發。兩名受害者皆因私人原因前往克拉科夫，卻在公共場所遭到攻擊，引發廣泛恐慌。

英國政府正為受影響家庭提供領事協助，而克拉科夫當地當局則加強了熱門旅遊景點的安全措施。隨著調查持續進行，焦點仍集中在嫌疑人的動機，以及他是單獨行動還是隸屬於更廣泛的極端分子網路。

這場悲劇凸顯了激進化個人帶來的持續威脅，以及在數位招募時代監控極端活動所面臨的挑戰。

來源: The Telegraph
