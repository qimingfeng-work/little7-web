---
title: "Tragédie à Leeds : deux morts après une course-poursuite policière"
date: 2026-11-15T09:53:11Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiXkFVX3lxTE1xSjFWSENqRUJJczNrVUktR0MxeTg0UFVHVGNZQWtMdENlQlJIb0ZDZjZieUZxMWtWeFJseFMySFBZVTBqa3BNWXQ1LVNKZF9QQUJPaU04dGhaZURXMFE?oc=5"
source_name: "BBC"
draft: false
---

Une collision routière tragique à Leeds a entraîné la mort de deux personnes après qu'un véhicule fuyant les forces de l'ordre a percuté une autre voiture.

<!--more-->

L'incident a suscité une vive inquiétude et a déclenché des procédures d'enquête standard concernant les poursuites policières dans les zones urbaines.

Selon les autorités locales et les rapports des principaux médias britanniques, la séquence des événements a commencé lorsque la police a tenté d'arrêter un véhicule.

Plutôt que de s'arrêter, le conducteur a accéléré, entamant une course-poursuite à grande vitesse dans les rues de la ville.

La poursuite a pris fin de manière dévastatrice lorsque le véhicule en fuite est entré violemment en collision avec une voiture tierce innocente.

Les services d'urgence se sont précipités sur les lieux après l'accident, mais malgré l'intervention rapide des ambulanciers et des pompiers, deux personnes ont subi des blessures mortelles et ont été déclarées mortes sur place.

L'identité exacte des victimes n'a pas été immédiatement révélée dans l'attente de la notification aux proches.

L'incident a relancé les discussions sur les protocoles et les risques potentiels associés aux poursuites policières.

Les forces de l'ordre sont confrontées au défi permanent d'équilibrer la nécessité d'appréhender les suspects en fuite avec la sécurité du grand public.

Des organismes de surveillance indépendants devraient examiner les circonstances ayant conduit à la collision afin de déterminer si les protocoles appropriés ont été suivis pendant la poursuite.

Alors que l'enquête se poursuit, les membres de la communauté locale ont exprimé leur choc et leur tristesse face à la perte soudaine de vies humaines résultant des actions imprudentes du conducteur en fuite.

Les autorités ont appelé tous les témoins ou individus possédant des images de caméra embarquée à se manifester pour aider à l'enquête en cours.

Source: BBC
