---
title: "華盛頓高爾夫球場法律糾紛升級，法官下令調查政府律師行為"
date: Sat, 07 Nov 2026 18:34:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiogFBVV95cUxNRDZaRHNfaVJoem5LcFRtZWJBbFV3YmFwSGFJTzRqUm1IVzNINDVSMkFiWFFSMXJ3bnNkYV9MMjFFZ0R0X3l2TXBKdGU4RlZNTW93YWw4WkV3QTM4cjRyaUxHUTd3SUdXdTJEcHdfa0psWUt6dVExVzlrcmVlNXVRQTN1Y1JQNkdRV25xN3Vqd3VWaUVzOEZYMVJkSEgyN29EWWc?oc=5"
source_name: "Politico"
draft: false
---

在涉及華盛頓特區一處歷史悠久的高爾夫球場的激烈法律鬥爭中，一名聯邦法官採取了重大行動，任命了一名前檢察官調查政府律師是否存在潛在的道德違規行為。調查重點在於特朗普政府時期律師在處理與該物業相關的法律訴訟中的行為表現。

<!--more-->

此次任命源於外界指控，稱政府律師在代表行政部門利益時可能存在不當行為，或未能遵守職業道德標準。法官決定引入外部法律專家，凸顯了法院對這些指控的重視程度。

調查旨在釐清政府的法律策略是否越界構成了不當行為。該案件本身涉及關於東波托馬克（East Potomac）高爾夫球場未來的更廣泛爭議。

特朗普政府的開發計劃遭到反對，當地民眾和利益相關方積極尋求阻止該場地的關閉或重新開發。公眾利益團體對擬議變更可能帶來的損失表示擔憂，這為正在進行的法律訴訟增添了公眾監督的壓力。

法律專家指出，任命一名前特朗普任命的檢察官來領導此次調查是一項戰略舉措，旨在確保公正性並維護司法程序的完整性。通過選擇具有前政府背景的人選，法院旨在避免偏見嫌疑，同時對相關律師的行為進行嚴格審查。

隨著調查展開，其結果可能對該高爾夫球場案以及政府律師應遵循的更廣泛行為標準產生重大影響。預計調查將深入挖掘內部通訊和法律檔案，以確定是否存在蓄意誤導法院或繞過既定法律程式的行為。

目前，各方目光均聚焦於即將釋出的報告，該報告極有可能影響法院對高爾夫球場未來的最終裁決。此案不僅關乎一處公共土地的用途，更觸及了政府行政權與司法獨立性之間的敏感邊界。

來源: Politico
