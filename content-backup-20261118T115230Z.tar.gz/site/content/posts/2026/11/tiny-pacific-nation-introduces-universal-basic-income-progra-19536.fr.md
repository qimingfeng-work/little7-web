---
title: "Une nation insulaire du Pacifique lance un programme national de revenu universel"
date: Sun, 01 Nov 2026 10:05:09 +0000
lang: "fr"
mode: "llm_translate"
source_url: "https://www.economist.com/asia/2026/10/29/a-tiny-pacific-country-rolls-out-universal-basic-income"
source_name: "Hacker News"
draft: false
---

Un État insulaire isolé de l'océan Pacifique a franchi une étape audacieuse vers la sécurité économique en lançant une initiative nationale de revenu universel de base.

<!--more-->

Cette politique sans précédent garantit des distributions financières régulières à tous les citoyens, positionnant le petit territoire souverain à l'avant-garde de l'expérimentation moderne en matière de protection sociale.

Bien que les détails concernant les mécanismes de financement exacts et les calendriers de paiement soient encore en cours de déploiement, les analystes régionaux notent que le programme vise à éradiquer l'extrême pauvreté et à stabiliser les finances des ménages à travers l'archipel.

Le gouvernement a conçu le cadre pour garantir que chaque résident reçoive une allocation monétaire prévisible, indépendamment de son statut d'emploi ou de sa richesse personnelle.

Les partisans de la mesure soutiennent que les transferts monétaires directs représentent la méthode la plus efficace pour élever les populations marginalisées et stimuler le commerce local.

En mettant l'argent directement entre les mains des consommateurs, les décideurs espèrent dynamiser les petites entreprises et favoriser une plus grande résilience économique au sein de la communauté isolée.

Cependant, les critiques et les économistes étrangers surveillent de près le déploiement pour évaluer si une nation aussi compacte peut soutenir des dépenses budgétaires à long terme sans provoquer d'inflation ou mettre à rude épreuve les budgets publics.

L'initiative place l'île du Pacifique aux côtés d'une liste croissante de municipalités et de zones expérimentales à travers le monde qui ont testé des modèles de revenu garanti.

Pourtant, la mise en œuvre de ce concept à l'échelle nationale reste un exploit rare, généralement entravé par l'impasse politique et les coûts prohibitifs dans les grands pays industrialisés.

Les observateurs suggèrent que le profil démographique distinct et l'économie localisée de la nation ont peut-être fourni un terrain d'essai idéal pour une réforme que de nombreux États plus grands considèrent comme purement théorique.

Alors que la première vague de paiements atteint les citoyens, les chercheurs internationaux et les experts en politiques suivront des indicateurs clés tels que les taux d'emploi, les résultats en matière de santé et les investissements dans l'éducation.

Le succès de cette entreprise dans le Pacifique pourrait fortement influencer la manière dont d'autres petits gouvernements abordent la réduction de la pauvreté et les filets de sécurité sociale au cours des prochaines décennies.

Source: Hacker News
