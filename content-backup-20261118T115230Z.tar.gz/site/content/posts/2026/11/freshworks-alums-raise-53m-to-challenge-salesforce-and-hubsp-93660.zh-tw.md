---
title: "AI 原生 CRM 新創 Dreamteam 獲 5300 萬美元融資，挑戰產業巨頭"
date: 2026-11-16T12:30:00Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://techcrunch.com/2026/11/16/freshworks-alums-raise-53m-to-take-on-salesforce-hubspot-with-ai-native-crm/"
source_name: "TechCrunch"
draft: false
---

由 Freshworks 校友創立的新創公司 Dreamteam，近日成功獲得 5300 萬美元的融資。該公司旨在顛覆目前由 Salesforce 和 HubSpot 等科技巨頭主導的客戶關係管理（CRM）市場。

<!--more-->

Dreamteam 將其平臺定位為「AI 原生」CRM，從底層架構設計之初便旨在為現代銷售與支援團隊充分利用人工智慧技術。儘管進入了一個競爭激烈且市場成熟的產業，Dreamteam 已經取得了顯著進展。

根據公司報告，該新創公司已在 13 個國家簽下了超過 100 家客戶。值得注意的是，部分早期採用者已主動從傳統的舊式 CRM 系統轉向 Dreamteam，以採用其更精簡、以自動化為核心的替代方案。

這筆巨額融資凸顯了投資人對於企業軟體的強烈興趣，特別是那些將生成式 AI 與先進自動化技術原生整合，而非僅作為附加功能的產品。

產業分析師指出，儘管 Salesforce 和 HubSpot 等公司持續在其龐大的生態系統中增加 AI 功能，但靈活的新創公司正押注於徹底重新設計使用者體驗，以吸引尋求更高效率的成長型企業。

Dreamteam 計畫利用這筆資金進一步開發其核心產品，擴大工程與市場推廣團隊，並擴充套件其全球業務。隨著 AI 驅動軟體領域的競爭日益激烈，該新創公司的早期動能顯示，企業越來越願意探索替代方案，以滿足其客戶管理需求。

來源: TechCrunch
