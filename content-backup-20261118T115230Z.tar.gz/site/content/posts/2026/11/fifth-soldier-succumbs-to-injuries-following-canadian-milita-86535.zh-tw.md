---
title: "加拿大軍隊痛失第五名士兵：溫萊特基地訓練火災悲劇引發全國哀悼"
date: 2026-11-15T01:52:00Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiqwFBVV95cUxNbXVic0tteXJQZFNLYUpUUDBUcnFSS2p4Z1lSbW04ZXljajhyVjRuTXNib0dvanhZMWxyUlFudTlZcXdGUkxKYkdKRHk5QWRwRWN2TjZ3bXRsTTZ4clhqSGwwLWhBZHRaZ0l4aHBld2swV255Y1VYZVVQSkprdXh2WEQ2Ny1laXA2aFdLTUlLTnZXY3pQOVRjaEVuUmpsUDNuUDQ0cXVuNDJvSHc?oc=5"
source_name: "NBC News"
draft: false
---

加拿大軍隊正為第五名在溫萊特基地（CFB Wainwright）訓練火災中喪生計程車兵哀悼。這起事件對軍事社群造成了巨大衝擊，火災導致多名人員受到嚴重傷害。

<!--more-->

儘管醫療專業人員竭盡全力搶救，但死亡人數仍持續上升，這成為加拿大近代軍事史上最沉痛的篇章之一。火災發生於例行訓練演習期間，凸顯了軍事準備工作中固有的風險。

官員已證實，該名士兵因火災造成的傷勢併發症而不治。這場悲劇引發了全國範圍內的哀悼與支援，各組織與地方社群紛紛響應，協助受難者家屬度過難關。

在聖艾伯特（St.Albert），今年的國殤紀念日儀式顯得格外沉重，社群特別向陣亡的「帕特里夏公主加拿大輕步兵團」（PPCLI）成員致敬。

這場悲劇也激發了顯著的慈善行動；例如，薩斯喀徹溫堡（Fort Saskatchewan）退伍軍人協會從其罌粟花基金中捐贈了10萬加元，以支援受害者及其家屬。此舉反映了退伍軍人社群與廣大公眾之間深厚的團結感。

隨著火災原因的調查持續進行，軍方領導層強調了對透明度與安全性的承諾。在單一訓練事故中失去五條生命是一個毀滅性的打擊，這無疑將導致軍方對溫萊特基地的安全規程與操作程式進行嚴格審查。

目前，軍方的重點仍放在支援悲痛的家屬，並向那些在職責中犧牲的軍人致敬。

來源: NBC News
