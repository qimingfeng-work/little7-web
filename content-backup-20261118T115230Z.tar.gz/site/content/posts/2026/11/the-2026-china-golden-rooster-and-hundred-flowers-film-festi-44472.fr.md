---
title: "Le Festival du film des Coqs d'or et des Cent Fleurs 2026 s'ouvre à Xiamen"
date: Sat, 07 Nov 2026 06:21:46 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiaEFVX3lxTE14T0xremNFa1FYQVRCMFJNbW92S0NoZ0hxX0NjdzZ6dFF6aHQ4NHptSkd2VVRmbGctdnJKbG1hbHVVUldXc1BnT1IxeDk0QXNiaVlXdmlBNFh3dmFXbnRMeVV4Qy1ySVhr?oc=5"
source_name: "中国新闻网"
draft: false
---

Le Festival du film des Coqs d'or et des Cent Fleurs 2026 a officiellement débuté dans la ville côtière de Xiamen, marquant une étape importante pour l'industrie cinématographique chinoise.

<!--more-->

La cérémonie d'ouverture a été un événement prestigieux, avec les acteurs de renom Huang Xiaoming et Zhao Liying au centre de la scène pour illuminer l'emblématique statue du Coq d'or, signalant le début de cet événement cinématographique majeur.

En tant que l'un des rassemblements les plus attendus du calendrier cinématographique chinois, le festival sert de plateforme pour célébrer l'excellence artistique et l'innovation industrielle.

La 39e édition des prix du Coq d'or est au cœur des festivités, les lauréats dans diverses catégories devant être annoncés le 10 novembre.

L'attente est forte, alors que les cinéastes, les critiques et le public attendent de voir quels projets et quelles performances seront honorés cette année.

Au-delà des remises de prix, le festival a transformé Xiamen en un centre dynamique d'activité culturelle.

La rue Zhongshan de la ville a été illuminée par des décorations festives, attirant des foules de fans et de touristes désireux de s'imprégner de l'atmosphère.

L'événement n'est pas seulement une célébration du cinéma, mais aussi une vitrine pour la haute technologie et les partenariats industriels.

Notamment, la marque automobile AITO a utilisé cette plateforme pour présenter ses derniers modèles, le Wenjie M9 et le nouveau M8, intégrant ainsi les mondes de la fabrication de haute technologie et des arts cinématographiques.

Les experts de l'industrie notent que le festival de cette année met l'accent à la fois sur la narration traditionnelle et sur les avancées techniques modernes.

La présence de stars établies comme Huang Xiaoming et Zhao Liying, aux côtés de talents émergents comme Li Gengxi, souligne le pont générationnel qui définit actuellement le cinéma chinois.

Alors que le festival se poursuit, il devrait favoriser des discussions approfondies sur l'avenir de la production cinématographique et le rôle de la collaboration internationale à l'ère numérique.

L'événement demeure un témoignage de l'attrait durable des prix du Coq d'or en tant que référence de qualité dans l'industrie cinématographique de langue chinoise.

Source: China News Service
