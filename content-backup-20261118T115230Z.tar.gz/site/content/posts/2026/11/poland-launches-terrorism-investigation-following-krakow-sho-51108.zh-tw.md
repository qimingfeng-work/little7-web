---
title: "波蘭克拉科夫發生致命槍擊事件，當局啟動恐怖主義調查"
date: Sun, 08 Nov 2026 16:02:09 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMizwJBVV95cUxNUVVqdzRSbE16aW9TaUFHYVFtYkJ6QXNyaHRJZm5TV21BakJvNm1ESXhUbHVJTl93THFkcklraWtrNlg2NTdKeUE2UTRFVUFHSDVMVXBVYm0yMGZ2Q3labUxMamY0YVF5T2lxa2tGM3BTaDZ4REgxWHB1UkpQeFNHMkxfLVE2ZXZ0c0QtcnIzdWU4aDhnVDRqNTEycWdNVmx6S0dQRFotdWYxOWFjQzlZUG82elpsWm9UUWF0VlNKV0RzRVNqQzNiVEJ2N3ZHRUJ1VVktTDJlUjdUV0NpUEZORU05ODV2REZoVU5OaFJCMngtaU9DdTZOTkpITWlqUjdkemttRHJ0dl9NWS1wbEt1UGFsSnVWWHZFMkJXMDNkUkVlaFVkV3ExeEUwLThhVjBDeDdVMGFyRERTU3dKRDlVeEl6MllMamJPa2x2aEpIVQ?oc=5"
source_name: "RFI"
draft: false
---

波蘭當局已正式針對近日發生在歷史名城克拉科夫的一起致命槍擊事件啟動了恐怖主義調查。這起慘劇造成 6 人死亡、15 人受傷，在波蘭全國範圍內引發了巨大震動，並促使政府採取了嚴厲的安保響應措施。

<!--more-->

據目擊者描述，行兇者身穿防彈衣，手持自動步槍，在歐洲最大的中世紀廣場之一向人群開火，將這一著名的旅遊勝地瞬間變成了混亂與悲劇的現場。據報道，槍手在市中心地帶針對平民進行無差別攻擊，迫使遊客和當地居民紛紛躲避在歷史建築後方。

由於暴力事件的規模巨大，波蘭官方已將此案定性為潛在的恐怖主義行為。目前，調查人員正全力核實嫌疑人的動機，並排查其是否與極端組織存在關聯。

儘管當地和國際媒體對襲擊的“極右翼”性質進行了大量猜測，但當局呼籲公眾保持冷靜，等待正式調查結果。事件發生後，事發區域立即被封鎖，緊急救援人員迅速趕往現場救治傷者。

此次襲擊受到了包括聯合國在內的國際機構的強烈譴責，聯合國特別強調了歷史遺蹟在面對此類暴力行為時的脆弱性。隨著調查的深入，波蘭政府面臨著巨大的輿論壓力，公眾要求解釋為何一名全副武裝的個人能夠在人流密集的公共場所實施如此嚴重的襲擊。

這場悲劇在波蘭引發了關於國家安全以及歐洲政治極端主義抬頭的全國性討論。隨著調查的持續進行，克拉科夫市民仍沉浸在哀悼遇難者的悲痛中，而波蘭全國的安全部隊也保持著高度戒備狀態。

此次事件不僅是對波蘭公共安全的挑戰，也再次引發了歐洲各國對於防範此類“獨狼式”恐怖襲擊的深層反思。

來源: RFI, BBC, 觀察者網, 新華網, 新浪網
