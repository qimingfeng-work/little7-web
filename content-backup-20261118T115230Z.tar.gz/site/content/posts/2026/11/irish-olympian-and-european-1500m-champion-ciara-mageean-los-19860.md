---
title: "Irish Olympian and European 1500m Champion Ciara Mageean Loses Cancer Battle at 34"
date: Sun, 01 Nov 2026 10:05:00 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMilgFBVV95cUxNdXV5ZmF4bzlxWWxRTWtNZnNrTl9SRlplQzlxQWdzdi1BN2Q5aTZqNHpJSEkxZ0cwYjZtLWo5d3o5WHFFZU9KazZjZUlqeHpoVy1CV0R0bm45WGRNSHpTLVZHbnNWVTI0VkI0UGN4bHluVE41a1VrbGtLdDdOYVFJZEJ4S09ZUzJNcFpjbHpsdElBMXhQSVHSAZsBQVVfeXFMTzJsb1VfUWswMzc5RksxTDJ1T2JLN0ExZTRvZnItSnhVMmhrYVVNWjlmcVNzamhIZFBPcGRWSVVWMGdpdFZhMzR1a0hCT0g3YkJULWxmVTltMDd6VUYwYjlET1RIQ211Q0I0NGNWUEk3YjRHblRGSW1ia0pTZDRxMTJfYnoyekxZSGhWeEI3RVllcjBjX1N1VjY1aU0?oc=5"
source_name: "Belfast Live"
draft: false
---

The sports community is in mourning following the death of renowned Irish athlete Ciara Mageean. The Olympian and European champion passed away at the age of 34 after a courageous and private struggle with cancer. 

<!--more-->

Mageean cemented her legacy as one of Ireland’s most celebrated middle-distance runners through a career defined by resilience, talent, and historic achievements on the track. Representing her country with distinction on the global stage, she competed at multiple Olympic Games and consistently placed herself among the elite competitors in international athletics. 

Her crowning sporting achievement arrived when she captured the prestigious 1500-meter gold medal at the European Championships, a milestone that brought immense pride to the Irish sporting landscape. Beyond that victory, she collected numerous medals and set national records, inspiring a new generation of runners across the island. 

News of her passing has prompted an outpouring of sorrow and heartfelt tributes from fellow athletes, sports administrators, and political figures alike. Many have highlighted not only her extraordinary athletic prowess but also her tenacity, warmth, and grace under pressure. Throughout her illness, Mageean maintained the fierce determination that characterized her time on the track, fighting the disease with the same unwavering spirit she brought to every race.

Her untimely death leaves a profound void within Irish sport. She is remembered as a trailblazer who elevated middle-distance running in Ireland to unprecedented heights and left an indelible mark on the international athletic community. 

Sources: Belfast Live
