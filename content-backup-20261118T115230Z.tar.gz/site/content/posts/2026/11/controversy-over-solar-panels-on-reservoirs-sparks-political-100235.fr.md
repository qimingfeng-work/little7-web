---
title: "Controverse à Taïwan : le débat sur les panneaux solaires dans les réservoirs s'intensifie"
date: 2026-11-17T07:11:29Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiakFVX3lxTE1kbG13SGpDUGRWM1p1SE5iYXNMMmdwbWdTbEVWN2F3VEFhMm9xSHFZcTczLU5yazBZWXlUWkpYM2JEclhoODl5QWxCUDBtR2hjVGZhMXNYUHFfcE80cXY2U2hORk5kQm5pa2fSAW9BVV95cUxPUzRONTcwbC1LQzdOWjRHYjQxZl94ZExZWkZlTDRyVWpTeWo5ZmhtN2xicEkzMDhkZTJ6WkNyOXpaUmtXQVFDck9IMVM3MGpOdHBhb0twLXYxOUFpb2VUNzk2SFJCSkVLLXp6c096SGM?oc=5"
source_name: "自由時報"
draft: false
---

Un débat politique houleux a éclaté à Taïwan concernant l'installation de panneaux solaires sur les réservoirs d'eau.

<!--more-->

Le camp bleu (Kuomintang) a soulevé des inquiétudes quant à une potentielle pollution environnementale.

Cependant, le site officiel du gouvernement de la ville de Taipei a involontairement contredit ces affirmations, déclarant que les installations solaires sont conçues pour être écologiquement sûres et qu'elles ne provoqueront aucune contamination de l'eau.

La controverse a impliqué diverses personnalités politiques, le maire de Taipei, Chiang Wan-an, exprimant son opposition aux projets solaires au réservoir de Feitsui.

En réponse, des responsables gouvernementaux, dont le secrétaire général du Yuan exécutif, Cho Jung-tai, ont précisé qu'il n'existait actuellement aucun projet d'installation de panneaux solaires à cet endroit précis.

Cela a conduit à des accusations de « guerre cognitive », certains législateurs critiquant l'incohérence des messages politiques concernant les projets d'énergie renouvelable.

Des différends similaires ont fait surface concernant le réservoir de Wushantou.

Alors que certains candidats politiques locaux ont allégué que les panneaux solaires pourraient causer une contamination au plomb, l'entreprise responsable du projet, Star Energy, a catégoriquement nié ces affirmations et a engagé des poursuites judiciaires contre ceux qui propagent ce qu'ils qualifient de désinformation.

Les partisans des initiatives solaires soutiennent que ces projets sont essentiels pour la transition énergétique de Taïwan et que les préoccupations soulevées sont motivées par des intérêts politiques plutôt que par des preuves scientifiques.

L'incident met en lumière les défis plus larges auxquels Taïwan est confronté pour équilibrer ses objectifs ambitieux en matière d'énergie verte avec les préoccupations du public concernant la protection de l'environnement et l'utilisation des terres.

Alors que le débat se poursuit, le gouvernement subit des pressions pour fournir des informations transparentes et fondées sur la science afin de dissiper les rumeurs et de garantir que la transition vers les énergies renouvelables reste sur la bonne voie sans compromettre l'intégrité des ressources en eau de l'île.

Source: Liberty Times, UDN, Public Television Service (PNN), Yahoo News
