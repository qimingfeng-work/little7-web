---
title: "Leadership Shakeup at DC Studios: James Gunn and Peter Safran Depart as Jeremy Latcham Takes the Helm"
date: Mon, 09 Nov 2026 17:49:18 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMijAFBVV95cUxOYmZMU2dYeU9ESlMzQnlqSElWekVnTS1nNW1RVVZwRHNtT0djaWZWZGQ3eXpSNW1xZzBnN1Z2YUIxSkY4OVBFdnl5a0UtakVhVktxd01ZQndobGxQaEJJV0hTR2lKcHdEMUVvcXpfamFxYlJEV2tHbUZTQnV4SElENmg3RU1GSy1GWW0yWg?oc=5"
source_name: "Empire"
draft: false
---

In a major development that has sent ripples through the entertainment industry, DC Studios has officially announced that CEOs James Gunn and Peter Safran are stepping down from their roles. The transition marks a significant turning point for the studio as it looks to redefine its cinematic strategy and creative direction moving forward.

<!--more-->

Replacing the outgoing duo is former Marvel executive Jeremy Latcham, who has been named the new President and Chief Creative Officer. Latcham brings a wealth of experience from his tenure at Marvel, where he was instrumental in the development of several high-profile projects. His appointment is seen by industry analysts as a strategic move to stabilize the DC brand and potentially align its production quality with the successful models seen in other major franchises.

David Ellison, a key figure in the industry, has publicly praised the contributions of Gunn and Safran during their time at the helm, acknowledging their efforts to navigate the complex landscape of superhero filmmaking. However, the decision to pivot toward new leadership suggests that the studio is eager for a fresh perspective. The departure of Gunn and Safran, who were initially brought on to revitalize the DC Extended Universe, comes amidst a period of intense scrutiny regarding the studio's long-term vision.

The arrival of Jeremy Latcham is expected to bring a shift in creative philosophy. With his background in building interconnected cinematic universes, stakeholders are optimistic that he can foster a more cohesive and commercially successful slate of films. As the industry watches closely, the focus remains on how Latcham will reshape the DC portfolio and whether this change will finally provide the consistency that fans and investors have been demanding.

Sources: Empire
