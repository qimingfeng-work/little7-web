---
title: "Arrestations à Blackwood : la police enquête sur la sécurité d'une garderie"
date: Thu, 05 Nov 2026 22:11:18 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMikAFBVV95cUxNT1lSRzhuNVVYT0p0QldsWUlxTDVaQ0hlUWRvZnNIbUVLR1ZWYjhzd0dDSjhUZGxGa3VDNVpHczRoRC1lbmV1TTJiUEhlWlBLdFRXR1RmZ0RjM1p0emF1LS05c0k1RWx3WUlIVFlYZDN2UGhWOUJFXzJuVFFHSE5KWjNTaWN4cEpxYmFnV2c0Z2PSAZYBQVVfeXFMUDZmZmsycTRIZ0JNRm5WRGt0emZyQkl4cS1RcmtmTWNMcUwxUms0VEVoXzdlR2J1MWc5cFp2Y0Q3STV2REt0ZnpsNzB5VTlleF9JWFJjSjZpdkMwZzFJV3IxVmYzaGpsNkpBWGZkMWRUbXFlOXpCbkx4N2wxRzhBaFFnRTZETGRRQ29kRXdfaFpFakljMkFR?oc=5"
source_name: "Wales Online"
draft: false
---

Les forces de l'ordre au Royaume-Uni ont récemment placé deux individus en garde à vue à la suite d'une enquête approfondie menée dans une garderie de Blackwood, située dans la région de Gwent.

<!--more-->

Cette intervention policière d'envergure a été déclenchée après que des signalements particulièrement préoccupants ont été transmis aux autorités compétentes concernant le bien-être, la sécurité et la protection des jeunes enfants accueillis au sein de cet établissement.

La police de Gwent a par la suite publié des communiqués officiels confirmant qu'un homme et une femme avaient été appréhendés et placés en détention provisoire, tous deux soupçonnés de négligence envers des enfants.

Cette action soudaine des forces de l'ordre a naturellement provoqué une vive émotion ainsi qu'une profonde inquiétude parmi les parents d'élèves et l'ensemble de la communauté locale.

Face à cette situation alarmante, les familles exigent désormais transparence et réponses claires concernant les opérations quotidiennes, les protocoles de surveillance et les normes de sécurité appliquées au sein de la garderie.

En parallèle, les services de protection de l'enfance et les autorités locales poursuivent leurs investigations minutieuses pour faire toute la lumière sur ces allégations troublantes.

Des cellules de soutien psychologique et des services d'assistance ont été mis en place et rendus accessibles aux familles touchées par cette épreuve, tandis que les enquêteurs s'attellent à rassembler les éléments de preuve nécessaires et à évaluer la conformité stricte de l'établissement avec la réglementation en vigueur en matière de garde d'enfants.

Les détails de cette affaire continuent de mobiliser l'attention des médias régionaux et nationaux, témoignant de la gravité des faits reprochés et de l'exigence de responsabilité dans les structures d'accueil de la petite enfance.

Source: Wales Online
