---
title: "歐盟擴大制裁俄國經濟核心：Wildberries 執行長塔季揚娜·金遭列名單"
date: 2026-11-16T17:11:52Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMihAFBVV95cUxONW4wMEE5cnhoc2pmTGRNR0JteHNSNUwtUkJrMzRtV3ZCYjR4SEpuOHJvU2lLT3E3alRVMC1JckJEZDhsTlBzb09oQktOdi1MU3dnaWlPNHQ3cEZfWnJKMzBTaE1ETmU0OHE5YndBOEw2SU9GN1pIX0liNTJQUXZKb0lDT00?oc=5"
source_name: "Financial Times"
draft: false
---

歐盟已正式對線上零售巨頭 Wildberries 的執行長塔季揚娜·金（Tatyana Kim）實施制裁。塔季揚娜·金被廣泛認為是俄羅斯首富，此舉是歐盟擴大制裁計畫的一部分，旨在針對那些被認定支援莫斯科在烏克蘭持續軍事行動的個人與實體。

<!--more-->

這項決定標誌著歐盟在施壓俄羅斯經濟方面的重大升級，其策略核心在於鎖定那些與克里姆林宮基礎設施有深厚連結的高知名度商業領袖。Wildberries 是俄羅斯電子商務領域的基石，過去一年更積極將業務版圖擴充套件至非洲市場。

透過制裁塔季揚娜·金，歐盟明確傳達了一個訊號：在衝突的後果面前，沒有任何商業大亨能夠置身事外。制裁措施包括資產凍結與旅行禁令，意在擾亂支援俄羅斯政府的金融網路。

除了塔季揚娜·金之外，歐盟還針對了多個參與管理莫斯科「影子船隊」（shadow fleet）油輪的實體，這些船隊被用於規避國際能源制裁。這輪最新的制裁措施涉及 145 個名稱與實體，反映了歐盟在冬季臨近之際，試圖孤立俄羅斯經濟的廣泛戰略。

布魯塞爾的官員指責莫斯科在拖延和平談判的同時，持續針對烏克蘭的關鍵能源基礎設施進行攻擊。這些針對發電廠的攻擊所造成的嚴重人道主義影響，已成為爭議焦點，促使歐盟加強對那些為俄羅斯戰爭機器提供便利的個人之管控。

塔季揚娜·金被列入制裁名單，凸顯了當前地緣政治氣候下，私人企業與國家利益之間的交集。儘管 Wildberries 主要作為商業實體運作，但歐盟的行動顯示，該集團認為該公司的領導層與俄羅斯更廣泛的經濟體系密不可分。

隨著衝突持續演變，國際觀察家正密切關注這些制裁將如何影響俄羅斯商業菁英的行為，以及它們是否能對克里姆林宮維持軍事行動的能力產生實質影響。這場經濟戰的升級，不僅考驗著俄羅斯企業的韌性，也反映出西方國家試圖透過切斷經濟命脈來終結戰事的決心。

來源: Financial Times
