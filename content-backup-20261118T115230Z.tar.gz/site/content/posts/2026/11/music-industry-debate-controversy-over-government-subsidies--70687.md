---
title: "Music Industry Debate: Controversy Over Government Subsidies and Artist Status"
date: 2026-11-12T11:09:14Z
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMi2gJBVV95cUxPZjlnVndORmN1QkJiWko2UzVWOXBtaWFfek8zMW1NYWZZbndkMG1COXVnZGZCTVhQdHpseUtFQ19wRFM0djU1aTNiQnQ1YnBnUHdqS1lNbWFwUHJmZERueWFVeEVLeXlTeFU3MXlFb1h0VUQ3dUFET205RVZhUmFxZm9JT3I5SjRnOXhoanYtcmhBNGF1VWUxNmI5QTZFLWRiU1RaU0RmYnJrLWRTdHpaNjE1aUZLMmdGMGs0eEozOHdCaTV4R3hmajU5YTROUXROeHZ2UVhhWXNDM2Y1amNKbWRjRVMtUWZpZ3RkOFk1TFFObGg3Vl9VUnBMLUlzU0NvRjdRYUpMT1liOGNPVDJMZjRpUWdWNUJNNGxWRklzYm4yZ0xCbi10bFpLbU9LNVFKd3hQTHFVemdZUGc2VzRZam5BRlBYNWUya1JBVS1zT0NRSk5XOXlJMkZ3?oc=5"
source_name: "Yahoo新聞"
draft: false
---

A heated debate has erupted in the Taiwanese music industry following criticisms directed at veteran singer Lo Ta-yu, which subsequently led to the exposure of the critic's own significant receipt of government subsidies. The controversy began when a musician, associated with the 'Blue Bird' movement, challenged Lo Ta-yu's status and influence in the Mandopop scene, prompting a sharp rebuttal from public figures and commentators, including social media personality Chen Yi.

<!--more-->

Chen Yi criticized the musician, labeling them a 'subsidy seeker' after it was revealed that the individual had received approximately 16 million NTD in government grants over a four-year period. This revelation sparked a broader discussion about the allocation of public funds in the cultural and creative sectors. Critics argued that artists who rely heavily on government support should be more mindful of their public commentary, especially when attacking legendary figures like Lo Ta-yu, who is widely regarded as a founding father of modern Chinese-language music.

Internet personality Cheap also weighed in on the matter, suggesting that despite the musician's criticisms, Lo Ta-yu's legacy remains untouchable. Cheap noted that in the industry, one must show respect to such 'ancestral' figures, regardless of personal or political differences. The debate has highlighted the tension between artistic freedom and the responsibilities that come with receiving public funding. Many netizens have questioned whether the current subsidy system is being used effectively or if it has become a tool for certain groups to sustain their careers without market validation.

The incident has had a tangible impact on the musician involved, who has faced significant backlash and public scrutiny. Observers suggest that the 'cost' of such public outbursts has been high, potentially damaging their professional reputation and future prospects. As the discourse continues, it has become a focal point for larger questions regarding the intersection of politics, art, and public finance in Taiwan. The situation serves as a reminder of the scrutiny that public figures face when their private financial dealings are brought into the public eye.

Sources: Yahoo News, China Times, PChome Online, Apple Daily, ETtoday
