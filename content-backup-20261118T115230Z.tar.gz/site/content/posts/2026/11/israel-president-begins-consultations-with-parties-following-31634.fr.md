---
title: "Israël : incertitude politique renouvelée et début des consultations présidentielles pour former un gouvernement"
date: Wed, 04 Nov 2026 16:18:21 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiW0FVX3lxTE16VlJEM1d3V3hZVURESU85dmlFTTlValUxVG8xLUlaNi1hVy1sYmlPMG4zdWg2cW5EMUdLWEZHczFMWG9Qcy1DcnlNNmd4SlVXUGhYS2NZX1FBcjQ?oc=5"
source_name: "BBC"
draft: false
---

Le paysage politique en Israël fait face à une incertitude renouvelée alors que le président du pays entame des consultations formelles avec les partis politiques, à la suite d'un nouveau résultat électoral peu concluant.

<!--more-->

Alors que les résultats officiels des élections ont été confirmés et que les allégations de fraude ont été fermement rejetées par la commission électorale, l'attention s'est entièrement déplacée vers le processus complexe et délicat de la formation d'une coalition gouvernementale.

Le président Isaac Herzog a entamé la première série cruciale de discussions avec les différentes factions de la Knesset afin de déterminer qui détient les meilleures chances de former le prochain gouvernement.

Cette étape est fondamentale dans le système parlementaire israélien, où aucun parti n'obtient généralement la majorité absolue à lui seul, rendant les alliances indispensables à la stabilité institutionnelle.

Pendant ce temps, le dirigeant sortant Benjamin Netanyahu fait face à un bras de fer politique aux enjeux considérables.

Des factions politiques rivales s'activent pour manœuvrer, consolider leur pouvoir et bloquer sa trajectoire vers une nouvelle coalition, ce qui pourrait redessiner durablement la carte politique du pays.

Les analystes soulignent que la capacité de Netanyahu à négocier avec les partis religieux et nationalistes sera mise à rude épreuve.

Des organisations médiatiques de premier plan, telles que la BBC, The New York Times et Al Jazeera, suivent de très près ces développements politiques.

Elles soulignent que le rôle du président dans la médiation entre les factions rivales sera pivot pour briser l'impasse persistante qui paralyse le pays depuis la fin du scrutin.

L'issue de ces consultations déterminera si Israël parviendra enfin à se doter d'un gouvernement stable ou si le pays s'enfonce dans une période de turbulences et d'instabilité politique prolongée, affectant potentiellement sa position géopolitique et économique dans la région.

Source: BBC
