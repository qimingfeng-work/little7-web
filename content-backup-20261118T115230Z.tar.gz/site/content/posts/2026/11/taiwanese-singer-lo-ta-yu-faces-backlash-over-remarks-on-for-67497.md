---
title: "Taiwanese Singer Lo Ta-yu Faces Backlash Over Remarks on Former President Tsai Ing-wen's Childlessness"
date: Wed, 11 Nov 2026 21:21:00 GMT
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiSEFVX3lxTFBxSkhRRzNpZHRKS2xUcndLQXBYaTdpODg3NlhpRThfSkl1QUNFblg0SGo2Ym1UaWQ1X2Y1WEhNQkdrYjg2b1lrR9IBTEFVX3lxTE9vdjZLTWNEWDZweDFLSzFmMjZJNzdYUEdXUWVQdkpvUkFRWHNVd3lubDFkUmFOcENnVzRlTmRpOWR2ZE9iYXE4WUVUVDM?oc=5"
source_name: "三立新聞網SETN.com"
draft: false
---

Veteran Taiwanese singer-songwriter Lo Ta-yu has sparked intense public controversy following critical remarks he made regarding former President Tsai Ing-wen's lack of children. The comments quickly ignited a fierce debate across Taiwanese social media and political circles, dividing public opinion and drawing sharp rebukes from prominent public figures and gender equality advocates.

<!--more-->

During a recent public appearance, Lo criticized Tsai's leadership and specifically pointed to her marital status and childlessness as a point of contention. The remarks immediately drew heavy backlash online, with critics accusing the singer of misogyny and promoting outdated, patriarchal views. Social media users flooded platforms with condemnation, arguing that personal family choices have no bearing on a leader's political competence or dedication to the country.

Despite the widespread public outrage, the comments found some supporters within certain political factions. Some conservative commentators and blue-camp supporters voiced agreement with Lo's sentiments, with prominent political figures such as Cheng Li-wen publicly echoing support. Conversely, other public figures, including celebrity Chia Yung-je and politician-activist Chu Pei-chun, strongly denounced the remarks. Chu, who recently became a mother, emphasized that having a uterus does not mean a person owes the world children, reinforcing the broader pushback against judging women based on reproductive choices.

The controversy has also intersected with ongoing political campaigns, including the Taipei mayoral race. When questioned by reporters regarding the incident, politicians like Chiang Wan-an distanced themselves from the rhetoric, stating that marital and reproductive status should never serve as a standard for evaluating public servants. Observers note that the incident underscores deep-seated cultural divisions in Taiwan regarding gender roles, privacy, and political discourse.

Sources: 三立新聞網SETN.com
