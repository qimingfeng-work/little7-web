---
title: "Démission du président paraguayen Santiago Peña suite à l'effondrement de la banque Ueno"
date: Thu, 05 Nov 2026 16:26:50 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiuwFBVV95cUxOWGc3WWZCT3BZUUFMY3E0VW43Z244SWNKVUk4NS1RZ1RHVGVSdG1RSVNKVjFaZGdlQjktT2JvcElpNEVvMllaNTdIbWRMdmdQZ1F3RjZwMThjcVU5X1pYY20wajc0MzIyenBHX3MtaEVRRnpRTC16TWdITnA4QWZxcFhtNHh0UlR0YlZ2UkVqUmF4YXZWejdWY2xsZ0c2bm5oWUNiczZnWms4NHo2eHctcHJKSHJEMmNDQmtZ?oc=5"
source_name: "Reuters"
draft: false
---

Le président du Paraguay, Santiago Peña, a officiellement annoncé sa démission, marquant l'aboutissement d'une crise nationale majeure déclenchée par la faillite soudaine de la banque Ueno.

<!--more-->

Cet établissement financier numérique, autrefois présenté comme le fer de lance de la modernisation économique du pays, a vu son effondrement provoquer une onde de choc sans précédent sur l'ensemble de l'échiquier politique et économique paraguayen.

La chute brutale de la banque Ueno a mis en lumière des vulnérabilités structurelles profondes au sein du cadre réglementaire financier du pays.

Cette défaillance a suscité une indignation publique généralisée et une perte de confiance massive envers la gestion économique de l'administration Peña.

À mesure que la crise s'intensifiait, la pression politique exercée sur le président est devenue insoutenable.

Des législateurs issus de tout l'éventail politique ont commencé à exiger sa destitution, pointant du doigt l'incapacité de son gouvernement à superviser efficacement le secteur bancaire numérique, un domaine pourtant crucial pour l'avenir technologique du pays.

Des médias internationaux de premier plan, tels que Reuters, CNN et The Economist, ont suivi de près la détérioration rapide de la situation.

Le récit entourant l'échec de cette banque — autrefois célébrée comme une réussite exemplaire — s'est transformé en une mise en garde sévère sur les risques associés à une croissance financière numérique rapide et insuffisamment régulée.

Les retombées politiques ont plongé le pays dans un climat d'incertitude alors qu'il entame une transition délicate suite au départ du chef de l'État.

Les observateurs soulignent que cette démission constitue un tournant historique pour le Paraguay.

Avec un gouvernement confronté à un vide de pouvoir, l'attention se porte désormais sur la stabilisation de l'économie et la restauration de la confiance du public dans le système bancaire.

La volonté législative de faire toute la lumière sur cette affaire suggère que les répercussions politiques de cette crise continueront de se faire sentir dans les mois à venir, alors que le pays cherche à reconstruire ses fondations institutionnelles.

Source: Reuters
