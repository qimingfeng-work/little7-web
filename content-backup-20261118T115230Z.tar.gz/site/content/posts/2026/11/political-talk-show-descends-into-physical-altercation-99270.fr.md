---
title: "Une violente bagarre éclate lors d'un débat politique télévisé en Arménie"
date: 2026-11-17T08:21:00Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiSEFVX3lxTFBuWE1Ya0VLX2VscVRlMmxCUHJHTnp2VkNUTDhwUFNSVWp1XzZjWUxaZ2ZPN0ZWWksyd0pVWGRVN2k2b3EwOU85M9IBTEFVX3lxTE9yQTdrZk5GbzVNNzRjcTJtUFUzSG5fYTBnOU9DNXZ4ZlhDbElaV19sZFB3dndtM1BPWmlIOHZiMTBpcUlnVzdqZUtXZEw?oc=5"
source_name: "三立新聞網SETN.com"
draft: false
---

Un débat politique télévisé en Arménie a pris une tournure choquante lorsque deux invités se sont livrés à une bagarre physique, transformant le studio en un ring de boxe improvisé.

<!--more-->

L'incident, qui s'est produit lors d'une diffusion en direct sur la télévision publique, est devenu viral, suscitant à la fois une condamnation généralisée et l'amusement des téléspectateurs du monde entier.

L'altercation a commencé par un échange verbal houleux concernant des politiques politiques avant de dégénérer rapidement en une véritable bagarre, forçant l'équipe de production à intervenir.

Suite à la diffusion, l'un des participants, un journaliste, a fait un commentaire provocateur, affirmant que ses actions visaient à « discipliner » l'autre invité au nom de son père.

Cette remarque a ajouté une couche supplémentaire d'absurdité à l'événement, de nombreux utilisateurs des réseaux sociaux critiquant le manque de professionnalisme affiché à la fois par le journaliste et par l'invité.

L'incident a déclenché un débat national sur l'état du discours politique dans le pays et sur la tendance croissante des débats à sombrer dans l'hostilité.

Les autorités de radiodiffusion examinent actuellement les images pour déterminer la réponse appropriée, beaucoup appelant à des réglementations plus strictes sur les programmes politiques en direct afin d'éviter de telles explosions à l'avenir.

L'événement a été largement ridiculisé comme le signe de la détérioration de la qualité du débat politique, où les attaques personnelles et la violence physique ont commencé à éclipser les discussions de fond sur les politiques.

Cet incident n'est pas la première fois que les talk-shows politiques voient les esprits s'échauffer, mais le niveau de violence affiché à cette occasion est sans précédent pour un radiodiffuseur public.

Alors que le public continue de débattre de l'éthique des participants, l'incident sert d'avertissement quant aux dangers d'une rhétorique incontrôlée dans les médias.

La chaîne n'a pas encore publié d'excuses formelles, mais la pression pour répondre de la conduite de ses invités ne cesse de croître, soulevant des questions fondamentales sur l'éthique journalistique et la sécurité des plateaux de télévision en direct dans les démocraties en transition.

Source: SETN
