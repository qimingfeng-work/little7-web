---
title: "Bowen Yang Makes Surprise Return to SNL as Jensen Huang"
date: 2026-11-15T05:20:35Z
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMitgFBVV95cUxNVXBCTThkclVDdGVLb0RnbE1BRFU4aEpiZ0w1TEZDOXlVVks0Z0JqRjROWExsYW9VcC1qbmk0RDZCN2lMcTVvLUpjMUVlRTNra1dlT2tfNlIxcjYyVEQzXzF5NFFMRWZSMkc2Y096UDdTOVdKdE1ENjE4NWZPRHNRdnRzWm9qYjJnWURNWjZnbGd6M1h6WGsxdHA3RGJqMUhzdEJrakw0U2p1NHRDZkM2ZEtoTmVlUQ?oc=5"
source_name: "The Daily Beast"
draft: false
---

In a surprising turn of events during the latest episode of 'Saturday Night Live' (SNL), fan-favorite comedian Bowen Yang made a dramatic return to the show. Yang appeared during the cold open, taking on the persona of Nvidia CEO Jensen Huang. The sketch, which also featured John Mulaney, aimed to satirize the current landscape of tech leadership and the ongoing controversies surrounding high-profile Silicon Valley figures.

<!--more-->

The comedic segment focused on the intersection of technology, corporate culture, and current events. Yang's portrayal of the tech mogul was met with enthusiasm from the audience, as he navigated a script that poked fun at everything from the recent FAA ground stops to the widespread Microsoft outages. The writers utilized the platform to critique the perceived detachment of tech CEOs, specifically targeting the 'sex-mad' and eccentric public image that has recently surrounded certain industry leaders.

John Mulaney, acting as a foil to Yang's character, helped guide the sketch through a series of absurd scenarios, including a 'crash course' for tech CEOs dealing with complex geopolitical and corporate espionage issues. The performance was widely noted for its sharp wit and the seamless way it integrated real-world tech frustrations into the late-night comedy format. Critics and viewers alike praised Yang for his ability to capture the mannerisms and public persona of the Nvidia executive, adding a layer of authenticity to the biting satire.

This appearance marks a significant moment for the current season of SNL, as the show continues to leverage its cold opens to address pressing cultural and political topics. By bringing back a seasoned performer like Yang, the show managed to heighten the impact of its critique, turning a standard sketch into a viral moment that resonated across social media platforms. The sketch serves as a reminder of the show's enduring ability to stay relevant by lampooning the most powerful figures in the tech world.

Sources: The Daily Beast
