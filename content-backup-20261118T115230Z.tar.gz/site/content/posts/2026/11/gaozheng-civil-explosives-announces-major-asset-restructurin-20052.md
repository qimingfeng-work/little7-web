---
title: "Gaozheng Civil Explosives Announces Major Asset Restructuring and Resumption of Trading"
date: Sun, 01 Nov 2026 07:35:47 GMT
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiRkFVX3lxTE5ON1QwR1RZcTFvZEZfbkxMeWM2OTc0UzViam4yUWhDVFluSWZTZXBTMmxnZlB4eGhFeXZMNXJfMVF4MkxRalE?oc=5"
source_name: "财联社电报"
draft: false
---

Gaozheng Civil Explosives, a company listed on the Shenzhen Stock Exchange, has officially unveiled a significant asset restructuring plan, signaling a new chapter for the firm following a period of suspension. The company announced that it intends to acquire major stakes in two mineral-related enterprises through the issuance of new shares, a move aimed at integrating upstream assets and diversifying its business footprint.

<!--more-->

Under the terms of the restructuring proposal, Gaozheng Civil Explosives plans to purchase a 51 percent controlling interest in Ziyuan Copper Industry alongside the full acquisition of Shengyuan Mining. By bringing these entities into its corporate structure, the company is effectively pivoting to incorporate high-value mining operations into its portfolio. To support this strategic expansion, the company will also raise supplementary funding through the issuance of additional shares, providing the necessary capital to facilitate the integration of these newly acquired assets.

The announcement puts an end to the stock's recent trading hiatus, which had captured market attention due to speculation regarding the company’s future direction. Following the disclosure of the restructuring details, the firm confirmed that its shares are scheduled to resume trading on November 2. 

Industry analysts have noted the strategic implications of this deal, particularly highlighting the involvement of Zijin Mining in the regional mining landscape. By serving as a vehicle for these mineral assets, Gaozheng Civil Explosives is positioning itself as a vital financing and operational platform within the Tibet-based mining sector. This restructuring is widely viewed as a move to optimize resource allocation and leverage the industrial synergy between civil explosive applications and mining operations.

Investors and market participants are expected to watch the stock’s performance closely as trading resumes, gauging how the market reacts to the company’s ambitious transition. As the firm moves forward with these acquisitions, it aims to enhance its long-term competitive edge and deliver value through a broader scope of operations. With the regulatory filing now complete and the transaction parameters established, the company is set to embark on a transition that shifts its primary focus toward mineral asset management and mining sector development. 

Sources: 财联社电报
