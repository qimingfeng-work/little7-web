---
title: "Japanese Ground Staff Confronts Aggressive Passenger Over Excess Baggage"
date: 2026-11-12T07:07:30Z
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiswNBVV95cUxPMFRqZmZyZEpIcnBEcU9mRkVwbXJ0Qk5Ea3ItRVUzR0RtdWI4RDAwV2l4TzNpTGRrRng2Uk9UeG82MmdwVUJmZkhnWFZhb1dSQlNCVE40VTB4TURTMGZRSUgzUjk4WjhiTW91V2tyYXcwWHBuRWZOcGFJYW44NG1mQVh3bVVxd1hRcGE2Y3VNOVFzaWFkWFRZTmxIeERteXRwZE1uTkprNUs2NjlsSjRhcm4zMTJEX3dQMVlvVXEwaTFGbWsyT21ncUw1OHJQRHZFMVRpVTJkZDZ0bUxvcWVzcWRSeUhwdW1qUy1wV0pmMXpOZzlNTHJNQzlPZUotQ3pCSzV0NXA4RExLZmhZWHJLMHpwQ3Y2OGNQZU1MVjh2Zm1ZZHZMcGl0X2Qyc0NBeWt2N0UtYURwbXJ0T1NBdzZUdHZKU2lnZ0FoM2wxOFI4djd5TUdoSC10OXVCWlVHdUxUaXRNRGREMThRdk5rV0Q0UXJoMmZfelNUU1RZT0hOVHFFOWRqZnpkY2p4ekxZUXRWS00yQ0FfakFpWUtWdndnYmpEdThKVWZxbnhDRlk5ZlBfcGs?oc=5"
source_name: "Yahoo新聞"
draft: false
---

A viral video has captured a heated confrontation between a passenger and airline ground staff at a Japanese airport, highlighting the growing tensions regarding airline baggage policies. The incident involved a passenger from Hong Kong who reportedly refused to pay for excess baggage fees and subsequently engaged in verbal abuse toward the airport staff.

<!--more-->

The situation escalated when the passenger continued to berate the employee, leading the ground staff member to take an unexpected and firm stand. In a moment of frustration, the staff member tore up the passenger's boarding pass, effectively denying them boarding. The footage, which has since circulated widely on social media, has sparked a polarized debate regarding the conduct of both the passenger and the airline personnel.

Many viewers have expressed support for the ground staff, arguing that airline employees should not be subjected to verbal abuse, regardless of the circumstances. Others have questioned the professionalism of the staff member's reaction, noting that destroying a passenger's documents is an extreme measure that could lead to further complications for the airline. The incident serves as a reminder of the challenges faced by airport staff who must enforce strict baggage regulations while dealing with increasingly frustrated travelers.

Airline policies regarding baggage weight and size are strictly enforced for safety and operational efficiency. When passengers refuse to comply with these rules or resort to aggressive behavior, it creates a difficult environment for both staff and other travelers. The airline involved has yet to issue a formal statement regarding the incident, but the video has undoubtedly drawn attention to the need for better conflict resolution training and clearer communication of baggage policies at international travel hubs.

Sources: Yahoo News
