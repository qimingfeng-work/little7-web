---
title: "Réforme de l'emploi des jeunes : un appel à une refonte totale du système"
date: 2026-11-16T22:32:47Z
lang: "fr"
mode: "llm_translate"
source_url: "https://www.bbc.co.uk/news/articles/c38xzy980924o?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
image_url: "https://ichef.bbci.co.uk/ace/standard/240/cpsprodpb/1a76/live/fbd49eb0-e1e2-11f1-9f14-b33806cfd783.jpg"
draft: false
---

Un rapport dirigé par Alan Milburn a lancé un avertissement sévère concernant l'avenir de la jeune génération, appelant à une « réinitialisation complète du système » pour aider 440 000 jeunes à intégrer le marché du travail.

<!--more-->

Le rapport met en lumière une défaillance systémique dans le pont entre l'éducation et l'emploi, suggérant que les structures actuelles ne sont plus adaptées à un paysage économique en évolution rapide.

L'examen de Milburn soutient que les cadres actuels régissant l'éducation, la formation professionnelle et l'aide sociale sont fragmentés et souvent contradictoires.

En échouant à fournir un parcours cohérent pour les jeunes, en particulier ceux qui ne sont ni en emploi, ni en éducation, ni en formation (NEET), le système actuel marginalise une part importante de la prochaine génération.

Les réformes proposées visent à démanteler les barrières bureaucratiques qui empêchent l'accès à des opportunités de carrière significatives.

Au cœur des recommandations se trouve un appel à une approche intégrée de la formation professionnelle, où les écoles et les collèges travailleraient en étroite collaboration avec les entreprises locales pour aligner les compétences enseignées sur les demandes réelles du marché.

De plus, le système d'aide sociale est critiqué pour son caractère punitif plutôt que solidaire, le rapport préconisant une transition vers des politiques actives du marché du travail axées sur l'acquisition de compétences à long terme.

Bien que le débat sur la faisabilité et le coût d'une telle restructuration soit inévitable, le rapport souligne que les coûts économiques et sociaux à long terme de l'inaction, tels que le chômage persistant et la perte de productivité, dépassent largement l'investissement initial requis pour la réforme.

Source: BBC News
