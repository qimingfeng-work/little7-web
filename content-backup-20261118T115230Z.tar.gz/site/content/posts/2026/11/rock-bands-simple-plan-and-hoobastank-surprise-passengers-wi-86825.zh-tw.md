---
title: "空中驚喜：Simple Plan 與 Hoobastank 樂團機艙內即興開唱"
date: 2026-11-14T23:26:36Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMivAFBVV95cUxNWUQxeGwxS3VXQ1BQa3pkblljNzVmaUFWdEMxelNHUFN6dU5IcFZodV9EYWVRZWoyQVZiRnZzMEd0ZDJTSGxUaG9Rdkl0Q2Fsb1h3Y05WaXhIYnowTmpkeFBFYlh1dzdfdHpxeTVoY041LTEwb3BJXzhPdTBIRzFJVXRUWXlOVlh1RUk1LWtYc0VPd2JVZnVhczVDQXRzc2ROTTZWUHQ3M2ZxaEVNSnJ1NHNybzlGYkxuMnNPYg?oc=5"
source_name: "The Hollywood Reporter"
draft: false
---

近期搭乘飛機的旅客經歷了一場難忘的旅程，2000 年代指標性搖滾樂團 Simple Plan 與 Hoobastank 的成員，將飛機客艙變成了即興演唱會現場。

<!--more-->

這場意外的音樂表演，發生在全國性航班停飛導致飛機與乘客被迫滯留空中之際，為機上所有人創造了一個罕見且超現實的環境。隨著聯邦航空總署（FAA）停飛的訊息在航空網路中傳開，乘客們開始意識到他們將在空中度過比預期長得多的時間。

為了緩解緊張情緒並娛樂焦躁的旅客，這些備受喜愛的另類搖滾與情緒搖滾（emo）樂團成員決定將危機化為轉機。樂手們拿起木吉他等樂器，就在飛機走道中間舉辦了一場迷你「Warped Tour」風格的演唱會。

根據《好萊塢報導》（The Hollywood Reporter）、NBC 與《今日秀》（TODAY）等媒體廣泛分享的影片與報導顯示，樂團成員在巡航高度演奏了膾炙人口的熱門歌曲。

Hoobastank 為粉絲獻唱了經典抒情曲《The Reason》，而 Simple Plan 則為客艙帶來了高昂的能量。乘客們紛紛跟著唱和，用智慧型手機記錄下這些時刻，並在數千英呎的高空享受這場超現實的空中演唱會。

這場自發性的空中演出迅速在網路上瘋傳，吸引了全球目光，並為 2000 年代搖滾樂迷帶來了懷舊感。雖然意外的旅遊延誤通常是旅客沮喪的來源，但這群乘客卻發現自己成為了流行文化歷史中獨特篇章的一部分。

滯留的音樂人與航空旅客之間的合作，將一場例行的交通中斷轉化為一場關於音樂與韌性的歡樂慶典。

來源: The Hollywood Reporter
