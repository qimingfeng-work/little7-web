---
title: "Coupe du monde U23 : Le Taipei chinois renverse le Japon"
date: 2026-11-14T02:23:05Z
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiUEFVX3lxTE9fdTUxakxqMWZxTTFjNlF4RnJST2ZPbFY0VUxLVmpGT3hTbk8zcXN5OV9IZjJwSS1FdURqa0hzQjA2Y2JkSGFKREQ3bGFZUEd60gFWQVVfeXFMTzRaRWpiZ1ZtS0lkOWFxaHRPTnpfcFJDRnk4N2J5VWRfQ18tbGxUX2NlWTEtb3hGVi1pUjVmeEx3S0NnaUVhVmFwNS1kek5kZWZsd2p6d2c?oc=5"
source_name: "UDN"
draft: false
---

Dans une démonstration palpitante de baseball international, l'équipe du Taipei chinois a réussi un retour remarquable pour vaincre le Japon 2-1 lors de la Coupe du monde de baseball U23, s'assurant ainsi sa deuxième victoire consécutive dans le tournoi.

<!--more-->

Cette victoire durement acquise rapproche l'équipe des phases finales, ravissant les fans et les analystes sportifs.

Le tournant du match est survenu grâce à un coup de circuit décisif de Huang Chun-Lin, dont la frappe puissante a complètement fait basculer l'élan de cette rencontre à faible score.

L'héroïsme offensif de Huang a fourni le soutien crucial nécessaire pour renverser le déficit et mettre la pression sur le redoutable personnel de lanceurs japonais.

Sur le plan défensif, le lanceur partant Lei Hao-Bo a livré une performance stellaire, lançant un match complet sur sept manches dominantes.

Faisant preuve d'un contrôle et d'une vitesse exceptionnels, le lanceur a déconcerté les frappeurs adverses tout au long de la partie.

La couverture médiatique après le match a également souligné le potentiel professionnel de plusieurs lanceurs du Taipei chinois, notamment Wu Cheng-Hao et Wang Hsuan-Chi, qui attirent l'attention des recruteurs internationaux.

Avec l'élan de leur côté, l'équipe attend avec impatience son prochain match contre le Venezuela alors qu'elle se bat pour une place sur le podium.

Source: UDN
