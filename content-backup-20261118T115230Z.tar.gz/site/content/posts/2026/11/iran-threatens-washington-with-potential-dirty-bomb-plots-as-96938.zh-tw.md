---
title: "美伊緊張局勢升溫：伊朗威脅川普政府官員，國土安全部啟動緊急應變"
date: 2026-11-16T23:46:33Z
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMirAJBVV95cUxOazFhVXFzYTA2Vk1wME9HUHQwX19YMnl1QUdQYjlXN3hzbGZyNFZTR0Z5WlE1eXhXUTdtM050T18zc3BoUWM3dkhPUWpVX25GNnI4eXN1SWM2X2hBMjVYXzRCMFgzX2daaVZSbHZFTy1Mc3N2ZjZORnA4ZWl1SFY4OW4tam1seHZIMzl2X2V5VWtBaWg1N2I0b1d1UXc1cFRtVFNua2JsTGthTzh4UWpROW9wTnJrcWdDRllUemZvMlRDLXFlUkxyVk40eV9RQm5qY2lBZ0trMFdhMmZjMlZuSFdTRUNYUzBOYzJIUzJoT3FUNGY5b0lBWjNJMjJoc0I0MUExcU5hU3ZqYU1qZnpqQVVfLVBNZ2JRZE5WR1EwaVJRazZJMl9oNUY5bVc?oc=5"
source_name: "Yahoo新聞"
draft: false
---

隨著關於針對川普政府高層官員潛在安全威脅的情報報告浮出水面，華盛頓與德黑蘭之間的緊張關係急劇升溫。據 CNN 及多家主要財經媒體報導，美國當局在獲悉伊朗可能策劃涉及「髒彈」或化學武器的攻擊情報後，已啟動緊急應變機制。

<!--more-->

美國國土安全部公開強調，前總統唐納·川普及其家人正面臨持續性的每日威脅，這促使首都地區全面提升安全防護措施。地緣政治的衝擊已不僅限於國內政治人物，更涉及直接的軍事摩擦與嚴厲指控。

報告指出，伊朗針對一起涉及多名學童死亡的事件公開指責美國，進一步激化了敵對言論。在更具侵略性的舉動中，伊朗當局甚至明確威脅在該地區執行任務的美國驅逐艦指揮官與執行官。

這些發展加劇了外界對於無人機及海上巡邏安全的擔憂。安全官員與國際分析師正密切監控局勢發展，國土安全部也持續評估日益增長的無人機威脅與安全風險。

國內政治威脅與國際海軍對峙的交織，凸顯了該地區外交關係的脆弱性。隨著華盛頓加強防禦態勢，國際社會對於局勢進一步升級以及駐外人員的安全深感憂慮。

來源: Yahoo新聞, 鉅亨網, 大紀元, 世界新聞網, 中央社 CNA
