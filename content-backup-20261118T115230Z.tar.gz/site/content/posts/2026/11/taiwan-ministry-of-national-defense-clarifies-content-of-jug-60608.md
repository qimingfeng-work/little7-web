---
title: "Taiwan Ministry of National Defense Clarifies Content of 'Juguang Day' Broadcasts"
date: Tue, 10 Nov 2026 13:17:00 GMT
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMi5wNBVV95cUxOSjlaRkpkZnZySU9vYndQdWNOMG52YUJUMUpkY2pwSjN2RlQwXzRrRkp3bVVBZXJmYW11TFdfQTlPRlFqTXFoTXAyVDdhb0c1ZS1qWXdiamtaRm5RemF6WUlqSS1jV2dRUThpS1o5QVY1ckZHWTU4NDV1V05VSTJnZ3hZdFY1cFdIRGJxYmxncW1JeUdGRHVRTElLY3BZVkFXYV8tRThhVmk2Y2JhNlRjYXB1QmQ1ajBFMkhDSWo1dVZxbDdoQ3hENjR0ejlSNnhrWTBuZlZOWVh2MEVXWTJPWHhpTVZlcVhsbFpoTGpmVXY1T2NyYzlFRFhvXzVWVzBzeG9rU3RZZ2kyQnZEd1BZM0prbXowN2VTTDhkWVEyLW9JWEZNZTFaS182U3FTZFY4cUhsNkpucUtUWnlVNm5TUy1ZeXdaUUJjdjBHQ0VQSF9rbzRoTHBaQmhoRFAxZEpCekFFZlJjb25pNGlkRVZLRllReXJNOVRCV0JGcklyVk9PZ1dyQkVnTXZSWFNjYV9xY0NmejJIT0UxSzZpc2dWNUR4cHc3TDB1bEJJXzZrdDhXcldiMHIxYXlrQUgzdHF4TmUteHBHRU1scmd4WkplWEpuWExVZ09haXlISlZXUHhDQ0IwY2hn?oc=5"
source_name: "Yahoo新聞"
draft: false
---

The Taiwan Ministry of National Defense (MND) has issued a formal clarification following allegations from a local city councilor that military personnel were being shown videos featuring politician Shen Po-yang during 'Juguang Day'—a mandatory military education program. The councilor claimed that the inclusion of such content in military training materials was politically motivated and inappropriate. In response, the MND conducted an internal review and released a detailed timeline to address the controversy.

<!--more-->

The Ministry stated that the video in question was broadcast in April 2024 and was part of a broader educational curriculum. Crucially, the MND emphasized that the content of the broadcast was entirely unrelated to any electoral activities or the recent local elections. According to the Ministry, the educational materials are designed to enhance the knowledge and awareness of service members on various national issues, and the selection of speakers or topics is based on professional criteria rather than political alignment.

The MND's response was intended to quell concerns about the politicization of the military. By providing a clear timeline and context for the broadcast, the Ministry sought to 'slap down' the accusations of bias. The incident highlights the ongoing sensitivity regarding the intersection of politics and military education in Taiwan. The Ministry reiterated its commitment to maintaining political neutrality within the armed forces, ensuring that training programs remain focused on national defense objectives rather than partisan agendas. The clarification has been widely reported by local media, serving as an attempt to restore public confidence in the military's educational standards.

Sources: Yahoo News
