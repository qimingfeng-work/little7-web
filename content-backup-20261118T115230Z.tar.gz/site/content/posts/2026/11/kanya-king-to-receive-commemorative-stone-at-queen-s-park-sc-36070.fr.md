---
title: "Kanya King, fondatrice des MOBO Awards, honorée par une plaque commémorative à Londres pour son impact culturel"
date: Thu, 05 Nov 2026 12:09:54 GMT
lang: "fr"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMiXkFVX3lxTE5DTWliUERkcno1djV6aE92STlRcGpGaGFFcUZlRV9COGRzSC1rek9XQXJCMTlUZUpRVDhNaWd2NnpDRDh2el9INEROX0k0bjhmX0M2V2hCaUdyTVVMVEE?oc=5"
source_name: "BBC"
draft: false
---

Kanya King, la fondatrice immensément influente des célèbres MOBO Awards (Music of Black Origin), s'apprête à recevoir un hommage exceptionnel sous la forme d'une pierre commémorative installée dans une école située à Queen’s Park.

<!--more-->

Cette reconnaissance institutionnelle et communautaire sert de vibrant tribut à ses contributions majeures et durables à l'industrie musicale britannique ainsi qu'à son rôle de pionnière incontestée en matière de diversité et d'inclusion dans les arts.

La cérémonie officielle mettra en lumière son parcours remarquable, depuis ses débuts modestes jusqu'à son accession au rang des figures les plus respectées et écoutées de la vie culturelle au Royaume-Uni.

La carrière remarquable de Kanya King a toujours été définie par son engagement indéfectible et courageux à offrir une plateforme médiatique d'envergure aux artistes noirs qui étaient systématiquement ignorés ou marginalisés par les cérémonies de récompenses traditionnelles et grand public.

La création historique des MOBO Awards en 1996 a constitué un véritable tournant, un moment charnière qui a contraint l'industrie musicale tout entière à faire face à son manque criant de représentation équitable.

Au fil des décennies, elle est restée une avocate inlassable de l'égalité, utilisant habilement son influence croissante pour encadrer la jeune génération de talents et exiger des changements structurels et systémiques profonds au sein du secteur de la musique.

Le choix délibéré d'implanter cette pierre commémorative dans une école de Queen’s Park revêt une valeur hautement symbolique, car cet emplacement a pour vocation explicite d'inspirer directement les élèves et les étudiants des nouvelles générations.

En plaçant un repère permanent au cœur même d'un espace entièrement dédié à l'éducation, la communauté locale souligne avec force l'importance capitale que revêt l'héritage de Kanya King pour les jeunes qui peuvent ainsi s'identifier et se projeter à travers sa réussite exceptionnelle.

C'est un rappel permanent et nécessaire que l'impact d'une vie ne se mesure pas seulement aux trophées remportés ou à la richesse accumulée au fil du temps, mais bien aux portes que l'on parvient à ouvrir pour tous ceux qui choisissent de suivre nos traces.

Les élus locaux et les responsables communautaires ont exprimé publiquement leur immense fierté d'accueillir ce magnifique hommage, rappelant que le travail acharné de Kanya King a laissé une empreinte positive et indélébile sur le tissu culturel de toute la nation.

Alors qu'elle poursuit inlassablement son combat militant en faveur de la justice sociale et de l'excellence artistique, cette pierre commémorative demeurera pour longtemps le témoignage éclatant de sa résilience et de sa vision avant-gardiste.

Cet événement est à la fois une célébration joyeuse d'une carrière hors du commun et un appel vibrant adressé aux jeunes étudiants pour qu'ils poursuivent leurs propres passions avec le même niveau de dévouement et d'intégrité dont Kanya King a fait preuve tout au long de son existence.

Source: BBC
