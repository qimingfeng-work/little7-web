---
title: "Bonfire Night Disorder Triggers Arrests and Emergency Response Surges in Tameside and Bolton"
date: Fri, 06 Nov 2026 14:49:00 GMT
lang: "en"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiuAFBVV95cUxQLXhTeWp3T3kzZjA0enMzYmRzZkU1SXBNQk04OGtjQ2hGRWpNSnN0aFUyV0NlTFAyUUt6WFYzX2VzLVNGSzMxZXRQcGwxUlFSOEhTdnp4MUM2UzBvSGJvYzc4eXhIYVpfVkpTQjZvMTBXby0yS00tdUZZVHQxVVN4ZkdWVGpEVGNsOGVCXzRVeG9KOXcwdE1tWGtUdThTTXhnOTR3LVU2eHU5d05YRDZqUlJXYVh3Y0540gG-AUFVX3lxTE15VDd3TmlKRFlEaUtKRk54d2ZyaG1jdDFQUHNNb01vbHdzbFlRSXRTTUF5QURRbU5PaE96MHZxcGlxMjRGa0ZsbFd0Z2dDWWZmQXkxUkZieW5wRkxqMmpuT0FGTld3aWpjOUgyXzQwclV6VldfTU13WGNvZmw1akRKamN1ZFFfdU14QXRWN0J4NHRuNHdWUTZPdVY2MUJlbWowc1hNR29LYkRxM0N5U0tuMEw0TFd3UTc1LVRFS0E?oc=5"
source_name: "Manchester Evening News"
draft: false
---

Recent Bonfire Night celebrations across parts of Greater Manchester, including Tameside and Bolton, were marred by widespread anti-social behavior and public disorder. Shocking footage shared widely across media platforms captured groups of youths recklessly launching fireworks directly at residential properties and moving vehicles. The chaotic scenes prompted an immediate and heavy response from local law enforcement and emergency services, who struggled to manage the surge in dangerous incidents.

<!--more-->

In response to the escalating violence, Greater Manchester Police issued immediate dispersal orders for heavily affected areas, granting officers expanded powers to proactively tackle groups engaging in disruptive behavior. Authorities confirmed that multiple arrests have already been made in connection with the street fireworks disturbances. Meanwhile, local fire and rescue services reported an overwhelming volume of calls, with Bolton alone recording dozens of emergency responses to fire-related incidents throughout the evening.

Community leaders, emergency service representatives, and local officials have strongly condemned the reckless actions targeting both public property and frontline responders. Police have emphasized that proactive patrols and investigations will continue in the coming days to identify additional individuals involved in the disorder. Authorities are urging witnesses to come forward with video footage or information to help ensure those responsible face full accountability for endangering public safety.

Sources: Manchester Evening News
