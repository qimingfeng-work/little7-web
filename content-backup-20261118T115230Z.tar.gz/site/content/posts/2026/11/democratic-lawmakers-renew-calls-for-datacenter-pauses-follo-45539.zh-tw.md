---
title: "資料中心擴張引發環保爭議：民主黨議員呼籲暫停建設"
date: Fri, 06 Nov 2026 21:14:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMilgFBVV95cUxNaVlBaF9ySDJtNHBSYkZBYkVTQ1g4cHlER2ZIYnFzakVsUDBSTXpHVXhLU0lWVU83N05INjluWHZVWnBvcVg3YTlHTG5BU0pHRDFKY1NYYlFRZHBVMlQ2cDJmdzFteTV6NHFiYVpETkd1RThhTGFhdWIzWVVxRWRCQWUtUEFqTDFCU3hXbVk0amwyOWZHdWc?oc=5"
source_name: "The Guardian"
draft: false
---

在近期選舉格局變動之後，多位民主黨議員再次發出緊急呼籲，要求暫停新型資料中心的快速開發。這一舉措的背景是，這些設施在能源和水資源上的巨大消耗已引發了環保與社群層面的廣泛擔憂，並在政治上獲得了顯著關注。

<!--more-->

在多個地區，為人工智慧和雲端計算提供動力的基礎設施建設，已從單純的地方規劃問題轉變為全國舞臺上的重大議題。近期的選舉週期表明，公眾對公用事業費率、電網可靠性以及環境退化的焦慮感已深刻影響了選民行為。

針對大規模技術設施的基層反對力量有效地動員了社群，形成了一種令許多傳統分析師感到意外的強大政治動力。競選分析師指出，那些能夠捕捉到這些地方性不滿情緒的候選人，成功地與那些擔憂企業無序擴張和資源枯竭的選民產生了共鳴。

然而，行業代表則為資料中心的擴張進行辯護，稱其為重要的經濟引擎和現代數字經濟的核心組成部分。他們認為，停止建設可能會嚴重阻礙技術創新，特別是在人工智慧這一全球競爭激烈的領域。

科技倡導者強調，企業正越來越多地投資於可再生能源解決方案，以減輕其環境足跡。儘管行業給出了保證，但推動臨時暫停令的議員們堅持認為，採取預防性措施對於保護地方資源和確保適當的監管監督是必要的。

這場辯論凸顯了技術進步與可持續社群發展之間日益加劇的緊張關係。隨著立法會議的恢復，資料中心的擴張前景很可能將繼續成為經濟雄心與環境保護倡導之間激烈博弈的戰場。

來源: The Guardian
