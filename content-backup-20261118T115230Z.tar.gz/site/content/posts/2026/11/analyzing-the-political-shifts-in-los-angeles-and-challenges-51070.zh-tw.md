---
title: "洛杉磯市長貝斯面臨城市治理壓力 跨社群溝通與領導策略受嚴峻考驗"
date: Sun, 08 Nov 2026 11:00:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://news.google.com/rss/articles/CBMizgFBVV95cUxOWkZFTEREWEJZOG1GUS1vMDRDeXhFZF9CbEtIVU1PaGd3aC1oS1VPS1lVaXhYNzhTdUNNUHJEMGNtY2djTC13OHdQTFA2dTJveGZ1eENVTGtfbTNTVUEwRzVIRjRsck4tWlVsY1lieWZLaTd4QXNoWDJnd0hIZlcwQnN5cjJ0WG9SVVZnUlM3UGRuVUhMazFWQXoxaEZnZFNqSGM0TS0zSEhNWkVMS0pSTFItTWhkNFdyVVRpQ19fZHV4QmNrdEpXakJpRjN1UQ?oc=5"
source_name: "Los Angeles Times"
draft: false
---

洛杉磯市長凱倫·貝斯（Karen Bass）當初競選時，在很大程度上建立在出色的個人人際交往能力以及搭建多元社群橋梁的政治聲譽之上。

<!--more-->

然而，近期的政治發展與城市政治版圖的轉變，開始引發外界質疑：在龐大且複雜的城市治理壓力下，這種人際連結導向的策略究竟能發揮多大成效。正當洛杉磯持續應對住房短缺與無家可歸者危機等根深蒂固的挑戰時，內部的政治分歧也日益明顯。

政治觀察家指出，雖然在洛杉磯這樣一個高度多元的大都市中，建立政治聯盟是不可或缺的，但進步派陣營與關鍵地方盟友之間不斷變化的優先事項，往往會為市府領導階層帶來意料之外的內部摩擦。

與此同時，市議會中較為年輕的進步派聲音（例如議員妮蒂亞·拉曼 Nithya Raman）取得了顯著進展，這反映出洛杉磯選民政治思潮的轉變。這些變化表明，選民越來越要求在關鍵議題上看到直接、具體的成效，這也對傳統領導者的政治結盟與行政處理方式構成了嚴峻考驗。

駕馭這些錯綜複雜的政治動態需要持續不斷的對話與策略性的妥協。隨著貝斯市長繼續致力於解決城市的核心挑戰，與溫和派及進步派盟友維持強韌的緊密關係，將是推動有效立法與維持公眾信任的關鍵所在。

來源: Los Angeles Times
