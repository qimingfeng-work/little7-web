---
title: "Political Turmoil in Taiwan as KMT Figures Clash Over Party Unity and Strategy"
date: Tue, 10 Nov 2026 17:27:35 GMT
lang: "zh-TW"
mode: "llm_rewrite"
source_url: "https://news.google.com/rss/articles/CBMiakFVX3lxTE1aeWtaZkkzVi0tSldxbzJIeVlmbEJLTHVRWGR5MDh4RFNydkVrUDZnMzM5TFltay1YSHNaaVhzRFlGVVZJWVVMYXpRdGxBSFBDUXVodnVpM0RXOXRwS25hSy1OaFF0OUlqZUHSAW9BVV95cUxQdERRcVl6UUxxcVZhUUlmUzQzTUR4T3Z2cVo1dTY0UlFWTXZqVmtkMGJROEhCYS12MV9RcTdlT2x4RExWaXAxWE4xcmVic1pkN0RVb0d6WmpMZTJzRmpTVWpCeEZWS2VnSGR5Tm4yNHc?oc=5"
source_name: "自由時報"
draft: false
---

The political landscape within Taiwan's Kuomintang (KMT) has been shaken by internal disputes, with senior party figures publicly clashing over strategy, discipline, and candidate retention. Recent reports highlighted efforts by party veteran Yang Chih-liang to convince Jaw Shaw-kong to remain within the party, warning that an actual departure could severely damage the political prospects of the pan-blue camp in upcoming elections. This internal friction reflects deeper anxieties regarding party cohesion and the ongoing debate over potential cooperation strategies with the Taiwan People's Party (TPP).

<!--more-->

Tensions have also flared over public outreach and messaging tactics. Taipei Mayor Chiang Wan-an's planned appearance on a popular TPP livestream platform has intensified discussions about how the KMT should approach younger voters and supporters of the third party. While some party strategists view cross-party engagement as a necessary step to broaden their appeal, critics within the KMT worry that such moves blur ideological boundaries and weaken the party's core identity. Public spats between high-profile members, characterized by sharp rhetorical exchanges and accusations of internal betrayal, have further exposed fractures within the political camp.

Political analysts suggest that these public disputes threaten to undermine the opposition's momentum at a crucial electoral juncture. With party discipline appearing increasingly fragile and strategic direction remaining a point of contention, KMT leadership faces a daunting challenge in uniting its base. Unless the party can resolve its internal divisions and present a cohesive front to the electorate, the opposition risks squandering valuable political capital ahead of the polls.

Sources: 自由時報, UDN, EBC, LINE TODAY, TVBS新聞網, Yahoo新聞
