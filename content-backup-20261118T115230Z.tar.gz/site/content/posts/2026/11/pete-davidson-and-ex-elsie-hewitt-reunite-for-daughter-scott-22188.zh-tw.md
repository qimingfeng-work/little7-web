---
title: "皮特·戴維森與前伴侶埃爾西·休伊特共同慶祝女兒萬聖節"
date: Sun, 01 Nov 2026 21:47:00 GMT
lang: "zh-TW"
mode: "llm_translate"
source_url: "https://www.bbc.co.uk/news/articles/cm369yy7lw73o?at_medium=RSS&at_campaign=rss"
source_name: "BBC News"
draft: false
---

喜劇演員皮特·戴維森（Pete Davidson）與其前伴侶埃爾西·休伊特（Elsie Hewitt）暫時擱置了過去的隔閡，為了一個溫馨的家庭里程碑而團聚：慶祝女兒斯科蒂（Scottie）的第一個萬聖節。

<!--more-->

儘管此前曾有關於育兒安排的報道，這對友好相處的前任依然共同為孩子協調了一套可愛的家庭服裝。社交媒體上分享的照片捕捉到了三人共同微笑的畫面，證明瞭共同撫養達成和諧的可能性。

粉絲和媒體紛紛稱讚他們將女兒的幸福放在首位，創造了積極的家庭回憶。此次團聚展現了雙方共同致力於為斯科蒂提供充滿愛的成長環境的承諾。

News

來源: E!
